"""Public-action statistics with explicit opportunities; no hidden-card labels."""
import math
from .contracts import PokerError

NAMES = ('three_bet', 'four_bet', 'fold_to_three_bet', 'fold_to_four_bet',
         'flop_cbet', 'fold_to_flop_cbet', 'turn_barrel')
SIZE_BUCKETS = ('le25', 'le33', 'le50', 'le75', 'le100', 'over100')


def add_public_decision(counters, observation, event):
    actor, street = observation['actor'], observation['street']
    if actor != event['seat'] or street != event['street']:
        raise PokerError('frequency event does not match its public decision')
    legal = {a['kind'] for a in observation['legal_actions']}
    if event['kind'] not in legal:
        raise PokerError('frequency event action was not available')
    history = observation['history']
    pre = [e for e in history if e['street'] == 'preflop' and e['kind'] in ('bet', 'raise')]
    flop = [e for e in history if e['street'] == 'flop' and e['kind'] in ('bet', 'raise')]
    current = [e for e in history if e['street'] == street and e['kind'] in ('bet', 'raise')]
    facing = int(observation['to_call']) > 0
    raises = event['kind'] in ('bet', 'raise')
    def observe(name, eligible, success):
        if eligible and observation.get('history_complete', True) is True:
            for suffix, increment in (('opportunities', 1), ('successes', int(success))):
                key = f'poker/{name}/{suffix}'
                counters[key] = counters.get(key, 0)+increment
    can_raise = 'raise' in legal or 'bet' in legal
    observe('three_bet', street == 'preflop' and len(pre) == 1 and can_raise, raises)
    observe('four_bet', street == 'preflop' and len(pre) == 2 and can_raise, raises)
    for count, name in ((2, 'fold_to_three_bet'), (3, 'fold_to_four_bet')):
        observe(name, street == 'preflop' and len(pre) == count and facing and 'fold' in legal
                and pre[-2]['seat'] == actor and pre[-1]['seat'] != actor, event['kind'] == 'fold')
    aggressor = pre[-1]['seat'] if pre else None
    observe('flop_cbet', street == 'flop' and aggressor == actor and not current and 'bet' in legal,
            event['kind'] == 'bet')
    observe('fold_to_flop_cbet', street == 'flop' and len(current) == 1 and facing
            and current[0]['seat'] == aggressor and current[0]['kind'] == 'bet' and 'fold' in legal,
            event['kind'] == 'fold')
    observe('turn_barrel', street == 'turn' and aggressor == actor and bool(flop)
            and flop[0]['seat'] == actor and flop[-1]['seat'] == actor
            and not current and 'bet' in legal, event['kind'] == 'bet')
    if raises:
        # Raise fraction counts the extra raise after calling, over pot after
        # calling. Integer comparisons preserve arbitrary legal chip magnitudes.
        extra = int(event['put_in'])-int(observation['to_call'])
        base = int(observation['pot'])+int(observation['to_call'])
        if extra <= 0 or base <= 0:
            raise PokerError('invalid public bet sizing amounts')
        bucket = next((name for percent, name in zip((25, 33, 50, 75, 100), SIZE_BUCKETS)
                       if extra*100 <= base*percent), 'over100')
        key = f'poker/size/{street}/{bucket}'
        counters[key] = counters.get(key, 0)+1


def summarize_frequencies(counters):
    rates = {}
    for name in NAMES:
        n, k = (counters.get(f'poker/{name}/{suffix}', 0) for suffix in ('opportunities', 'successes'))
        if type(n) is not int or type(k) is not int or not 0 <= k <= n:
            raise PokerError('invalid public frequency counters')
        rates[name] = {'opportunities': n, 'successes': k, 'observed_rate': k/n if n else None}
    return {'version': 'public-poker-frequencies-v1', 'rates': rates,
            'bet_sizes': {street: {b: counters.get(f'poker/size/{street}/{b}', 0) for b in SIZE_BUCKETS}
                          for street in ('preflop', 'flop', 'turn', 'river')},
            'bluff_frequency': None, 'balance_score': None,
            'limitations': ['未摊牌时不能确定诈唬；下注尺度统计本身不代表打法合理性。',
                           '机会数不是独立牌局数，小样本不能据此判定稳定风格。']}


def posterior_rate(counters, name, *, prior_mean, prior_strength=40.):
    """Beta posterior for an explicitly supplied baseline, not an automatic exploit."""
    if (name not in NAMES or not math.isfinite(prior_mean) or not 0 < prior_mean < 1
            or not math.isfinite(prior_strength) or prior_strength <= 0):
        raise PokerError('invalid opponent frequency prior')
    row = summarize_frequencies(counters)['rates'][name]
    n, k = row['opportunities'], row['successes']
    alpha = prior_mean*prior_strength+k
    beta = (1-prior_mean)*prior_strength+n-k
    total = alpha+beta
    return {'mean': alpha/total, 'variance': alpha*beta/(total*total*(total+1)),
            'opportunities': n, 'evidence_weight': n/(n+prior_strength),
            'prior_mean': prior_mean, 'prior_strength': prior_strength}
