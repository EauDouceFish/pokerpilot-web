"""Observation-only Monte Carlo reference analysis for no-limit hold'em.

This module deliberately implements a bounded rollout baseline. It is useful for
integration tests and teaching, but it is neither a trained model nor a claim of
GTO convergence.
"""

from __future__ import annotations

import math
import random
import time
from collections.abc import Mapping, Sequence
from copy import deepcopy
from typing import Any

from pokerlab.contracts import PokerError, STYLES, chips
from pokerlab.evaluator import evaluate_hand, side_pot_payouts
from pokerlab.opponent_profile import contextual_call_rate

ENGINE = "rollout-reference-v1"
STATUS = "research_baseline"
_DECK = tuple(rank + suit for rank in "23456789TJQKA" for suit in "cdhs")
_AGGRESSION = {
    "balanced": 0.0,
    "tight_aggressive": 0.12,
    "loose_aggressive": 0.22,
    "loose_passive": -0.14,
}
_CALL_RATE = {
    "balanced": 0.58,
    "tight_aggressive": 0.48,
    "loose_aggressive": 0.68,
    "loose_passive": 0.72,
}


def _number(value: Any, name: str) -> int:
    try:
        return chips(value)
    except PokerError as exc:
        raise PokerError(f"{name} 无效：{exc}") from exc


def _validate(observation: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(observation, Mapping):
        raise PokerError("observation 必须是对象")
    data = deepcopy(dict(observation))
    if data.get("is_terminal"):
        raise PokerError("牌局已经结束，没有可分析的决策")
    players = data.get("players")
    if not isinstance(players, list) or not 2 <= len(players) <= 9:
        raise PokerError("玩家数量必须为 2 到 9")
    actor, viewer = data.get("actor"), data.get("viewer")
    if not isinstance(actor, int) or not 0 <= actor < len(players) or viewer != actor:
        raise PokerError("求解输入必须由当前行动玩家的观察值生成")
    button = data.get("button")
    if not isinstance(button, int) or not 0 <= button < len(players):
        raise PokerError("button 座位无效")
    if any(not isinstance(player, Mapping) or player.get("seat") != seat for seat, player in enumerate(players)):
        raise PokerError("players 必须按物理座位顺序排列")
    if players[actor].get("status") != "active":
        raise PokerError("当前行动玩家必须处于 active 状态")

    hero = data.get("hero_cards")
    board = data.get("board")
    if not isinstance(hero, list) or len(hero) != 2 or not isinstance(board, list) or len(board) not in (0, 3, 4, 5):
        raise PokerError("英雄底牌或公共牌数量无效")
    from pokerlab.evaluator import parse_cards

    parse_cards([*hero, *board])
    for seat, player in enumerate(players):
        holes = player.get("hole_cards", [])
        if not isinstance(holes, list):
            raise PokerError("hole_cards 必须是数组")
        if seat != actor and holes:
            raise PokerError("分析输入不得包含对手隐藏底牌")
    if players[actor].get("hole_cards", hero) not in ([], hero):
        raise PokerError("英雄底牌与玩家观察值不一致")

    pot = _number(data.get("pot", "0"), "pot")
    declared_to_call = _number(data.get("to_call", "0"), "to_call")
    declared_min_raise = _number(data.get("min_raise_to", "0"), "min_raise_to")
    rules = data.get("rules")
    if not isinstance(rules, Mapping) or rules.get("ante_mode") not in ("none", "uniform", "big_blind"):
        raise PokerError("rules.ante_mode 无效")
    ante_mode = rules["ante_mode"]
    amounts: list[tuple[int, int, int, int, int]] = []
    for seat, player in enumerate(players):
        stack = _number(player.get("stack"), f"players[{seat}].stack")
        starting = _number(player.get("starting_stack"), f"players[{seat}].starting_stack")
        committed = _number(player.get("committed"), f"players[{seat}].committed")
        street = _number(player.get("street_committed"), f"players[{seat}].street_committed")
        if ante_mode != "none" and "ante_paid" not in player:
            raise PokerError("启用 ante 时每个玩家都必须提供 ante_paid")
        ante_paid = _number(player.get("ante_paid", "0"), f"players[{seat}].ante_paid")
        if player.get("status") not in ("active", "folded", "all_in", "out"):
            raise PokerError("玩家状态无效")
        if starting != stack + committed:
            raise PokerError("运行中牌局必须满足 starting_stack = stack + committed")
        if ante_paid > committed:
            raise PokerError("ante_paid 不能大于 committed")
        if ante_mode == "none" and ante_paid != 0:
            raise PokerError("ante_mode=none 时 ante_paid 必须为 0")
        if street > committed - ante_paid:
            raise PokerError("street_committed 不能大于 live committed")
        if player.get("status") == "all_in" and stack != 0:
            raise PokerError("all_in 玩家剩余筹码必须为 0")
        amounts.append((stack, starting, committed, ante_paid, street))
    if pot != sum(item[2] for item in amounts):
        raise PokerError("pot 必须等于所有玩家 committed 之和")

    actor_stack, _, _, _, actor_street = amounts[actor]
    round_target = max(item[4] for item in amounts)
    # A short all-in blind does not reduce the nominal preflop wager while
    # another active opponent still has chips to respond (BettingRound rule).
    if data.get("street") == "preflop" and any(
        seat != actor and player["status"] == "active" and amounts[seat][0] > 0
        for seat, player in enumerate(players)
    ):
        round_target = max(round_target, _number(rules.get("big_blind"), "big_blind"))
    actual_to_call = min(actor_stack, max(0, round_target - actor_street))
    if declared_to_call != actual_to_call:
        raise PokerError("to_call 与当前轮投入及筹码不一致")
    legal = data.get("legal_actions")
    if not isinstance(legal, list) or not legal:
        raise PokerError("当前行动没有合法动作")
    for action in legal:
        if not isinstance(action, Mapping) or action.get("kind") not in ("fold", "check", "call", "bet", "raise"):
            raise PokerError("合法动作格式无效")
        kind = action["kind"]
        amount_to = _number(action.get("amount_to"), "legal_actions.amount_to")
        put_in = _number(action.get("put_in"), "legal_actions.put_in")
        if not isinstance(action.get("all_in"), bool):
            raise PokerError("legal_actions.all_in 必须为布尔值")
        if kind in ("fold", "check"):
            if amount_to != actor_street or put_in != 0 or action["all_in"]:
                raise PokerError("fold/check 的金额必须等于当前轮已投入且 put_in 为 0")
            if kind == "check" and actual_to_call != 0:
                raise PokerError("仍需跟注时不能 check")
        elif kind == "call":
            if actual_to_call == 0 or amount_to != actor_street + actual_to_call or put_in != actual_to_call:
                raise PokerError("call 金额与实际待跟注额不一致")
            if action["all_in"] != (put_in == actor_stack):
                raise PokerError("call 的 all_in 标记与剩余筹码不一致")
        else:
            minimum = _number(action.get("min_to"), "legal_actions.min_to")
            maximum = _number(action.get("max_to"), "legal_actions.max_to")
            real_maximum = actor_street + actor_stack
            expected_kind = "bet" if round_target == 0 else "raise"
            if kind != expected_kind or not data.get("can_raise"):
                raise PokerError("bet/raise 与当前轮局面不一致")
            if maximum != real_maximum or not round_target < minimum <= maximum:
                raise PokerError("下注范围无效")
            if declared_min_raise != minimum:
                raise PokerError("min_raise_to 与合法加注范围不一致")
            if not minimum <= amount_to <= maximum or put_in != amount_to - actor_street:
                raise PokerError("bet/raise 金额与 put_in 不一致")
            if action["all_in"] != (put_in == actor_stack):
                raise PokerError("bet/raise 的 all_in 标记与剩余筹码不一致")
    return data


def _candidate_actions(data: Mapping[str, Any]) -> list[dict[str, Any]]:
    actor = data["actor"]
    street_paid = _number(data["players"][actor]["street_committed"], "street_committed")
    stack = _number(data["players"][actor]["stack"], "stack")
    pot = _number(data["pot"], "pot")
    candidates: list[dict[str, Any]] = []
    seen: set[tuple[str, int]] = set()
    for legal in data["legal_actions"]:
        kind = legal["kind"]
        if kind in ("bet", "raise"):
            minimum = _number(legal["min_to"], "min_to")
            maximum = _number(legal["max_to"], "max_to")
            proposed = [minimum, maximum]
            proposed.extend(street_paid + round(pot * fraction) for fraction in (0.33, 0.5, 0.75, 1.0))
            targets = sorted({max(minimum, min(maximum, target)) for target in proposed})
        else:
            targets = [_number(legal["amount_to"], "amount_to")]
        for target in targets:
            key = (kind, target)
            if key in seen:
                continue
            seen.add(key)
            put_in = min(stack, max(0, target - street_paid))
            if kind in ("fold", "check"):
                put_in = 0
            candidates.append(
                {
                    "kind": kind,
                    "amount_to": str(target),
                    "put_in": str(put_in),
                    "all_in": bool(legal["all_in"] or (put_in == stack and stack > 0)),
                }
            )
    return candidates


def _unit_rate(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise PokerError(f"{name} 无效")
    return max(0.0, min(1.0, float(value)))


def _profile_rate(style: str, stats: Mapping[str, Any], prefix: str) -> tuple[float, float]:
    base = _CALL_RATE[style]
    hands = min(1.0, _number(stats.get("hands", 0), f"{prefix}.hands") / 200.0)
    opportunities = min(1.0, _number(stats.get("opportunities", 0), f"{prefix}.opportunities") / 100.0)
    confidence = _unit_rate(stats.get("confidence", 1.0), f"{prefix}.confidence")
    weight = confidence * max(hands, opportunities)
    observations: list[float] = []
    if "fold_rate" in stats:
        observations.append(1.0 - _unit_rate(stats["fold_rate"], f"{prefix}.fold_rate"))
    if "vpip" in stats:
        observations.append(_unit_rate(stats["vpip"], f"{prefix}.vpip"))
    if "aggression" in stats:
        aggression = _unit_rate(stats["aggression"], f"{prefix}.aggression")
        observations.append(0.35 + 0.4 * aggression)
    observed_call = sum(observations) / len(observations) if observations else base
    rate = base * (1.0 - weight) + observed_call * weight
    return max(0.05, min(0.95, rate)), weight


def _opponent_models(
    data: Mapping[str, Any], mode: str, profile: Mapping[str, Any] | None
) -> tuple[dict[int, float], dict[str, Any]]:
    actor = data["actor"]
    seats = [player["seat"] for player in data["players"] if player["seat"] != actor]
    rates = {seat: _CALL_RATE["balanced"] for seat in seats}
    details: dict[str, Any] = {
        "source": "ignored_in_baseline" if mode == "baseline" else "stable_prior",
        "applied_seats": [],
        "confidence_weights": {},
        "styles": {str(seat): "balanced" for seat in seats},
    }
    if mode == "baseline" or not profile:
        return rates, details
    if not isinstance(profile, Mapping):
        raise PokerError("profile 必须是对象")
    source = profile.get("source", "unspecified")
    if not isinstance(source, str) or not source:
        raise PokerError("profile.source 必须是非空字符串")
    details["source"] = source
    selected: dict[int, Mapping[str, Any]] = {}
    opponents = profile.get("opponents")
    if opponents is not None:
        if not isinstance(opponents, Mapping):
            raise PokerError("profile.opponents 必须是按座位索引的对象")
        for raw_seat, opponent in opponents.items():
            try:
                seat = int(raw_seat)
            except (TypeError, ValueError) as exc:
                raise PokerError("profile.opponents 座位无效") from exc
            if str(seat) != str(raw_seat) or seat not in rates or not isinstance(opponent, Mapping):
                raise PokerError("profile.opponents 座位或内容无效")
            selected[seat] = opponent
    elif "target_seat" in profile:
        target = profile["target_seat"]
        if isinstance(target, bool) or not isinstance(target, int) or target not in rates:
            raise PokerError("profile.target_seat 无效")
        selected[target] = profile

    for seat, opponent in selected.items():
        opponent_style = opponent.get("style", "balanced")
        if opponent_style not in STYLES:
            raise PokerError("对手 style 不受支持")
        nested_stats = opponent.get("stats", opponent)
        if not isinstance(nested_stats, Mapping):
            raise PokerError("对手 stats 必须是对象")
        opportunity_profile = nested_stats.get("opportunity_profile")
        if opportunity_profile is None:
            rate, weight = _profile_rate(opponent_style, nested_stats, f"profile.opponents[{seat}]")
        else:
            rate, weight, evidence = contextual_call_rate(
                opportunity_profile, data["street"], _CALL_RATE[opponent_style]
            )
            rate = max(0.05, min(0.95, rate))
            details.setdefault("opportunity_evidence", {})[str(seat)] = evidence
        rates[seat] = rate
        details["applied_seats"].append(seat)
        details["confidence_weights"][str(seat)] = weight
        details["styles"][str(seat)] = opponent_style
    return rates, details


def _deal(data: Mapping[str, Any], rng: random.Random) -> tuple[dict[int, list[str]], list[str]]:
    actor = data["actor"]
    known = set(data["hero_cards"] + data["board"])
    deck = [card for card in _DECK if card not in known]
    rng.shuffle(deck)
    holes: dict[int, list[str]] = {actor: list(data["hero_cards"])}
    cursor = 0
    for player in data["players"]:
        seat = player["seat"]
        if seat != actor and player["status"] in ("active", "all_in"):
            holes[seat] = deck[cursor : cursor + 2]
            cursor += 2
    needed = 5 - len(data["board"])
    board = list(data["board"]) + deck[cursor : cursor + needed]
    return holes, board


def _rollout(
    data: Mapping[str, Any],
    action: Mapping[str, Any],
    holes: Mapping[int, Sequence[str]],
    board: Sequence[str],
    rng: random.Random,
    call_rates: Mapping[int, float],
) -> float:
    actor = data["actor"]
    if action["kind"] == "fold":
        return 0.0
    ante_paid = [_number(player.get("ante_paid", "0"), "ante_paid") for player in data["players"]]
    contributions = [
        _number(player["committed"], "committed") - ante_paid[player["seat"]]
        for player in data["players"]
    ]
    dead_money = sum(ante_paid)
    folded = {player["seat"] for player in data["players"] if player["status"] in ("folded", "out")}
    hero_extra = _number(action["put_in"], "put_in")
    contributions[actor] += hero_extra
    target = _number(action["amount_to"], "amount_to")
    round_target = max(
        target,
        max(_number(player["street_committed"], "street_committed") for player in data["players"]),
    )

    for player in data["players"]:
        seat = player["seat"]
        if seat == actor or player["status"] != "active":
            continue
        street_paid = _number(player["street_committed"], "street_committed")
        owed = max(0, round_target - street_paid)
        if owed:
            needed = min(_number(player["stack"], "stack"), owed)
            pressure = needed / max(1, _number(data["pot"], "pot") + needed)
            probability = max(0.03, min(0.97, call_rates[seat] - 0.32 * pressure))
            if rng.random() <= probability:
                contributions[seat] += needed
            else:
                folded.add(seat)

    ranks = {
        seat: evaluate_hand([*cards, *board])
        for seat, cards in holes.items()
        if seat not in folded
    }
    player_count = len(data["players"])
    first = (data["button"] + 1) % player_count
    seat_order = [(first + offset) % player_count for offset in range(player_count)]
    payouts = side_pot_payouts(
        contributions,
        folded,
        ranks,
        dead_money=dead_money,
        seat_order=seat_order,
    )
    return float(payouts[actor] - hero_extra)


def _probabilities(actions: Sequence[Mapping[str, Any]], evs: Sequence[float], style: str, big_blind: int) -> list[float]:
    scores: list[float] = []
    for action, ev in zip(actions, evs, strict=True):
        bias = 0.0
        if action["kind"] in ("bet", "raise"):
            bias = _AGGRESSION[style] * big_blind
        elif action["kind"] in ("call", "check") and style == "loose_passive":
            bias = 0.08 * big_blind
        elif action["kind"] == "fold" and style == "tight_aggressive":
            bias = 0.04 * big_blind
        scores.append((ev + bias) / max(1.0, float(big_blind)))
    peak = max(scores)
    weights = [math.exp(max(-40.0, min(0.0, score - peak))) for score in scores]
    total = sum(weights)
    return [weight / total for weight in weights]


def _analyze_samples(
    observation: Mapping[str, Any],
    *,
    mode: str,
    style: str,
    profile: Mapping[str, Any] | None,
    seed: int,
    sample_limit: int,
    deadline: float | None,
) -> dict[str, Any]:
    started = time.perf_counter()
    data = _validate(observation)
    if mode not in ("baseline", "exploit"):
        raise PokerError("mode 必须为 baseline 或 exploit")
    if style not in STYLES:
        raise PokerError("style 不受支持")
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise PokerError("seed 必须为整数")
    if not isinstance(sample_limit, int) or sample_limit < 1:
        raise PokerError("samples 必须为正整数")
    actions = _candidate_actions(data)
    rng = random.Random(seed)
    call_rates, profile_details = _opponent_models(data, mode, profile)
    totals = [0.0] * len(actions)
    completed = 0
    deadline_hit = False
    while completed < sample_limit:
        if deadline is not None and completed and time.perf_counter() >= deadline:
            deadline_hit = True
            break
        holes, board = _deal(data, rng)
        for index, action in enumerate(actions):
            totals[index] += _rollout(data, action, holes, board, rng, call_rates)
        completed += 1
    evs = [total / completed for total in totals]
    big_blind = _number(data.get("rules", {}).get("big_blind", "1"), "big_blind")
    probabilities = _probabilities(actions, evs, style, max(1, big_blind))
    output_actions = []
    for action, probability, ev in zip(actions, probabilities, evs, strict=True):
        output_actions.append(
            {
                **action,
                "probability": probability,
                "ev_chips": ev,
                "ev_bb": ev / max(1, big_blind),
            }
        )
    chosen = rng.choices(output_actions, weights=probabilities, k=1)[0].copy()
    elapsed = (time.perf_counter() - started) * 1000.0
    return {
        "status": STATUS,
        "engine": ENGINE,
        "mode": mode,
        "model_loaded": False,
        "actions": output_actions,
        "chosen_action": chosen,
        "explanations": [
            f"参考引擎使用 {completed} 次公开信息蒙特卡洛发牌，并假设行动后各方跟注或弃牌，随后直接摊牌。",
            f"当前为{('基础' if mode == 'baseline' else '对手适应')}模式；画像来源为 {profile_details['source']}，应用座位为 {profile_details['applied_seats']}。",
            "结果只用于研究基线：有限样本、简化对手响应和直接摊牌假设会带来未量化误差，不能视为 GTO 精度证明。",
        ],
        "timing": {"total_ms": elapsed},
        "diagnostics": {
            "samples": completed,
            "sample_limit": sample_limit,
            "candidate_actions": len(actions),
            "deadline_hit": deadline_hit,
            "profile": profile_details,
            "approximation": "sampled hidden cards; style/profile response model; checkdown after root response",
            "uncertainty": "sampling error is not a certification of strategy quality",
        },
    }


def analyze(
    observation: dict[str, Any],
    *,
    mode: str = "baseline",
    style: str = "balanced",
    profile: dict[str, Any] | None = None,
    budget_ms: int = 500,
    seed: int = 0,
) -> dict[str, Any]:
    """Analyze one public decision under a measured, bounded time budget."""

    if isinstance(budget_ms, bool) or not isinstance(budget_ms, int) or not 1 <= budget_ms <= 60_000:
        raise PokerError("budget_ms 必须是 1 到 60000 的整数")
    started = time.perf_counter()
    sample_limit = max(1, min(256, budget_ms // 3))
    return _analyze_samples(
        observation,
        mode=mode,
        style=style,
        profile=profile,
        seed=seed,
        sample_limit=sample_limit,
        deadline=started + budget_ms / 1000.0,
    )


def analyze_fixed_samples(
    observation: dict[str, Any],
    *,
    samples: int,
    mode: str = "baseline",
    style: str = "balanced",
    profile: dict[str, Any] | None = None,
    seed: int = 0,
) -> dict[str, Any]:
    """Deterministic-count companion used for reproducibility tests."""

    return _analyze_samples(
        observation,
        mode=mode,
        style=style,
        profile=profile,
        seed=seed,
        sample_limit=samples,
        deadline=None,
    )
