"""Small transactional local store; private hand specifications never leave it."""

from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .contracts import PokerError
from .opponent_profile import summarize_state, update_state


class ActionConflict(PokerError):
    """The persisted hand no longer matches an action's expected version."""


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Store:
    def __init__(self, path: str | Path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path, check_same_thread=False)
        self.connection.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.connection:
            self.connection.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS profiles (
                    id TEXT PRIMARY KEY, name TEXT NOT NULL,
                    epoch INTEGER NOT NULL DEFAULT 0, stats TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS profile_models (
                    profile_id TEXT PRIMARY KEY,
                    epoch INTEGER NOT NULL,
                    data TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS hands (
                    id TEXT PRIMARY KEY, spec TEXT NOT NULL, events TEXT NOT NULL,
                    complete INTEGER NOT NULL, created_at TEXT NOT NULL,
                    profile_id TEXT, profile_epoch INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS requests (
                    hand_id TEXT NOT NULL, id TEXT NOT NULL,
                    payload TEXT NOT NULL, response TEXT NOT NULL,
                    PRIMARY KEY(hand_id,id)
                );
                CREATE TABLE IF NOT EXISTS hand_successors (
                    parent_id TEXT PRIMARY KEY,
                    hand_id TEXT NOT NULL UNIQUE,
                    payload TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS executed_policies (
                    hand_id TEXT NOT NULL, event_index INTEGER NOT NULL,
                    request_id TEXT NOT NULL, policy BLOB NOT NULL,
                    PRIMARY KEY(hand_id,event_index)
                );
            """)

    def close(self) -> None:
        with self.lock:
            self.connection.close()

    def profile(self, row: sqlite3.Row) -> dict:
        from .poker_frequencies import summarize_frequencies
        counters = json.loads(row["stats"])
        hands = counters.get("hands", 0)
        calls = counters.get("facing_bet", 0)
        decisions = counters.get("decisions", 0)
        opportunity_profile = None
        if row["model_data"] is not None and row["model_epoch"] == row["epoch"]:
            opportunity_profile = summarize_state(json.loads(row["model_data"]), now())
        nested = ({"opportunity_profile": opportunity_profile}
                  if opportunity_profile is not None else {})
        return {"id": row["id"], "name": row["name"], "epoch": row["epoch"],
                "hands": hands, "created_at": row["created_at"],
                "stats": {**counters,
                          "poker_frequencies": summarize_frequencies(counters),
                          "vpip": counters.get("vpip_hands", 0) / max(hands, 1),
                          "fold_rate": (counters.get("folds", 0) + 2) / (calls + 5),
                          "aggression": (counters.get("raises", 0) + 2) / (decisions + 6),
                          "opportunities": calls,
                          "confidence": hands / (hands + 50),
                          **nested}}

    def profiles(self) -> list[dict]:
        with self.lock:
            return [self.profile(r) for r in self.connection.execute(
                """SELECT p.*,m.epoch AS model_epoch,m.data AS model_data
                   FROM profiles p LEFT JOIN profile_models m ON m.profile_id=p.id
                   ORDER BY p.created_at""")]

    def create_profile(self, name: str) -> dict:
        name = name.strip()
        if not name or len(name) > 40:
            raise PokerError("玩家名称需为 1 至 40 个字符")
        key = uuid.uuid4().hex
        with self.lock, self.connection:
            self.connection.execute("INSERT INTO profiles VALUES(?,?,0,?,?)",
                                    (key, name, "{}", now()))
        return self.get_profile(key)

    def get_profile(self, key: str) -> dict:
        with self.lock:
            row = self.connection.execute(
                """SELECT p.*,m.epoch AS model_epoch,m.data AS model_data
                   FROM profiles p LEFT JOIN profile_models m ON m.profile_id=p.id
                   WHERE p.id=?""",
                (key,),
            ).fetchone()
            if row is None:
                raise KeyError("玩家档案不存在")
            return self.profile(row)

    def reset_profile(self, key: str) -> dict:
        with self.lock, self.connection:
            cursor = self.connection.execute(
                "UPDATE profiles SET stats='{}',epoch=epoch+1 WHERE id=?", (key,))
            if not cursor.rowcount:
                raise KeyError("玩家档案不存在")
            self.connection.execute("DELETE FROM profile_models WHERE profile_id=?", (key,))
        return self.get_profile(key)

    def _save_terminal_counters(self, profile_id: str | None, profile_epoch: int,
                                counters: dict[str, Any] | None) -> None:
        if not profile_id or not counters:
            return
        profile = self.connection.execute("SELECT * FROM profiles WHERE id=?",
                                          (profile_id,)).fetchone()
        if profile is None or profile["epoch"] != profile_epoch:
            return
        scalar_counters = dict(counters)
        opportunity_counts = scalar_counters.pop("opportunity_counts", None)
        stats = json.loads(profile["stats"])
        for name, value in scalar_counters.items():
            stats[name] = stats.get(name, 0) + value
        self.connection.execute("UPDATE profiles SET stats=? WHERE id=?",
                                (json.dumps(stats), profile_id))
        if opportunity_counts is not None:
            row = self.connection.execute(
                "SELECT epoch,data FROM profile_models WHERE profile_id=?", (profile_id,)
            ).fetchone()
            previous = (json.loads(row["data"])
                        if row is not None and row["epoch"] == profile_epoch else None)
            state = update_state(previous, opportunity_counts, now())
            self.connection.execute(
                """INSERT INTO profile_models(profile_id,epoch,data) VALUES(?,?,?)
                   ON CONFLICT(profile_id) DO UPDATE SET epoch=excluded.epoch,data=excluded.data""",
                (profile_id, profile_epoch, json.dumps(state, allow_nan=False)),
            )

    def add_hand(self, key: str, spec: dict, events: list, complete: bool,
                 counters: dict[str, Any] | None = None) -> None:
        with self.lock, self.connection:
            self.connection.execute("INSERT INTO hands VALUES(?,?,?,?,?,?,?)", (
                key, json.dumps(spec), json.dumps(events), int(complete), now(),
                spec.get("profile_id"), spec.get("profile_epoch", 0)))
            if complete:
                self._save_terminal_counters(spec.get("profile_id"),
                                             spec.get("profile_epoch", 0), counters)

    def successor(self, parent_id: str) -> dict | None:
        with self.lock:
            row = self.connection.execute(
                "SELECT hand_id,payload FROM hand_successors WHERE parent_id=?",
                (parent_id,)).fetchone()
            if row is None:
                return None
            return {"hand_id": row["hand_id"], "payload": json.loads(row["payload"])}

    def add_successor(self, parent_id: str, child_id: str, spec: dict, events: list,
                      complete: bool, payload: dict,
                      counters: dict[str, Any] | None = None) -> tuple[str, bool]:
        spec_json = json.dumps(spec, allow_nan=False)
        events_json = json.dumps(events, allow_nan=False)
        payload_json = json.dumps(payload, sort_keys=True, separators=(",", ":"),
                                  allow_nan=False)
        with self.lock:
            self.connection.execute("BEGIN IMMEDIATE")
            try:
                parent = self.connection.execute(
                    "SELECT complete FROM hands WHERE id=?", (parent_id,)).fetchone()
                if parent is None:
                    raise PokerError("上一手牌局不存在")
                if not parent["complete"]:
                    raise PokerError("上一手尚未结束，不能创建下一手")
                existing = self.connection.execute(
                    "SELECT hand_id,payload FROM hand_successors WHERE parent_id=?",
                    (parent_id,)).fetchone()
                if existing is not None:
                    if existing["payload"] != payload_json:
                        raise PokerError("上一手已使用不同配置创建下一手")
                    self.connection.commit()
                    return existing["hand_id"], False
                self.connection.execute("INSERT INTO hands VALUES(?,?,?,?,?,?,?)", (
                    child_id, spec_json, events_json, int(complete), now(),
                    spec.get("profile_id"), spec.get("profile_epoch", 0)))
                self.connection.execute(
                    "INSERT INTO hand_successors VALUES(?,?,?,?)",
                    (parent_id, child_id, payload_json, now()))
                if complete:
                    self._save_terminal_counters(spec.get("profile_id"),
                                                 spec.get("profile_epoch", 0), counters)
                self.connection.commit()
                return child_id, True
            except BaseException:
                self.connection.rollback()
                raise

    def load_hand(self, key: str) -> dict:
        with self.lock:
            row = self.connection.execute("SELECT * FROM hands WHERE id=?", (key,)).fetchone()
            if row is None:
                raise KeyError("牌局不存在")
            return {**dict(row), "spec": json.loads(row["spec"]),
                    "events": json.loads(row["events"])}

    def history(self) -> list[dict]:
        with self.lock:
            result = []
            for row in self.connection.execute("SELECT * FROM hands ORDER BY created_at DESC LIMIT 200"):
                spec = json.loads(row["spec"])
                result.append({"id": row["id"], "created_at": row["created_at"],
                               "players": len(spec["stacks"]), "complete": bool(row["complete"]),
                               "profile_id": row["profile_id"], "hero_seat": spec["hero_seat"]})
            return result

    def prior_request(self, hand_id: str, request_id: str, payload: dict) -> dict | None:
        with self.lock:
            row = self.connection.execute("SELECT * FROM requests WHERE hand_id=? AND id=?",
                                          (hand_id, request_id)).fetchone()
            if row is None:
                return None
            if json.loads(row["payload"]) != payload:
                raise PokerError("请求标识已用于不同操作")
            return json.loads(row["response"])

    def save_action(self, hand_id: str, events: list, complete: bool,
                    request_id: str, payload: dict, response: dict,
                    counters: dict[str, Any] | None = None, *, expected_version: int,
                    policy_record=None) -> dict:
        if type(expected_version) is not int or expected_version < 0:
            raise PokerError("预期版本必须是非负整数")
        events_json = json.dumps(events, allow_nan=False)
        payload_json = json.dumps(payload, sort_keys=True, allow_nan=False)
        response_json = json.dumps(response, allow_nan=False)
        if counters is not None:
            json.dumps(counters, allow_nan=False)
        candidate_events = json.loads(events_json)
        canonical_payload = json.loads(payload_json)
        policy_blob = None
        if policy_record is not None:
            from .policy_history import pack_decision
            policy_blob = pack_decision(policy_record)
            self._check_policy_event(policy_record, candidate_events, expected_version)
        with self.lock:
            self.connection.execute("BEGIN IMMEDIATE")
            try:
                prior = self.connection.execute(
                    "SELECT payload,response FROM requests WHERE hand_id=? AND id=?",
                    (hand_id, request_id)).fetchone()
                if prior is not None:
                    if json.loads(prior["payload"]) != canonical_payload:
                        raise PokerError("请求标识已用于不同操作")
                    result = json.loads(prior["response"])
                    self.connection.commit()
                    return result
                row = self.connection.execute(
                    "SELECT * FROM hands WHERE id=?", (hand_id,)).fetchone()
                if row is None:
                    raise KeyError("牌局不存在")
                persisted_events = json.loads(row["events"])
                if row["complete"] or len(persisted_events) != expected_version:
                    raise ActionConflict("牌局版本已变化或牌局已经结束")
                if (not isinstance(candidate_events, list)
                        or len(candidate_events) != len(persisted_events) + 1
                        or candidate_events[:-1] != persisted_events):
                    raise PokerError("候选行动历史必须严格追加一条行动")
                self.connection.execute("UPDATE hands SET events=?,complete=? WHERE id=?",
                                        (events_json, int(complete), hand_id))
                self.connection.execute("INSERT INTO requests VALUES(?,?,?,?)", (
                    hand_id, request_id, payload_json, response_json))
                if policy_blob is not None:
                    self.connection.execute("INSERT INTO executed_policies VALUES(?,?,?,?)",
                        (hand_id, expected_version, request_id, policy_blob))
                if complete and row["profile_id"] and counters:
                    self._save_terminal_counters(row["profile_id"], row["profile_epoch"], counters)
                result = json.loads(response_json)
                self.connection.commit()
                return result
            except BaseException:
                self.connection.rollback()
                raise

    @staticmethod
    def _check_policy_event(record, events, index):
        if type(index) is not int or not 0 <= index < len(events):
            raise PokerError("executed policy has no corresponding action")
        fields = ("seat", "kind", "amount_to", "put_in", "street", "version")
        prefix = tuple(tuple(event[name] for name in fields) for event in events[:index])
        event = events[index]
        action = (event["kind"], int(event["amount_to"]) if event["kind"] in ("bet", "raise") else None)
        if record.key[8] != prefix or record.key[1] != event["seat"] or action not in record.actions:
            raise PokerError("executed policy does not match committed action history")

    def policy_history(self, hand_id, *, before, seat=None):
        from .policy_history import PolicyHistory, unpack_decision
        if type(before) is not int or before < 0:
            raise PokerError("invalid policy history position")
        with self.lock:
            hand = self.load_hand(hand_id)
            if before > len(hand["events"]):
                raise PokerError("policy history position is beyond committed actions")
            records = {}
            for row in self.connection.execute(
                    "SELECT event_index,policy FROM executed_policies WHERE hand_id=? AND event_index<? ORDER BY event_index",
                    (hand_id, before)):
                record = unpack_decision(row["policy"])
                self._check_policy_event(record, hand["events"], row["event_index"])
                if seat is None or record.key[1] == seat:
                    records[record.key] = record
            return PolicyHistory(hand_id, records)
