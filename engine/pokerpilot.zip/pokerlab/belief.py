"""Traceable public-information hand ranges and unbiased joint sampling.

This module does not infer action likelihoods and does not claim learned or GTO
ranges.  Callers may supply priors and externally computed likelihood vectors;
every such source is retained on the returned immutable state.
"""

from __future__ import annotations

import bisect
import math
import random
import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from itertools import combinations
from types import MappingProxyType
from typing import Any

import numpy as np

from pokerlab.contracts import PokerError
from pokerlab.evaluator import parse_cards

DECK = tuple(rank + suit for rank in "23456789TJQKA" for suit in "cdhs")
COMBOS = tuple(combinations(DECK, 2))
_COMBO_INDEX = {combo: index for index, combo in enumerate(COMBOS)}
_CARD_INDEX = {card: index for index, card in enumerate(DECK)}
_COMBO_MASKS = np.asarray(
    [(1 << _CARD_INDEX[left]) | (1 << _CARD_INDEX[right]) for left, right in COMBOS],
    dtype=np.uint64,
)


def _readonly(values: np.ndarray) -> np.ndarray:
    """Use immutable bytes as backing storage so writeability cannot be restored."""

    array = np.ascontiguousarray(values, dtype=np.float64)
    return np.frombuffer(array.tobytes(), dtype=np.float64)


def _normalize(values: np.ndarray, name: str) -> np.ndarray:
    array = np.asarray(values, dtype=np.float64)
    if array.shape != (len(COMBOS),):
        raise PokerError(f"{name} 长度必须为 {len(COMBOS)}")
    if not np.isfinite(array).all():
        raise PokerError(f"{name} 不能包含 NaN 或无穷值")
    if (array < 0).any():
        raise PokerError(f"{name} 不能包含负权重")
    total = float(array.sum(dtype=np.float64))
    if not math.isfinite(total) or total <= 0:
        raise PokerError(f"{name} 的有效权重总和必须大于 0")
    return _readonly(array / total)


def _canonical_card(value: Any) -> str:
    if not isinstance(value, str):
        raise PokerError("牌必须使用 As、Td、2c 格式")
    parse_cards([value])
    return value[0].upper() + value[1].lower()


def _canonical_cards(values: Any, name: str, *, valid_counts: set[int] | None = None) -> tuple[str, ...]:
    if not isinstance(values, (list, tuple)):
        raise PokerError(f"{name} 必须是牌面数组")
    cards = tuple(_canonical_card(value) for value in values)
    if valid_counts is not None and len(cards) not in valid_counts:
        expected = "、".join(str(count) for count in sorted(valid_counts))
        raise PokerError(f"{name} 数量必须为 {expected}")
    parse_cards(cards)
    return cards


def _canonical_combo(value: Any) -> tuple[str, str]:
    if not isinstance(value, str):
        raise PokerError("范围组合必须使用 'As Kh' 格式")
    raw_cards = value.split()
    if len(raw_cards) != 2:
        raise PokerError("范围组合必须恰好包含两张牌，例如 'As Kh'")
    cards = _canonical_cards(raw_cards, "范围组合", valid_counts={2})
    return tuple(sorted(cards, key=_CARD_INDEX.__getitem__))  # type: ignore[return-value]


def _blocker_mask(cards: Sequence[str]) -> int:
    mask = 0
    for card in cards:
        mask |= 1 << _CARD_INDEX[card]
    return mask


def _masked(weights: np.ndarray, blocked: Sequence[str], name: str) -> np.ndarray:
    blocker_mask = np.uint64(_blocker_mask(blocked))
    allowed = np.bitwise_and(_COMBO_MASKS, blocker_mask) == 0
    return _normalize(np.where(allowed, weights, 0.0), name)


def _cdf(weights: np.ndarray) -> np.ndarray:
    cumulative = np.cumsum(weights, dtype=np.float64)
    cumulative[-1] = 1.0
    return _readonly(cumulative)


def _diagnostics(weights: Sequence[np.ndarray], board: Sequence[str], dead_cards: Sequence[str]) -> Mapping[str, Any]:
    supports = tuple(int(np.count_nonzero(vector)) for vector in weights)
    return MappingProxyType(
        {
            "combo_count": len(COMBOS),
            "support_sizes": supports,
            "public_blockers": tuple(board) + tuple(dead_cards),
            "conditioning": "public board and explicit dead_cards only",
            "known_private_sampling": "independent conditional evaluation only; not public search state",
        }
    )


@dataclass(frozen=True, slots=True)
class BeliefState:
    """Immutable per-physical-seat factorized ranges over all 1,326 combos."""

    weights: tuple[np.ndarray, ...]
    board: tuple[str, ...]
    dead_cards: tuple[str, ...]
    sources: tuple[tuple[str, ...], ...]
    diagnostics: Mapping[str, Any]
    _cdfs: tuple[np.ndarray, ...] = field(repr=False, compare=False)

    @property
    def player_count(self) -> int:
        return len(self.weights)

    def update(self, seat: int, likelihoods: Sequence[float], source: str) -> BeliefState:
        if isinstance(seat, bool) or not isinstance(seat, int) or not 0 <= seat < self.player_count:
            raise PokerError("更新范围的座位无效")
        if not isinstance(source, str) or not source.strip():
            raise PokerError("行动似然必须提供非空来源")
        try:
            likelihood = np.asarray(likelihoods, dtype=np.float64)
        except (TypeError, ValueError) as exc:
            raise PokerError("行动似然必须是数值序列") from exc
        if likelihood.shape != (len(COMBOS),):
            raise PokerError(f"行动似然长度必须为 {len(COMBOS)}")
        if not np.isfinite(likelihood).all():
            raise PokerError("行动似然不能包含 NaN 或无穷值")
        if (likelihood < 0).any():
            raise PokerError("行动似然不能包含负值")
        posterior = _normalize(self.weights[seat] * likelihood, f"座位 {seat} 后验范围")
        weights = list(self.weights)
        weights[seat] = posterior
        sources = list(self.sources)
        sources[seat] = (*sources[seat], source.strip())
        frozen_weights = tuple(weights)
        return BeliefState(
            weights=frozen_weights,
            board=self.board,
            dead_cards=self.dead_cards,
            sources=tuple(sources),
            diagnostics=_diagnostics(frozen_weights, self.board, self.dead_cards),
            _cdfs=tuple(_cdf(vector) for vector in frozen_weights),
        )

    def with_board(self, board: Sequence[str]) -> BeliefState:
        next_board = _canonical_cards(board, "board", valid_counts={0, 3, 4, 5})
        if next_board[: len(self.board)] != self.board or len(next_board) < len(self.board):
            raise PokerError("新公共牌必须保留已经公开的 board 前缀")
        parse_cards((*next_board, *self.dead_cards))
        blocked = (*next_board, *self.dead_cards)
        weights = tuple(
            _masked(vector, blocked, f"座位 {seat} 新公共牌过滤范围")
            for seat, vector in enumerate(self.weights)
        )
        reveal = " ".join(next_board[len(self.board) :]) or "unchanged"
        sources = tuple((*seat_sources, f"public_board:{reveal}") for seat_sources in self.sources)
        return BeliefState(
            weights=weights,
            board=next_board,
            dead_cards=self.dead_cards,
            sources=sources,
            diagnostics=_diagnostics(weights, next_board, self.dead_cards),
            _cdfs=tuple(_cdf(vector) for vector in weights),
        )

    def sample_joint(
        self,
        rng: random.Random,
        *,
        known_private: dict[int, list[str]] | None = None,
        max_attempts: int = 10_000,
        deadline: float | None = None,
    ) -> dict[int, tuple[str, str]]:
        if not isinstance(rng, random.Random):
            raise PokerError("rng 必须是 random.Random")
        if isinstance(max_attempts, bool) or not isinstance(max_attempts, int) or max_attempts < 1:
            raise PokerError("max_attempts 必须是正整数")
        if deadline is not None and (
            isinstance(deadline, bool)
            or not isinstance(deadline, (int, float))
            or not math.isfinite(deadline)
        ):
            raise PokerError("deadline 必须是有限的绝对 perf-counter 时间")
        absolute_deadline = None if deadline is None else float(deadline)

        def check_deadline() -> None:
            if absolute_deadline is not None and time.perf_counter() >= absolute_deadline:
                raise TimeoutError("整组拒绝采样超过 deadline")

        check_deadline()
        fixed: dict[int, tuple[str, str]] = {}
        fixed_mask = _blocker_mask((*self.board, *self.dead_cards))
        if known_private is not None:
            if not isinstance(known_private, dict):
                raise PokerError("known_private 必须是座位到两张牌的字典")
            for seat, raw_cards in known_private.items():
                if isinstance(seat, bool) or not isinstance(seat, int) or not 0 <= seat < self.player_count:
                    raise PokerError("known_private 座位无效")
                cards = _canonical_cards(raw_cards, f"known_private[{seat}]", valid_counts={2})
                combo = tuple(sorted(cards, key=_CARD_INDEX.__getitem__))
                combo_mask = _blocker_mask(combo)
                if combo_mask & fixed_mask:
                    raise PokerError("known_private 与公共牌、dead_cards 或其他已知私牌冲突")
                combo_index = _COMBO_INDEX[combo]
                if self.weights[seat][combo_index] <= 0:
                    raise PokerError("known_private 在该座位范围中的概率为 0")
                fixed[seat] = combo
                fixed_mask |= combo_mask

        sampling_cdfs: dict[int, np.ndarray] = {}
        for seat in range(self.player_count):
            if seat in fixed:
                continue
            if known_private:
                allowed = np.bitwise_and(_COMBO_MASKS, np.uint64(fixed_mask)) == 0
                conditioned = _normalize(
                    np.where(allowed, self.weights[seat], 0.0),
                    f"座位 {seat} known_private 条件范围",
                )
                sampling_cdfs[seat] = _cdf(conditioned)
            else:
                sampling_cdfs[seat] = self._cdfs[seat]

        free_seats = tuple(seat for seat in range(self.player_count) if seat not in fixed)
        for attempt in range(max_attempts):
            if attempt % 64 == 0:
                check_deadline()
            sample = dict(fixed)
            used_mask = fixed_mask
            compatible = True
            # Every free seat is drawn from its own unchanged marginal first.  A
            # collision rejects the whole joint draw; no later seat is reweighted.
            candidates: list[tuple[int, tuple[str, str], int]] = []
            for seat in free_seats:
                draw = rng.random()
                index = bisect.bisect_right(sampling_cdfs[seat], draw)
                index = min(index, len(COMBOS) - 1)
                combo = COMBOS[index]
                candidates.append((seat, combo, int(_COMBO_MASKS[index])))
            for seat, combo, combo_mask in candidates:
                if combo_mask & used_mask:
                    compatible = False
                    break
                sample[seat] = combo
                used_mask |= combo_mask
            if compatible:
                check_deadline()
                return {seat: sample[seat] for seat in range(self.player_count)}
        raise PokerError(f"在 {max_attempts} 次整组拒绝采样后仍未找到牌张相容的联合手牌")


def build_belief(
    observation: Mapping[str, Any],
    ranges: Mapping[int, Mapping[str, float]] | None = None,
) -> BeliefState:
    """Build public ranges without conditioning any seat on actual hero cards."""

    if not isinstance(observation, Mapping):
        raise PokerError("observation 必须是对象")
    players = observation.get("players")
    if not isinstance(players, list) or not 2 <= len(players) <= 9:
        raise PokerError("玩家数量必须为 2 到 9")
    viewer = observation.get("viewer")
    if isinstance(viewer, bool) or not isinstance(viewer, int) or not 0 <= viewer < len(players):
        raise PokerError("viewer 座位无效")
    for seat, player in enumerate(players):
        if not isinstance(player, Mapping) or player.get("seat") != seat:
            raise PokerError("players 必须按物理座位顺序排列")
        holes = player.get("hole_cards", [])
        if not isinstance(holes, list):
            raise PokerError("hole_cards 必须是数组")
        if seat != viewer and holes:
            raise PokerError("公共范围输入不得包含对手隐藏底牌")
        if holes:
            _canonical_cards(holes, f"players[{seat}].hole_cards", valid_counts={2})
    hero_cards = _canonical_cards(observation.get("hero_cards", []), "hero_cards", valid_counts={0, 2})
    viewer_cards = _canonical_cards(players[viewer].get("hole_cards", []), "viewer.hole_cards", valid_counts={0, 2})
    if hero_cards and viewer_cards and set(hero_cards) != set(viewer_cards):
        raise PokerError("hero_cards 与 viewer 的底牌不一致")

    board = _canonical_cards(observation.get("board", []), "board", valid_counts={0, 3, 4, 5})
    dead_cards = _canonical_cards(observation.get("dead_cards", []), "dead_cards")
    parse_cards((*board, *dead_cards))
    # Validate the actual hand without conditioning public ranges on it.
    parse_cards((*board, *dead_cards, *(hero_cards or viewer_cards)))
    blocked = (*board, *dead_cards)

    if ranges is not None and not isinstance(ranges, Mapping):
        raise PokerError("ranges 必须是座位到组合权重字典的映射")
    supplied = dict(ranges or {})
    for seat in supplied:
        if isinstance(seat, bool) or not isinstance(seat, int) or not 0 <= seat < len(players):
            raise PokerError("ranges 包含无效座位")

    weights: list[np.ndarray] = []
    sources: list[tuple[str, ...]] = []
    for seat in range(len(players)):
        if seat not in supplied:
            prior = np.ones(len(COMBOS), dtype=np.float64)
            source = ("uniform_prior",)
        else:
            seat_range = supplied[seat]
            if not isinstance(seat_range, Mapping) or not seat_range:
                raise PokerError(f"ranges[{seat}] 必须是非空组合权重映射")
            prior = np.zeros(len(COMBOS), dtype=np.float64)
            seen: set[tuple[str, str]] = set()
            for raw_combo, raw_weight in seat_range.items():
                combo = _canonical_combo(raw_combo)
                if combo in seen:
                    raise PokerError(f"ranges[{seat}] 包含重复组合")
                seen.add(combo)
                if isinstance(raw_weight, bool) or not isinstance(raw_weight, (int, float)):
                    raise PokerError(f"ranges[{seat}] 权重必须是数值")
                weight = float(raw_weight)
                if not math.isfinite(weight):
                    raise PokerError(f"ranges[{seat}] 权重不能包含 NaN 或无穷值")
                if weight < 0:
                    raise PokerError(f"ranges[{seat}] 权重不能为负")
                prior[_COMBO_INDEX[combo]] = weight
            source = ("provided_range",)
        weights.append(_masked(prior, blocked, f"座位 {seat} 公共 blocker 过滤范围"))
        sources.append(source)

    frozen_weights = tuple(weights)
    return BeliefState(
        weights=frozen_weights,
        board=board,
        dead_cards=dead_cards,
        sources=tuple(sources),
        diagnostics=_diagnostics(frozen_weights, board, dead_cards),
        _cdfs=tuple(_cdf(vector) for vector in frozen_weights),
    )
