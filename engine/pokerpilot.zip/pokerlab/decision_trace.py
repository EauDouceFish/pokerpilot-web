"""Behavior-policy sampling with a bounded public event and private trace."""

from __future__ import annotations

import math
from collections.abc import Callable
from copy import deepcopy
from typing import Any

from .contracts import PokerError, chips

BehaviorPolicy = Callable[[dict[str, Any]], list[dict[str, Any]]]

_PLAYER_FIELDS = (
    "seat", "stack", "starting_stack", "committed", "ante_paid",
    "street_committed", "status",
)
_HISTORY_FIELDS = ("seat", "kind", "amount_to", "put_in", "street", "version")
_LEGAL_FIELDS = ("kind", "amount_to", "put_in", "all_in", "min_to", "max_to")
_RULE_FIELDS = ("small_blind", "big_blind", "ante_mode", "ante", "bba_order", "version")


def _json_copy(
    value: Any,
    path: str = "context",
    *,
    _depth: int = 0,
    _active: set[int] | None = None,
) -> Any:
    if _depth > 100:
        raise ValueError("context exceeds the maximum JSON nesting depth of 100")
    if value is None or type(value) in (str, bool, int):
        return value
    if type(value) is float:
        if not math.isfinite(value):
            raise ValueError(f"{path} must contain only finite JSON numbers")
        return value
    if type(value) in (list, dict):
        active = set() if _active is None else _active
        identity = id(value)
        if identity in active:
            raise ValueError("context must not contain a reference cycle")
        active.add(identity)
        try:
            if type(value) is list:
                return [
                    _json_copy(item, f"{path}[{index}]", _depth=_depth + 1, _active=active)
                    for index, item in enumerate(value)
                ]
            result = {}
            for key, item in value.items():
                if type(key) is not str:
                    raise ValueError(f"{path} must use JSON string object keys")
                result[key] = _json_copy(
                    item, f"{path}.{key}", _depth=_depth + 1, _active=active
                )
            return result
        finally:
            active.remove(identity)
    raise ValueError(f"{path} must be JSON-compatible")


def _actor_observation(observation: dict[str, Any]) -> dict[str, Any]:
    if type(observation) is not dict:
        raise ValueError("observation must be a dictionary")
    snapshot = observation
    actor = snapshot.get("actor")
    viewer = snapshot.get("viewer")
    players = snapshot.get("players")
    if type(actor) is not int or type(viewer) is not int or viewer != actor:
        raise ValueError("behavior policy observation viewer must equal actor")
    if type(players) is not list or not 0 <= actor < len(players):
        raise ValueError("behavior policy observation players are malformed")
    actor_row_count = 0
    for player in players:
        if type(player) is not dict or type(player.get("seat")) is not int:
            raise ValueError("behavior policy observation player is malformed")
        is_actor = player["seat"] == actor
        actor_row_count += int(is_actor)
        cards = player.get("hole_cards", [])
        if type(cards) is not list:
            raise ValueError("behavior policy observation hole_cards are malformed")
        if not is_actor and cards:
            raise ValueError("behavior policy observation exposes non-actor hole_cards")
    if actor_row_count != 1:
        raise ValueError("behavior policy observation must contain one actor player")
    return snapshot


def _project_rows(value: Any, fields: tuple[str, ...], name: str) -> list[dict[str, Any]]:
    if type(value) is not list:
        raise ValueError(f"observation {name} must be a list")
    rows = []
    for item in value:
        if type(item) is not dict:
            raise ValueError(f"observation {name} entry must be a dictionary")
        rows.append({field: deepcopy(item[field]) for field in fields if field in item})
    return rows


def _public_projection(observation: dict[str, Any]) -> dict[str, Any]:
    rules = observation.get("rules")
    if type(rules) is not dict:
        raise ValueError("observation rules must be a dictionary")
    scalar_fields = ("version", "street", "button", "actor", "board", "pot", "to_call")
    missing = [field for field in scalar_fields if field not in observation]
    if missing:
        raise ValueError(f"observation public field {missing[0]} is required")
    result = {
        field: deepcopy(observation[field])
        for field in scalar_fields
    }
    result["rules"] = {field: deepcopy(rules[field]) for field in _RULE_FIELDS if field in rules}
    result["players"] = _project_rows(observation.get("players"), _PLAYER_FIELDS, "players")
    result["history"] = _project_rows(observation.get("history"), _HISTORY_FIELDS, "history")
    result["legal_actions"] = _project_rows(
        observation.get("legal_actions"), _LEGAL_FIELDS, "legal_actions"
    )
    return result


def sample_decision(
    policy: BehaviorPolicy,
    observation: dict[str, Any],
    rng: Any,
    *,
    context: Any = None,
    record_trace: bool = True,
) -> dict[str, Any]:
    """Sample one legal action and return separated public and private records."""

    if not callable(policy):
        raise ValueError("behavior policy must be callable")
    if type(record_trace) is not bool:
        raise ValueError("record_trace must be a boolean")
    actor_observation = _actor_observation(observation)
    context_copy = None
    public_event = None
    trace_observation = None
    if record_trace:
        context_copy = {} if context is None else _json_copy(context)
        trace_observation = deepcopy(actor_observation)
        public_event = _public_projection(trace_observation)
    legal = actor_observation.get("legal_actions")
    if type(legal) is not list or not legal:
        raise ValueError("behavior policy observation must contain legal actions")
    legal_by_kind: dict[str, dict[str, Any]] = {}
    for item in legal:
        if type(item) is not dict or type(item.get("kind")) is not str:
            raise ValueError("behavior policy observation legal action is malformed")
        if item["kind"] in legal_by_kind:
            raise ValueError("behavior policy observation has duplicate legal action kinds")
        legal_by_kind[item["kind"]] = item

    try:
        distribution = policy(deepcopy(actor_observation))
    except Exception as exc:
        raise ValueError("behavior policy raised while producing an action distribution") from exc
    if type(distribution) is not list or not distribution:
        raise ValueError("behavior policy must return a non-empty list")

    entries: list[dict[str, Any]] = []
    seen: set[tuple[str, int]] = set()
    total = 0.0
    actor = actor_observation["actor"]
    actor_row = next(
        player for player in actor_observation["players"] if player["seat"] == actor
    )
    try:
        shove_to = chips(actor_row["street_committed"]) + chips(actor_row["stack"])
    except (KeyError, PokerError) as exc:
        raise ValueError("behavior policy observation actor chips are malformed") from exc

    for index, item in enumerate(distribution):
        if type(item) is not dict or not {"kind", "amount_to", "probability"}.issubset(item):
            raise ValueError(f"behavior policy entry {index} is malformed")
        kind = item["kind"]
        if type(kind) is not str or kind not in legal_by_kind:
            raise ValueError(f"behavior policy entry {index} has an illegal action kind")
        try:
            amount_to = chips(item["amount_to"])
        except PokerError as exc:
            raise ValueError(f"behavior policy entry {index} has an invalid amount_to") from exc
        probability = item["probability"]
        if isinstance(probability, bool) or not isinstance(probability, (int, float)):
            raise ValueError(f"behavior policy entry {index} has an invalid probability")
        declared = float(probability)
        if not math.isfinite(declared) or declared < 0.0:
            raise ValueError(f"behavior policy entry {index} has an invalid probability")

        details = legal_by_kind[kind]
        try:
            if kind in ("fold", "check", "call"):
                if amount_to != chips(details["amount_to"]):
                    raise ValueError(f"behavior policy entry {index} amount does not match {kind}")
            else:
                minimum = chips(details["min_to"])
                maximum = chips(details["max_to"])
                if not minimum <= amount_to <= maximum:
                    raise ValueError(
                        f"behavior policy entry {index} raise amount is outside legal bounds"
                    )
        except (KeyError, PokerError) as exc:
            raise ValueError("behavior policy observation legal action is malformed") from exc
        signature = (kind, amount_to)
        if signature in seen:
            raise ValueError("behavior policy returned a duplicate action")
        seen.add(signature)
        total += declared
        entries.append({
            "kind": kind,
            "amount_to": amount_to,
            "probability": declared,
            "aggressive_shove": amount_to == shove_to and kind in ("bet", "raise"),
        })

    if not math.isclose(total, 1.0, rel_tol=0.0, abs_tol=1e-12):
        raise ValueError("behavior policy probabilities must sum to one")
    normalized = [entry["probability"] / total for entry in entries]
    positive = [index for index, probability in enumerate(normalized) if probability > 0.0]
    if not positive:
        raise ValueError("behavior policy must assign positive probability to an action")
    correction_index = max(positive, key=lambda index: normalized[index])
    normalized[correction_index] += 1.0 - math.fsum(normalized)

    draw = rng.random()
    cumulative = 0.0
    selected_index = positive[-1]
    for index, probability in enumerate(normalized):
        cumulative += probability
        if probability > 0.0 and draw < cumulative:
            selected_index = index
            break
    selected = entries[selected_index]
    action = (selected["kind"], selected["amount_to"], selected["aggressive_shove"])
    if not record_trace:
        return {"action": action}
    assert public_event is not None
    assert context_copy is not None
    assert trace_observation is not None
    public_event["selected_action"] = {
        "kind": selected["kind"], "amount_to": selected["amount_to"]
    }
    declared_distribution = [
        {"kind": entry["kind"], "amount_to": entry["amount_to"],
         "probability": entry["probability"]}
        for entry in entries
    ]
    normalized_distribution = [
        {"kind": entry["kind"], "amount_to": entry["amount_to"], "probability": probability}
        for entry, probability in zip(entries, normalized, strict=True)
    ]
    return {
        "action": action,
        "public_event": public_event,
        "evaluation_trace": {
            "version": "decision-trace-v1",
            "visibility": "offline-evaluator-only",
            "actor_observation": trace_observation,
            "declared_distribution": declared_distribution,
            "normalized_distribution": normalized_distribution,
            "selected_index": selected_index,
            "selected_probability": normalized[selected_index],
            "draw": draw,
            "context": context_copy,
        },
    }
