"""Immutable policies with one dense private-hand matrix per public node.

No private hands are bucketed. The compact mapping retains the ordinary
CurrentPolicyProfile query API without allocating one Python entry per combo.
"""
from __future__ import annotations

from collections.abc import Iterator, Mapping
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

import numpy as np

from .belief import COMBOS
from .range_prior import (
    PolicyPriorDescriptor,
    UnvisitedPolicyPrior,
    checked_prior_matrix,
    validate_prior,
)
from .synchronous_search import CurrentPolicyProfile, _PolicyEntry

_INDEX = {frozenset(combo): i for i, combo in enumerate(COMBOS)}


def public_key(key: tuple) -> tuple:
    if not isinstance(key, tuple) or len(key) != 9 or key[0] != 'finite-nlhe-v1':
        raise ValueError('range policies require a compact poker information key')
    if not isinstance(key[4], tuple) or len(key[4]) not in (0, 2):
        raise ValueError('invalid private combination in information key')
    try:
        if key[4] and frozenset(key[4]) not in _INDEX:
            raise ValueError('invalid private combination in information key')
    except TypeError as exc:
        raise ValueError('invalid private combination in information key') from exc
    return (*key[:4], (), *key[5:])


def _readonly(array: np.ndarray) -> np.ndarray:
    return np.frombuffer(array.tobytes(), dtype=array.dtype).reshape(array.shape)


@dataclass(slots=True)
class RangeBlock:
    player: int
    actions: tuple
    regrets: np.ndarray
    strategy_sum: np.ndarray
    visited: np.ndarray


def new_block(player: int, actions: tuple) -> RangeBlock:
    CurrentPolicyProfile._validate_signature(9, player, actions)
    return RangeBlock(player, actions, np.zeros((len(COMBOS), len(actions))),
                      np.zeros((len(COMBOS), len(actions))), np.zeros(len(COMBOS), dtype=bool))


@dataclass(frozen=True, slots=True)
class _FrozenBlock:
    player: int
    actions: tuple
    probabilities: np.ndarray
    visited: np.ndarray


def _freeze_block(num_players: int, key: tuple, block: RangeBlock, *, average: bool) -> _FrozenBlock:
    if not isinstance(block, RangeBlock) or public_key(key) != key:
        raise ValueError('each block needs a public key and RangeBlock value')
    CurrentPolicyProfile._validate_signature(num_players, block.player, block.actions)
    if key[1] != block.player:
        raise ValueError('public node actor disagrees with block player')
    shape = (len(COMBOS), len(block.actions))
    if any(not isinstance(a, np.ndarray) or a.shape != shape or a.dtype != np.float64
           or not np.isfinite(a).all() for a in (block.regrets, block.strategy_sum)):
        raise ValueError('range tables must be finite float64 matrices')
    if (block.strategy_sum < 0).any():
        raise ValueError('average strategy mass cannot be negative')
    if not isinstance(block.visited, np.ndarray) or block.visited.shape != (len(COMBOS),) or block.visited.dtype != np.bool_:
        raise ValueError('visited must be a boolean combo vector')
    mass = block.strategy_sum.copy() if average else np.maximum(block.regrets, 0.0)
    total = mass.sum(axis=1, keepdims=True)
    if not np.isfinite(total).all():
        raise ValueError('range strategy normalization overflow')
    probabilities = np.full(shape, 1.0 / len(block.actions))
    np.divide(mass, total, out=probabilities, where=total > 0)
    # Unvisited rows have no policy identity even if a malformed caller
    # provided numbers there; reject that state rather than mask it.
    if np.any(block.regrets[~block.visited]) or np.any(block.strategy_sum[~block.visited]):
        raise ValueError('unvisited rows must have zero accumulators')
    return _FrozenBlock(block.player, block.actions,
                        _readonly(probabilities), _readonly(block.visited))


class _Entries(Mapping):
    def __init__(self, blocks: Mapping) -> None:
        self._blocks = blocks
        self._size = sum(int(block.visited.sum()) for block in blocks.values())

    def __len__(self) -> int:
        return self._size

    def __iter__(self) -> Iterator:
        for key, block in self._blocks.items():
            for index in np.flatnonzero(block.visited):
                yield (*key[:4], tuple(sorted(COMBOS[index])), *key[5:])

    def __getitem__(self, key: Any) -> _PolicyEntry:
        try:
            block = self._blocks[public_key(key)]
            index = _INDEX[frozenset(key[4])]
        except (ValueError, TypeError, KeyError):
            raise KeyError(key) from None
        if not block.visited[index]:
            raise KeyError(key)
        return _PolicyEntry(block.player, block.actions, tuple(map(float, block.probabilities[index])))


class _LazyBlocks(Mapping):
    def __init__(self, num_players: int, blocks: Mapping) -> None:
        self._num_players = num_players
        self._raw = MappingProxyType(dict(blocks))
        self._cache: dict[tuple, _FrozenBlock] = {}

    def __len__(self) -> int:
        return len(self._raw)

    def __iter__(self) -> Iterator:
        return iter(self._raw)

    def __contains__(self, key: object) -> bool:
        return key in self._raw

    def __getitem__(self, key: tuple) -> _FrozenBlock:
        raw = self._raw[key]
        frozen = self._cache.get(key)
        if frozen is None:
            frozen = _freeze_block(self._num_players, key, raw, average=False)
            self._cache[key] = frozen
        return frozen


class _LazyEntries(Mapping):
    def __init__(self, raw_blocks: Mapping, blocks: _LazyBlocks) -> None:
        self._raw_blocks = raw_blocks
        self._blocks = blocks
        self._size: int | None = None

    @staticmethod
    def _location(key: Any) -> tuple[tuple, int]:
        try:
            return public_key(key), _INDEX[frozenset(key[4])]
        except (ValueError, TypeError, KeyError):
            raise KeyError(key) from None

    def __len__(self) -> int:
        if self._size is None:
            self._size = sum(int(block.visited.sum()) for block in self._raw_blocks.values())
        return self._size

    def __iter__(self) -> Iterator:
        for key, block in self._raw_blocks.items():
            for index in np.flatnonzero(block.visited):
                yield (*key[:4], tuple(sorted(COMBOS[index])), *key[5:])

    def __contains__(self, key: object) -> bool:
        try:
            block_key, index = self._location(key)
            block = self._raw_blocks[block_key]
        except KeyError:
            return False
        return bool(block.visited[index])

    def __getitem__(self, key: Any) -> _PolicyEntry:
        block_key, index = self._location(key)
        try:
            raw = self._raw_blocks[block_key]
        except KeyError:
            raise KeyError(key) from None
        if not raw.visited[index]:
            raise KeyError(key)
        block = self._blocks[block_key]
        return _PolicyEntry(block.player, block.actions, tuple(map(float, block.probabilities[index])))


class DenseCurrentPolicyProfile(CurrentPolicyProfile):
    """Drop-in scalar queries plus batched rows, with no mutable table alias."""

    def __init__(self, num_players: int, blocks: Mapping, generation: int, *,
                 average: bool = False,
                 unvisited_policy_prior: UnvisitedPolicyPrior | None = None):
        super().__init__(num_players, {}, generation)
        if not isinstance(blocks, Mapping) or type(average) is not bool:
            raise ValueError('blocks must be a mapping and average a boolean')
        descriptor = validate_prior(unvisited_policy_prior, num_players)
        frozen = {}
        for key, block in blocks.items():
            frozen[key] = _freeze_block(num_players, key, block, average=average)
        self._blocks = MappingProxyType(frozen)
        self._entries = _Entries(self._blocks)
        self.average = average
        self.__unvisited_policy_prior = unvisited_policy_prior
        self.__prior_descriptor = descriptor

    @classmethod
    def _from_committed(cls, num_players: int, blocks: Mapping, generation: int, *,
                        unvisited_policy_prior: UnvisitedPolicyPrior | None = None):
        if not isinstance(blocks, Mapping):
            raise ValueError('blocks must be a mapping')
        descriptor = validate_prior(unvisited_policy_prior, num_players)
        profile = cls.__new__(cls)
        CurrentPolicyProfile.__init__(profile, num_players, {}, generation)
        lazy_blocks = _LazyBlocks(num_players, blocks)
        profile._blocks = lazy_blocks
        profile._entries = _LazyEntries(lazy_blocks._raw, lazy_blocks)
        profile.average = False
        profile.__unvisited_policy_prior = unvisited_policy_prior
        profile.__prior_descriptor = descriptor
        return profile

    @property
    def blocks(self) -> Mapping:
        return self._blocks

    @property
    def prior_descriptor(self) -> PolicyPriorDescriptor | None:
        self._check_prior_identity()
        return self.__prior_descriptor

    def _check_prior_identity(self) -> None:
        if (self.__unvisited_policy_prior is not None
                and self.__unvisited_policy_prior.descriptor != self.__prior_descriptor):
            raise ValueError('prior identity changed after profile construction')

    def _prior_matrix(self, key: tuple, player: int, actions: tuple,
                      indices: np.ndarray) -> np.ndarray:
        prior = self.__unvisited_policy_prior
        descriptor = self.__prior_descriptor
        if prior is None or descriptor is None:
            return np.full((len(indices), len(actions)), 1.0 / len(actions))
        return checked_prior_matrix(prior, descriptor, key, player, actions, indices)

    def probabilities(self, player: int, key: tuple, actions: tuple) -> tuple[float, ...]:
        block_key = public_key(key)
        if len(key[4]) != 2 or key[1] != player:
            raise ValueError('scalar policy queries require the actor and a private combination')
        if self.__unvisited_policy_prior is None:
            return super().probabilities(player, key, actions)
        self._check_prior_identity()
        self._validate_signature(self.num_players, player, actions)
        index = _INDEX[frozenset(key[4])]
        block = self._blocks.get(block_key)
        if block is not None:
            if block.player != player or block.actions != actions:
                raise ValueError('profile query does not match the registered information set')
            if block.visited[index]:
                return tuple(map(float, block.probabilities[index]))
        row = self._prior_matrix(
            block_key, player, actions, np.asarray([index], dtype=np.int64)
        )[0]
        return tuple(map(float, row))

    def matrix(self, key: tuple, player: int, actions: tuple, indices: np.ndarray) -> np.ndarray:
        self._check_prior_identity()
        self._validate_signature(self.num_players, player, actions)
        if public_key(key) != key or key[1] != player:
            raise ValueError('matrix query requires the matching public node')
        if not isinstance(indices, np.ndarray) or indices.ndim != 1 or indices.dtype.kind not in 'iu' or np.any(indices >= len(COMBOS)) or np.any(indices < 0):
            raise ValueError('indices must be an integer combo vector')
        block = self._blocks.get(key)
        if block is None:
            return _readonly(self._prior_matrix(key, player, actions, indices))
        if block.player != player or block.actions != actions:
            raise ValueError('matrix query does not match registered actions/player')
        if self.__unvisited_policy_prior is None:
            return _readonly(block.probabilities[indices])
        probabilities = np.array(block.probabilities[indices], copy=True)
        unvisited = ~block.visited[indices]
        if np.any(unvisited):
            probabilities[unvisited] = self._prior_matrix(
                key, player, actions, indices[unvisited]
            )
        return _readonly(probabilities)
