"""PokerKit 0.7.3 adapter for clockwise, one-chip-at-a-time split remainders.

PokerKit's default gives the entire remainder of a split pot to its first
winner. Our rules distribute one chip to each tied winner, starting left of the
button. The game's internal seats are already in that clockwise order. Keep
this hook covered when upgrading the pinned dependency: it intercepts a push
before PokerKit records it or starts pulling chips into stacks.
"""

from dataclasses import replace
from typing import Any

from pokerkit import ChipsPushing, NoLimitTexasHoldem, State


class _ClockwiseSplitState(State):
    def _begin_showdown(self) -> None:
        # Freeze contribution-based pot boundaries before automatic mucking
        # removes losing hands. Otherwise PokerKit can merge formerly distinct
        # side pots once their remaining eligible winners become identical,
        # which changes per-pot rounding. Keep PokerKit's independent ranker.
        if not hasattr(self, "_showdown_pot_boundaries"):
            self._showdown_pot_boundaries = tuple(super().pots)
        super()._begin_showdown()

    @property
    def pots(self):
        boundaries = getattr(self, "_showdown_pot_boundaries", None)
        if self._pots is not None or boundaries is None:
            yield from super().pots
        else:
            for pot in boundaries:
                # Mucked hands cannot win, but their removal cannot collapse
                # a side-pot boundary that existed before showdown.
                remaining = tuple(seat for seat in pot.player_indices if self.statuses[seat])
                yield replace(pot, player_indices=remaining)

    def _update_chips_pushing(self, operation=None) -> None:
        if isinstance(operation, ChipsPushing) and operation.board_index is not None:
            pot = self._pots[operation.pot_index]
            hands = tuple(self.get_up_hands(operation.board_index, operation.hand_type_index))
            available = [hands[seat] for seat in pot.player_indices if hands[seat] is not None]
            if available:
                best = max(available)
                winners = [seat for seat in pot.player_indices if hands[seat] == best]
                quotient, remainder = divmod(sum(operation.amounts), len(winners))
                amounts = [0] * self.player_count
                for offset, seat in enumerate(winners):
                    amounts[seat] = quotient + int(offset < remainder)
                for seat in self.player_indices:
                    self.bets[seat] += amounts[seat] - operation.amounts[seat]
                operation = replace(operation, amounts=tuple(amounts))
        super()._update_chips_pushing(operation)


class ClockwiseHoldem(NoLimitTexasHoldem):
    """Use PokerKit's rules and ranker, with the product's split-chip order."""

    def __call__(self, raw_starting_stacks: Any, player_count: int) -> State:
        return _ClockwiseSplitState(
            self.automations,
            self.deck,
            self.hand_types,
            self.streets,
            self.betting_structure,
            self.ante_trimming_status,
            self.raw_antes,
            self.raw_blinds_or_straddles,
            self.bring_in,
            raw_starting_stacks,
            player_count,
            mode=self.mode,
            starting_board_count=self.starting_board_count,
            divmod=self.divmod,
            rake=self.rake,
        )


class _V3State(_ClockwiseSplitState):
    """Apply full-blind and per-player no-limit reopening semantics."""

    def _begin_betting(self) -> None:
        assert self.street is not None
        self._v3_full_increment = self.street.min_completion_betting_or_raising_amount
        self._v3_nominal_floor = (
            self._v3_full_increment if self.street is self.streets[0] else 0
        )
        self._v3_acted_at = [None] * self.player_count
        self._v3_pending_raise = None
        super()._begin_betting()

    def _v3_wager_level(self) -> int:
        """Return the rules-level wager without adding synthetic chips."""
        actual = max(self.bets)
        floor = self._v3_nominal_floor
        actor = self.actor_index
        if floor <= actual or actor is None:
            return actual
        # The nominal preflop bring-in remains in force while another live
        # player still has chips, even when that player cannot reach the full
        # blind. Once only one player has chips, actual bets determine whether
        # a final match is needed; unmatched chips are never manufactured.
        if any(
            seat != actor
            and self.statuses[seat]
            and self.stacks[seat]
            for seat in self.player_indices
        ):
            return floor
        return actual

    @property
    def checking_or_calling_amount(self) -> int | None:
        try:
            self.verify_checking_or_calling()
        except (ValueError, UserWarning):
            return None
        player_index = self.actor_index
        assert player_index is not None
        return min(
            self.stacks[player_index],
            self._v3_wager_level() - self.bets[player_index],
        )

    def verify_folding(self) -> None:
        if not self.actor_indices:
            raise ValueError("There is no player to act.")
        if self.bring_in_status:
            raise ValueError("The player must post a bring-in or complete.")
        player_index = self.actor_index
        assert player_index is not None
        if self.bets[player_index] < self._v3_wager_level():
            return
        super().verify_folding()

    @property
    def min_completion_betting_or_raising_to_amount(self) -> int | None:
        try:
            self._verify_completion_betting_or_raising()
        except (ValueError, UserWarning):
            return None
        player_index = self.actor_index
        assert player_index is not None
        amount = self._v3_wager_level() + self._v3_full_increment
        return min(
            self.stacks[player_index] + self.bets[player_index],
            amount,
        )

    def _verify_completion_betting_or_raising(self) -> None:
        if not self.actor_indices:
            raise ValueError("There is no player to act.")
        assert self.street is not None
        if (
            self.completion_betting_or_raising_count
            == self.street.max_completion_betting_or_raising_count
        ):
            raise ValueError("No more completion, betting, or raising is permitted.")

        player_index = self.actor_index
        assert player_index is not None
        wager_level = self._v3_wager_level()
        acted_at = self._v3_acted_at[player_index]
        if acted_at is not None and wager_level - acted_at < self._v3_full_increment:
            raise ValueError(
                "The player already acted and is not facing a full bet or raise."
            )
        if self.stacks[player_index] <= wager_level - self.bets[player_index]:
            raise ValueError(
                "The player is already covered by a previous bet or raise."
            )
        if not any(
            seat != player_index
            and self.statuses[seat]
            and self.stacks[seat] + self.bets[seat] > wager_level
            for seat in self.player_indices
        ):
            raise ValueError(
                "There is no reason to raise since every other player is covered."
            )

    def _pop_actor_index(self) -> int:
        player_index = self.actor_index
        assert player_index is not None
        wager_level = self._v3_wager_level()
        popped = super()._pop_actor_index()
        assert popped == player_index
        self._v3_acted_at[player_index] = wager_level
        return popped

    def complete_bet_or_raise_to(self, amount=None, *, commentary=None):
        amount = self.verify_completion_betting_or_raising_to(amount)
        player_index = self.actor_index
        assert player_index is not None
        self._v3_pending_raise = (player_index, self._v3_wager_level(), amount)
        try:
            return super().complete_bet_or_raise_to(amount, commentary=commentary)
        finally:
            self._v3_pending_raise = None

    def _update_betting(self, operation=None, status: bool = False) -> None:
        pending = self._v3_pending_raise
        if pending is not None and operation is not None:
            player_index, prior_level, amount = pending
            increment = amount - prior_level
            self._v3_acted_at[player_index] = amount
            if increment >= self._v3_full_increment:
                self._v3_full_increment = increment
            # Keep PokerKit's generic bookkeeping aligned for code paths that
            # inspect it, while v3 legality uses the explicit fields above.
            self.completion_betting_or_raising_amount = self._v3_full_increment
            self._v3_pending_raise = None

        # Once only a covered player remains able to act, no voluntary action
        # or synthetic completion to the nominal blind is required.
        live_with_chips = sum(
            bool(self.statuses[seat] and self.stacks[seat]) for seat in self.player_indices
        )
        if len(self.actor_indices) == 1 and live_with_chips == 1:
            sole = self.actor_indices[0]
            status = status or self.bets[sole] >= max(self.bets)
        super()._update_betting(operation, status=status)


class V3Holdem(NoLimitTexasHoldem):
    """No-limit hold'em with chip-rules-v3 betting semantics."""

    def __call__(self, raw_starting_stacks: Any, player_count: int) -> State:
        return _V3State(
            self.automations,
            self.deck,
            self.hand_types,
            self.streets,
            self.betting_structure,
            self.ante_trimming_status,
            self.raw_antes,
            self.raw_blinds_or_straddles,
            self.bring_in,
            raw_starting_stacks,
            player_count,
            mode=self.mode,
            starting_board_count=self.starting_board_count,
            divmod=self.divmod,
            rake=self.rake,
        )
