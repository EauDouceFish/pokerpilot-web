"""Exact no-limit hold'em rules backed by PokerKit.

The public seat numbers in this module are physical, clockwise seat numbers.
PokerKit is kept behind a small adapter whose index zero is the small blind.
"""

from __future__ import annotations

from collections import deque
from copy import deepcopy
from itertools import chain
from random import Random
from typing import Any, TypedDict

from pokerkit import Automation, BetCollection, Card, Deck

from pokerlab.contracts import PokerError, chips, money
from pokerlab.pokerkit_adapter import ClockwiseHoldem, V3Holdem


class Observation(TypedDict):
    """Versioned public hand observation (nested values follow the contract)."""

    schema_version: int
    version: int
    street: str
    button: int
    actor: int | None
    viewer: int
    hero_cards: list[str]
    board: list[str]
    pot: str
    to_call: str
    min_raise_to: str
    can_raise: bool
    is_terminal: bool
    rules: dict[str, str]
    players: list[dict[str, Any]]
    pots: list[dict[str, Any]]
    legal_actions: list[dict[str, Any]]
    history: list[dict[str, Any]]
    result: dict[str, Any] | None


_AUTOMATIONS = (
    Automation.ANTE_POSTING,
    Automation.BET_COLLECTION,
    Automation.BLIND_OR_STRADDLE_POSTING,
    Automation.HOLE_CARDS_SHOWING_OR_MUCKING,
    Automation.HAND_KILLING,
    Automation.CHIPS_PUSHING,
    Automation.CHIPS_PULLING,
)
_STREETS = ("preflop", "flop", "turn", "river")


def _card(raw: object) -> Card:
    if not isinstance(raw, str):
        raise PokerError("牌必须使用 As、Td、2c 格式")
    try:
        parsed = tuple(Card.parse(raw))
    except (ValueError, KeyError) as exc:
        raise PokerError(f"无效的牌: {raw}") from exc
    if len(parsed) != 1 or repr(parsed[0]) != raw:
        raise PokerError(f"无效的牌: {raw}")
    return parsed[0]


class PokerHand:
    """A single no-limit Texas hold'em hand with exact integer chips."""

    def __init__(
        self,
        stacks: list[int],
        *,
        button: int = 0,
        small_blind: int = 50,
        big_blind: int = 100,
        ante_mode: str = "none",
        ante: int = 0,
        bba_order: str = "ante_first",
        seed: int | None = None,
        hole_cards: list[list[str]] | None = None,
        board_cards: list[str] | None = None,
        rules_version: str = "chip-rules-v3",
    ) -> None:
        if not isinstance(stacks, list) or not 2 <= len(stacks) <= 9:
            raise PokerError("玩家人数必须为 2 到 9")
        self.initial_stacks = [chips(value, minimum=1) for value in stacks]
        count = len(stacks)
        if isinstance(button, bool) or not isinstance(button, int) or not 0 <= button < count:
            raise PokerError("按钮座位无效")
        self.button = button
        self.small_blind = chips(small_blind, minimum=1)
        self.big_blind = chips(big_blind, minimum=1)
        if self.small_blind > self.big_blind:
            raise PokerError("小盲不能大于大盲")
        if ante_mode not in ("none", "uniform", "big_blind"):
            raise PokerError("前注模式必须是 none、uniform 或 big_blind")
        self.ante_mode = ante_mode
        self.ante = chips(ante)
        if bba_order not in ("ante_first", "blind_first"):
            raise PokerError("大盲前注顺序必须为 ante_first 或 blind_first")
        self.bba_order = bba_order
        if ante_mode == "none" and self.ante:
            raise PokerError("none 模式的前注必须为 0")
        if ante_mode != "none" and not self.ante:
            raise PokerError("启用前注时前注必须大于 0")
        if seed is not None and (isinstance(seed, bool) or not isinstance(seed, int)):
            raise PokerError("随机种子必须为整数")
        self.seed = seed
        if rules_version not in ("chip-rules-v2", "chip-rules-v3"):
            raise PokerError("规则版本必须为 chip-rules-v2 或 chip-rules-v3")
        self.rules_version = rules_version

        # Multiway internal index zero is the small blind.  Heads-up PokerKit
        # rotates the two blind values: internal zero becomes the big blind
        # (left of the button) and internal one is the button/small blind.
        first = (button + 1) % count
        self._internal_to_physical = [(first + i) % count for i in range(count)]
        self._physical_to_internal = [0] * count
        for internal, physical in enumerate(self._internal_to_physical):
            self._physical_to_internal[physical] = internal

        planned_holes, planned_board, deck = self._plan_cards(
            count, hole_cards, board_cards, seed
        )
        self._planned_holes = [
            planned_holes[physical] for physical in self._internal_to_physical
        ]
        self._planned_board = planned_board
        self._hole_offsets = [0] * count
        self._folded: set[int] = set()
        self._history: list[dict[str, Any]] = []
        self._version = 0
        self._result: dict[str, Any] | None = None

        internal_stacks = [
            self.initial_stacks[physical] for physical in self._internal_to_physical
        ]
        antes = [0] * count
        if ante_mode == "uniform":
            antes = [self.ante] * count
        elif ante_mode == "big_blind":
            # Like the blind tuple, PokerKit rotates a two-player value tuple.
            # Raw index one therefore lands on internal zero (the heads-up BB).
            antes[1] = self.ante
            if self.bba_order == "blind_first":
                big_blind_seat = (button + (1 if count == 2 else 2)) % count
                # Reserve the mandatory BB before computing payable dead ante.
                # PokerKit still posts ante first internally; the reduced raw
                # ante guarantees the same final live/dead allocation.
                antes[1] = min(self.ante, max(0, self.initial_stacks[big_blind_seat] - self.big_blind))
        blinds = [self.small_blind, self.big_blind] + [0] * (count - 2)
        try:
            holdem = ClockwiseHoldem if rules_version == "chip-rules-v2" else V3Holdem
            self._state = holdem.create_state(
                _AUTOMATIONS,
                False,
                antes,
                blinds,
                self.big_blind,
                internal_stacks,
                count,
            )
        except (ValueError, TypeError) as exc:
            raise PokerError(str(exc)) from exc

        # Explicit dealing makes fixed-card and seeded hands reproducible.  Put
        # three harmless burn cards first; explicit deals remove planned cards
        # from wherever they occur in this deque.
        planned = set(chain.from_iterable(planned_holes)) | set(planned_board)
        fillers = [card for card in deck if card not in planned]
        self._state.deck_cards = deque(fillers[:3] + list(planned) + fillers[3:])
        self._committed = [0] * count
        self._ante_paid = [0] * count
        for internal, physical in enumerate(self._internal_to_physical):
            self._committed[physical] = internal_stacks[internal] - self._state.stacks[internal]
            self._ante_paid[physical] = self._state.get_effective_ante(internal)
        gross_bets = list(self._state.bets)
        operation_start = len(self._state.operations)
        self._drive_dealing()
        self._apply_collection_refunds(gross_bets, operation_start)
        self.config = {
            "button": button,
            "small_blind": self.small_blind,
            "big_blind": self.big_blind,
            "ante_mode": ante_mode,
            "ante": self.ante,
            "bba_order": self.bba_order,
            "seed": seed,
            "hole_cards": [[repr(card) for card in cards] for cards in planned_holes],
            "board_cards": [repr(card) for card in planned_board],
            "rules_version": self.rules_version,
        }
        self._finish_if_terminal()

    @staticmethod
    def _plan_cards(
        player_count: int,
        hole_cards: list[list[str]] | None,
        board_cards: list[str] | None,
        seed: int | None,
    ) -> tuple[list[list[Card]], list[Card], list[Card]]:
        deck = list(Deck.STANDARD)
        Random(seed).shuffle(deck)
        count = 0 if hole_cards is None else len(hole_cards)
        fixed_holes: list[list[Card]] | None = None
        if hole_cards is not None:
            if not isinstance(hole_cards, list) or count != player_count:
                raise PokerError("固定手牌必须覆盖全部玩家")
            fixed_holes = []
            for cards in hole_cards:
                if not isinstance(cards, list) or len(cards) not in (0, 2):
                    raise PokerError("每位玩家的手牌必须为空或正好两张")
                fixed_holes.append([_card(raw) for raw in cards])
        fixed_board: list[Card] | None = None
        if board_cards is not None:
            if not isinstance(board_cards, list) or len(board_cards) not in (0, 3, 4, 5):
                raise PokerError("固定公共牌必须为 0、3、4 或 5 张")
            fixed_board = [_card(raw) for raw in board_cards]
        fixed = list(chain.from_iterable(fixed_holes or [])) + (fixed_board or [])
        if len(set(fixed)) != len(fixed):
            raise PokerError("牌不能重复")
        for card in fixed:
            deck.remove(card)

        planned_holes = fixed_holes or [[] for _ in range(player_count)]
        for seat, cards in enumerate(planned_holes):
            if not cards:
                planned_holes[seat] = [deck.pop(), deck.pop()]
        planned_board = list(fixed_board or [])
        while len(planned_board) < 5:
            planned_board.append(deck.pop())
        return planned_holes, planned_board, deck

    @property
    def actor(self) -> int | None:
        internal = self._state.actor_index
        return None if internal is None else self._internal_to_physical[internal]

    @property
    def is_terminal(self) -> bool:
        return not self._state.status

    @property
    def version(self) -> int:
        return self._version

    @property
    def history(self) -> list[dict[str, Any]]:
        return deepcopy(self._history)

    @property
    def result(self) -> dict[str, Any] | None:
        return deepcopy(self._result)

    def clone(self) -> PokerHand:
        # Cards (enum-valued rank/suit) and Street descriptors are frozen in
        # pinned PokerKit 0.7.3. Reuse those leaves only; all mutable state,
        # history, operation containers, configuration and stacks stay copied.
        cards = chain(Deck.STANDARD, chain.from_iterable(self._planned_holes), self._planned_board)
        memo = {id(card): card for card in cards}
        memo.update((id(street), street) for street in self._state.streets)
        return deepcopy(self, memo)

    def fork_action(
        self, seat: int, kind: str, amount_to: int | str | None = None
    ) -> PokerHand:
        """Apply one action on an independent branch, leaving this hand intact.

        Search callers need the new state, not a rendered observation. Keeping
        the transaction here also avoids cloning twice via clone().act().
        """
        candidate = self.clone()
        candidate._act_inplace(seat, kind, amount_to)
        return candidate

    def _drive_dealing(self) -> None:
        while self._state.status and self._state.actor_index is None:
            if self._state.can_deal_hole():
                internal = self._state.hole_dealee_index
                assert internal is not None
                offset = self._hole_offsets[internal]
                card = self._planned_holes[internal][offset]
                self._state.deal_hole(card)
                self._hole_offsets[internal] += 1
            elif self._state.card_burning_status:
                self._state.burn_card()
            elif self._state.can_deal_board():
                index = self._state.street_index
                assert index is not None and 1 <= index <= 3
                slices = ((0, 3), (3, 4), (4, 5))
                start, end = slices[index - 1]
                self._state.deal_board(self._planned_board[start:end])
            else:
                break

    def _apply_collection_refunds(
        self, gross_bets: list[int], operation_start: int
    ) -> None:
        """Remove PokerKit's uncalled-bet returns from committed totals."""
        for operation in self._state.operations[operation_start:]:
            if isinstance(operation, BetCollection):
                for index, collected in enumerate(operation.bets):
                    refund = gross_bets[index] - collected
                    if refund > 0:
                        physical = self._internal_to_physical[index]
                        self._committed[physical] -= refund
                break

    def act(
        self, seat: int, kind: str, amount_to: int | str | None = None
    ) -> Observation:
        # Apply to a private copy.  This protects every observable attribute,
        # including engine operation logs, if validation or dealing fails.
        candidate = self.fork_action(seat, kind, amount_to)
        observation = candidate.view(seat)
        self.__dict__ = candidate.__dict__
        return observation

    def _act_inplace(self, seat: int, kind: str, amount_to: int | str | None) -> None:
        if self.is_terminal:
            raise PokerError("牌局已经结束")
        if isinstance(seat, bool) or not isinstance(seat, int) or seat != self.actor:
            raise PokerError("当前不是该座位行动")
        if kind not in ("fold", "check", "call", "bet", "raise"):
            raise PokerError("动作类型无效")
        internal = self._physical_to_internal[seat]
        old_bet = self._state.bets[internal]
        gross_bets = list(self._state.bets)
        operation_start = len(self._state.operations)
        action_street = _STREETS[self._state.street_index or 0]
        call_amount = self._state.checking_or_calling_amount

        if kind == "fold":
            if not self._state.can_fold():
                raise PokerError("当前不能弃牌")
            actual_to, put_in = old_bet, 0
            if amount_to is not None and chips(amount_to) != actual_to:
                raise PokerError("amount_to 与合法弃牌金额不符")
            self._state.fold()
            self._folded.add(seat)
        elif kind in ("check", "call"):
            if call_amount is None or (kind == "check") != (call_amount == 0):
                raise PokerError("check/call 与当前跟注额不符")
            actual_to = old_bet + call_amount
            if amount_to is not None and chips(amount_to) != actual_to:
                raise PokerError("amount_to 与合法 check/call 金额不符")
            operation = self._state.check_or_call()
            put_in = operation.amount
            assert actual_to == old_bet + put_in
            gross_bets[internal] = actual_to
            self._committed[seat] += put_in
        else:
            if amount_to is None:
                raise PokerError("下注或加注必须指定 amount_to")
            target = chips(amount_to)
            opening = self._is_opening_bet()
            if (kind == "bet") != opening:
                raise PokerError("bet/raise 与当前下注状态不符")
            if not self._state.can_complete_bet_or_raise_to(target):
                raise PokerError("下注额不在合法范围内")
            self._state.complete_bet_or_raise_to(target)
            actual_to, put_in = target, target - old_bet
            gross_bets[internal] = target
            self._committed[seat] += put_in

        self._apply_collection_refunds(gross_bets, operation_start)

        self._version += 1
        self._history.append(
            {
                "seat": seat,
                "kind": kind,
                "amount_to": money(actual_to),
                "put_in": money(put_in),
                "street": action_street,
                "version": self._version,
            }
        )
        self._drive_dealing()
        self._finish_if_terminal()

    def _finish_if_terminal(self) -> None:
        if not self.is_terminal or self._result is not None:
            return
        final = [0] * len(self.initial_stacks)
        for internal, physical in enumerate(self._internal_to_physical):
            final[physical] = self._state.stacks[internal]
        net = [final[i] - self.initial_stacks[i] for i in range(len(final))]
        payouts = [final[i] - (self.initial_stacks[i] - self._committed[i]) for i in range(len(final))]
        winners = [i for i, payout in enumerate(payouts) if payout > 0]
        self._result = {
            "final_stacks": [money(value) for value in final],
            "net": [str(value) for value in net],
            "winners": winners,
        }

    def _legal_actions(self) -> list[dict[str, Any]]:
        if self.is_terminal or self._state.actor_index is None:
            return []
        internal = self._state.actor_index
        current = self._state.bets[internal]
        stack = self._state.stacks[internal]
        actions: list[dict[str, Any]] = []
        if self._state.can_fold():
            actions.append(
                {"kind": "fold", "amount_to": money(current), "put_in": "0", "all_in": False}
            )
        call = self._state.checking_or_calling_amount
        if call is not None:
            actions.append(
                {
                    "kind": "check" if call == 0 else "call",
                    "amount_to": money(current + call),
                    "put_in": money(call),
                    "all_in": call > 0 and call == stack,
                }
            )
        minimum = self._state.min_completion_betting_or_raising_to_amount
        maximum = self._state.max_completion_betting_or_raising_to_amount
        if minimum is not None and maximum is not None:
            actions.append(
                {
                    "kind": "bet" if self._is_opening_bet() else "raise",
                    "amount_to": money(minimum),
                    "put_in": money(minimum - current),
                    "all_in": minimum - current == stack,
                    "min_to": money(minimum),
                    "max_to": money(maximum),
                }
            )
        return actions

    def _is_opening_bet(self) -> bool:
        if self.rules_version == "chip-rules-v3" and self._state.street_index == 0:
            return False
        return max(self._state.bets) == 0

    def _visible_pots(self) -> list[dict[str, Any]]:
        """Partition every committed chip, including outstanding bets.

        A player who has not yet matched an outstanding layer remains eligible
        when their remaining stack can still reach it.  This avoids presenting
        a temporary side pot while action on the street is still pending.
        """
        if self.is_terminal:
            return []
        active = [
            seat for seat in range(len(self.initial_stacks)) if seat not in self._folded
        ]
        live = [
            self._committed[seat] - self._ante_paid[seat]
            for seat in range(len(self.initial_stacks))
        ]
        result: list[dict[str, Any]] = []
        dead_antes = sum(self._ante_paid)
        if dead_antes:
            result.append({"amount": money(dead_antes), "eligible": active})

        levels = sorted(set(value for value in live if value > 0))
        previous = 0
        for level in levels:
            contributors = sum(value >= level for value in live)
            amount = (level - previous) * contributors
            eligible = []
            for seat in range(len(self.initial_stacks)):
                internal = self._physical_to_internal[seat]
                capacity = live[seat] + self._state.stacks[internal]
                if seat not in self._folded and capacity >= level:
                    eligible.append(seat)
            if amount:
                if result and result[-1]["eligible"] == eligible:
                    result[-1]["amount"] = money(int(result[-1]["amount"]) + amount)
                else:
                    result.append({"amount": money(amount), "eligible": eligible})
            previous = level
        return result

    def view(self, viewer: int, reveal: bool = False) -> Observation:
        count = len(self.initial_stacks)
        if isinstance(viewer, bool) or not isinstance(viewer, int) or not 0 <= viewer < count:
            raise PokerError("查看座位无效")
        terminal_showdown = self.is_terminal and not self._state.folded_status
        board = [repr(card) for card in chain.from_iterable(self._state.board_cards)]
        players: list[dict[str, Any]] = []
        for seat in range(count):
            internal = self._physical_to_internal[seat]
            stack = self._state.stacks[internal]
            if seat in self._folded:
                status = "folded"
            elif self.is_terminal and stack == 0:
                status = "out"
            elif not self.is_terminal and stack == 0:
                status = "all_in"
            else:
                status = "active"
            visible = reveal or seat == viewer or (terminal_showdown and seat not in self._folded)
            players.append(
                {
                    "seat": seat,
                    "stack": money(stack),
                    "starting_stack": money(self.initial_stacks[seat]),
                    "committed": money(self._committed[seat]),
                    "ante_paid": money(self._ante_paid[seat]),
                    "street_committed": money(self._state.bets[internal]),
                    "status": status,
                    "hole_cards": [repr(card) for card in self._planned_holes[internal]] if visible else [],
                }
            )
        actor_internal = self._state.actor_index
        to_call = 0
        minimum = None
        maximum = None
        if actor_internal is not None:
            to_call = self._state.checking_or_calling_amount or 0
            minimum = self._state.min_completion_betting_or_raising_to_amount
            maximum = self._state.max_completion_betting_or_raising_to_amount
        pots = self._visible_pots()
        hero_internal = self._physical_to_internal[viewer]
        return {
            "schema_version": 1,
            "version": self._version,
            "street": "showdown" if self.is_terminal else _STREETS[self._state.street_index or 0],
            "button": self.button,
            "actor": self.actor,
            "viewer": viewer,
            "hero_cards": [repr(card) for card in self._planned_holes[hero_internal]],
            "board": board,
            "pot": money(self._state.total_pot_amount),
            "to_call": money(to_call),
            "min_raise_to": money(minimum or 0),
            "can_raise": minimum is not None and maximum is not None,
            "is_terminal": self.is_terminal,
            "rules": {
                "small_blind": money(self.small_blind),
                "big_blind": money(self.big_blind),
                "ante_mode": self.ante_mode,
                "ante": money(self.ante),
                "bba_order": self.bba_order,
                "version": self.rules_version,
            },
            "players": players,
            "pots": pots,
            "legal_actions": self._legal_actions(),
            "history": self.history,
            "result": self.result,
        }
