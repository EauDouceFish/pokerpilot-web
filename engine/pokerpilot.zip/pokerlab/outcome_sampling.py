"""Single-trajectory outcome-sampling MCCFR.

The optional baseline is an experimental, traversal-local control variate.  A
bad baseline can increase variance; enabling it is not a quality guarantee.
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from typing import Any, Hashable

from .cfr_samples import AdvantageSample, StrategySample
from .mccfr import (
    CHANCE,
    FrozenStrategy,
    MCCFRTrainer,
    _Context,
    _Delta,
    _is_hashable,
)


class OutcomeSamplingTrainer(MCCFRTrainer):
    """MCCFR trainer that samples one action at every player node."""

    def __init__(self, *args: Any, baseline_provider: Any = None, **kwargs: Any) -> None:
        if baseline_provider is not None and not callable(baseline_provider):
            raise ValueError("baseline_provider must be callable or None")
        super().__init__(*args, **kwargs)
        self.baseline_provider = baseline_provider

    @property
    def diagnostics(self) -> dict[str, Any]:
        result = super().diagnostics
        result.update({
            "algorithm": "outcome-sampling-mccfr",
            "experimental_baseline": self.baseline_provider is not None,
            "baseline_quality_qualified": False,
        })
        return result

    def _baseline(
        self,
        state: Any,
        traverser: int,
        snapshot: FrozenStrategy,
        size: int,
    ) -> tuple[float, ...]:
        if self.baseline_provider is None:
            return (0.0,) * size
        raw = self.baseline_provider(state, traverser, snapshot)
        if raw is None:
            return (0.0,) * size
        if not isinstance(raw, Sequence) or isinstance(raw, (str, bytes)) or len(raw) != size:
            raise ValueError("baseline_provider must return None or one finite value per legal action")
        values: list[float] = []
        for value in raw:
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError("baseline_provider must return finite non-boolean values")
            try:
                converted = float(value)
            except (OverflowError, ValueError) as exc:
                raise ValueError("baseline_provider must return finite non-boolean values") from exc
            if not math.isfinite(converted):
                raise ValueError("baseline_provider must return finite non-boolean values")
            values.append(converted)
        return tuple(values)

    def _traverse(
        self,
        state: Any,
        traverser: int,
        reaches: tuple[float, ...],
        chance_reach: float,
        sample_reach: float,
        snapshot: FrozenStrategy,
        deltas: dict[Hashable, _Delta],
        sampled_actions: dict[tuple[int, Hashable], Hashable],
        context: _Context,
    ) -> float:
        context.touch()
        if self.game.is_terminal(state):
            return self._terminal_value(state, traverser)

        player = self.game.current_player(state)
        if isinstance(player, bool) or not isinstance(player, int) or player < CHANCE or player >= self.num_players:
            raise ValueError("current_player must be chance (-1) or a valid player")
        if player == CHANCE:
            if self.chance_mode == "sampled_on_policy":
                action = self.game.sample_chance_on_policy(state, self._rng)
                if not _is_hashable(action):
                    raise ValueError("sample_chance_on_policy must return a hashable action")
                return self._traverse(
                    self.game.next_state(state, action), traverser, reaches,
                    chance_reach, sample_reach, snapshot, deltas,
                    sampled_actions, context,
                )
            outcomes = self._chance(state)
            index = self._sample_index([probability for _, probability in outcomes])
            action, probability = outcomes[index]
            return self._traverse(
                self.game.next_state(state, action), traverser, reaches,
                chance_reach * probability, sample_reach * probability,
                snapshot, deltas, sampled_actions, context,
            )

        if self.leaf_evaluator is not None:
            value = self.leaf_evaluator(state, traverser, snapshot)
            context.check_deadline()
            if value is not None:
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    raise ValueError("leaf_evaluator must return a finite non-boolean scalar or None")
                try:
                    converted = float(value)
                except (OverflowError, ValueError) as exc:
                    raise ValueError(
                        "leaf_evaluator must return a finite non-boolean scalar or None"
                    ) from exc
                if not math.isfinite(converted):
                    raise ValueError("leaf_evaluator must return a finite non-boolean scalar or None")
                context.leaf_values_evaluated += 1
                return converted

        key, actions, strategy = self._actions_and_strategy(state, player, snapshot, deltas)
        baseline = self._baseline(state, traverser, snapshot, len(actions))
        context.check_deadline()
        if not math.isfinite(sample_reach) or sample_reach <= 0.0:
            raise ValueError("sample_reach must remain finite and positive")
        sampling = self._proposal(strategy, player, traverser)
        allow_zero = player != traverser and self.opponent_sampling == "on-policy"
        if any(not math.isfinite(probability) or probability < 0.0
               or probability == 0.0 and not allow_zero for probability in sampling):
            raise ValueError("outcome-sampling proposal probabilities are invalid")

        index = self._sample_proposal_index(sampling, player, traverser)
        if sampling[index] <= 0.0:
            raise ValueError("sampled action must have positive proposal probability")
        action = actions[index]

        if player != traverser and self.sample_sink is not None and not self.regret_only:
            context.strategies.append(StrategySample(
                context.iteration, context.traversal_id, player, key, actions,
                strategy, reaches[player] / sample_reach,
            ))

        updated = list(reaches)
        updated[player] *= strategy[index]
        child = self._traverse(
            self.game.next_state(state, action), traverser, tuple(updated),
            chance_reach, sample_reach * sampling[index], snapshot, deltas,
            sampled_actions, context,
        )

        action_values = list(baseline)
        action_values[index] += (child - baseline[index]) / sampling[index]
        node_value = math.fsum(
            probability * value
            for probability, value in zip(strategy, action_values, strict=True)
        )
        if not math.isfinite(node_value) or any(not math.isfinite(value) for value in action_values):
            raise ValueError("outcome-sampling estimate became non-finite")

        if player == traverser:
            counterfactual = chance_reach
            for other, reach in enumerate(reaches):
                if other != traverser:
                    counterfactual *= reach
            regret_weight = counterfactual / sample_reach
            sampled_regrets = tuple(
                regret_weight * (value - node_value) for value in action_values
            )
            if self.regret_only:
                if not all(math.isfinite(value) for value in sampled_regrets):
                    raise ValueError("outcome-sampling update became non-finite")
            else:
                average_weight = reaches[traverser] / sample_reach
                average_updates = tuple(average_weight * probability for probability in strategy)
                if not all(math.isfinite(value) for value in (*sampled_regrets, *average_updates)):
                    raise ValueError("outcome-sampling update became non-finite")
            if self.sample_sink is not None:
                context.advantages.append(AdvantageSample(
                    context.iteration, context.traversal_id, player, key, actions,
                    strategy, tuple(action_values), node_value, regret_weight,
                    sampled_regrets,
                ))
            delta = deltas[key]
            for action_index in range(len(actions)):
                delta.regrets[action_index] += sampled_regrets[action_index]
                if not self.regret_only:
                    delta.strategy_sum[action_index] += average_updates[action_index]

        return node_value
