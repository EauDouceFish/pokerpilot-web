"""Torch-free NumPy inference for the frozen two-player U49 policy."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from copy import deepcopy
import math
from numbers import Real
from types import MappingProxyType
from typing import Any

import numpy as np

from .contracts import PokerError
from .policy_features import (
    ACTION_FEATURE_DIM,
    CARD_COUNT,
    CARD_ROWS,
    CONTEXT_FEATURE_DIM,
    HISTORY_FEATURE_DIM,
    MADE_HAND_FEATURE_DIM,
    MADE_POLICY_FEATURE_VERSION,
    MAX_SEATS,
    PLAYER_FEATURE_DIM,
    encode_policy,
)


_WIDTH = 128
_PARAMETER_COUNT = 383_233
_COMPONENT_ID = "advantage-component-v1:b8020e96c06f82bcac7e0ceae25f2530"
_SHAPES = {
    "relative_seat": (9, 128),
    "card_encoder.1.weight": (128, 364),
    "card_encoder.1.bias": (128,),
    "player_projection.weight": (128, 11),
    "player_projection.bias": (128,),
    "player_aggregate.0.weight": (128, 1152),
    "player_aggregate.0.bias": (128,),
    "context_encoder.0.weight": (128, 12),
    "context_encoder.0.bias": (128,),
    "history_gru.weight_ih_l0": (384, 20),
    "history_gru.weight_hh_l0": (384, 128),
    "history_gru.bias_ih_l0": (384,),
    "history_gru.bias_hh_l0": (384,),
    "made_hand_encoder.0.weight": (128, 80),
    "made_hand_encoder.0.bias": (128,),
    "global_encoder.0.weight": (128, 640),
    "global_encoder.0.bias": (128,),
    "global_encoder.2.weight": (128,),
    "global_encoder.2.bias": (128,),
    "action_encoder.0.weight": (128, 9),
    "action_encoder.0.bias": (128,),
    "candidate_head.0.weight": (128, 256),
    "candidate_head.0.bias": (128,),
    "candidate_head.2.weight": (1, 128),
    "candidate_head.2.bias": (1,),
}


def _gelu(value: np.ndarray) -> np.ndarray:
    flat = value.reshape(-1)
    errors = np.fromiter(
        (math.erf(float(item) / math.sqrt(2.0)) for item in flat),
        dtype=np.float32,
        count=flat.size,
    ).reshape(value.shape)
    return np.asarray(value * np.float32(0.5) * (np.float32(1.0) + errors), dtype=np.float32)


def _sigmoid(value: np.ndarray) -> np.ndarray:
    result = np.empty_like(value)
    positive = value >= 0
    result[positive] = np.float32(1.0) / (
        np.float32(1.0) + np.exp(-value[positive], dtype=np.float32)
    )
    exp_value = np.exp(value[~positive], dtype=np.float32)
    result[~positive] = exp_value / (np.float32(1.0) + exp_value)
    return result


def _regret_matching(values: Sequence[Real]) -> tuple[float, ...]:
    raw = tuple(values)
    if not raw:
        raise PokerError("advantages 必须是非空实数序列")
    checked = []
    for value in raw:
        if isinstance(value, bool) or not isinstance(value, Real):
            raise PokerError("advantages 必须全部是有限实数")
        number = float(value)
        if not math.isfinite(number):
            raise PokerError("advantages 必须全部是有限实数")
        checked.append(number)
    positive = [max(0.0, value) for value in checked]
    scale = max(positive)
    if scale <= 0.0:
        probabilities = [1.0 / len(positive)] * len(positive)
    else:
        scaled = [value / scale for value in positive]
        total = math.fsum(scaled)
        probabilities = [value / total for value in scaled]
    largest = max(range(len(probabilities)), key=probabilities.__getitem__)
    probabilities[largest] += 1.0 - math.fsum(probabilities)
    if any(not math.isfinite(value) or value < 0.0 for value in probabilities):
        raise PokerError("regret matching 产生无效概率")
    return tuple(probabilities)


class NumpyAdvantagePolicy:
    """Immutable, exact-GELU NumPy forward pass for the frozen U49 snapshot."""

    def __init__(self, metadata: dict, weights: Mapping[str, np.ndarray]):
        if type(metadata) is not dict:
            raise PokerError("browser policy metadata 必须是对象")
        if (
            metadata.get("feature_version") != MADE_POLICY_FEATURE_VERSION
            or metadata.get("width") != _WIDTH
            or metadata.get("parameter_count") != _PARAMETER_COUNT
            or metadata.get("component_id") != _COMPONENT_ID
        ):
            raise PokerError("browser policy metadata 与冻结 U49 不匹配")
        if not isinstance(weights, Mapping) or set(weights) != set(_SHAPES):
            raise PokerError("browser policy 参数名称不匹配")
        copied: dict[str, np.ndarray] = {}
        for name, shape in _SHAPES.items():
            value = weights[name]
            if (
                not isinstance(value, np.ndarray)
                or value.shape != shape
                or value.dtype != np.float32
                or not np.isfinite(value).all()
            ):
                raise PokerError(f"browser policy 参数 {name} 无效")
            frozen = np.array(value, dtype=np.float32, order="C", copy=True)
            frozen.flags.writeable = False
            copied[name] = frozen
        if sum(value.size for value in copied.values()) != _PARAMETER_COUNT:
            raise PokerError("browser policy 参数总数不匹配")
        self.__metadata = MappingProxyType(deepcopy(metadata))
        self.__weights = MappingProxyType(copied)

    @property
    def metadata(self) -> Mapping[str, Any]:
        return self.__metadata

    def _linear(self, value: np.ndarray, prefix: str) -> np.ndarray:
        weight = self.__weights[f"{prefix}.weight"]
        bias = self.__weights[f"{prefix}.bias"]
        return np.asarray(value @ weight.T + bias, dtype=np.float32)

    def _history(self, history: np.ndarray, length: int) -> np.ndarray:
        hidden = np.zeros(_WIDTH, dtype=np.float32)
        if length == 0:
            return hidden
        weight_ih = self.__weights["history_gru.weight_ih_l0"]
        weight_hh = self.__weights["history_gru.weight_hh_l0"]
        bias_ih = self.__weights["history_gru.bias_ih_l0"]
        bias_hh = self.__weights["history_gru.bias_hh_l0"]
        for row in history[:length]:
            input_gates = np.asarray(row @ weight_ih.T + bias_ih, dtype=np.float32)
            hidden_gates = np.asarray(hidden @ weight_hh.T + bias_hh, dtype=np.float32)
            input_reset, input_update, input_new = np.split(input_gates, 3)
            hidden_reset, hidden_update, hidden_new = np.split(hidden_gates, 3)
            reset = _sigmoid(input_reset + hidden_reset)
            update = _sigmoid(input_update + hidden_update)
            new = np.tanh(input_new + reset * hidden_new).astype(np.float32, copy=False)
            hidden = np.asarray((np.float32(1.0) - update) * new + update * hidden,
                                dtype=np.float32)
        return hidden

    @staticmethod
    def _features(features: Mapping[str, Any]) -> dict[str, Any]:
        if not isinstance(features, Mapping):
            raise PokerError("features 必须是 policy feature 映射")
        expected = {
            "version", "cards", "players", "context", "history", "actions",
            "seat_mask", "history_length", "made_hand",
        }
        if set(features) != expected or features.get("version") != MADE_POLICY_FEATURE_VERSION:
            raise PokerError("features 字段或版本无效")
        shapes = {
            "cards": (CARD_ROWS, CARD_COUNT),
            "players": (MAX_SEATS, PLAYER_FEATURE_DIM),
            "context": (CONTEXT_FEATURE_DIM,),
            "made_hand": (MADE_HAND_FEATURE_DIM,),
        }
        checked = dict(features)
        for name, shape in shapes.items():
            value = features.get(name)
            if (not isinstance(value, np.ndarray) or value.shape != shape
                    or value.dtype != np.float32 or not np.isfinite(value).all()):
                raise PokerError(f"features.{name} 无效")
        history = features.get("history")
        actions = features.get("actions")
        if (not isinstance(history, np.ndarray) or history.ndim != 2
                or history.shape[1] != HISTORY_FEATURE_DIM or history.dtype != np.float32
                or not np.isfinite(history).all()):
            raise PokerError("features.history 无效")
        if (not isinstance(actions, np.ndarray) or actions.ndim != 2
                or actions.shape[0] < 1 or actions.shape[1] != ACTION_FEATURE_DIM
                or actions.dtype != np.float32 or not np.isfinite(actions).all()):
            raise PokerError("features.actions 无效")
        length = features.get("history_length")
        if (type(length) is not int or length < 0 or history.shape[0] != max(1, length)):
            raise PokerError("features.history_length 无效")
        seat_mask = features.get("seat_mask")
        if (not isinstance(seat_mask, np.ndarray) or seat_mask.shape != (MAX_SEATS,)
                or seat_mask.dtype != np.bool_):
            raise PokerError("features.seat_mask 无效")
        seats = int(seat_mask.sum())
        if not 2 <= seats <= MAX_SEATS or not np.array_equal(
            seat_mask, np.arange(MAX_SEATS) < seats
        ) or np.any(features["players"][~seat_mask]):
            raise PokerError("features.seat_mask 或 padding 无效")
        made = features["made_hand"]
        if np.any((made != 0.0) & (made != 1.0)):
            raise PokerError("features.made_hand 必须是二元特征")
        return checked

    def score_features(self, features: Mapping[str, Any]) -> np.ndarray:
        feature = self._features(features)
        cards = _gelu(self._linear(feature["cards"].reshape(-1), "card_encoder.1"))
        player_tokens = self._linear(feature["players"], "player_projection")
        player_tokens = _gelu(player_tokens + self.__weights["relative_seat"])
        player_tokens = player_tokens * feature["seat_mask"][:, None]
        players = _gelu(self._linear(player_tokens.reshape(-1), "player_aggregate.0"))
        context = _gelu(self._linear(feature["context"], "context_encoder.0"))
        history = self._history(feature["history"], feature["history_length"])
        made_hand = _gelu(self._linear(feature["made_hand"], "made_hand_encoder.0"))
        combined = np.concatenate((cards, players, context, history, made_hand))
        global_state = _gelu(self._linear(combined, "global_encoder.0"))
        mean = np.mean(global_state, dtype=np.float32)
        variance = np.mean((global_state - mean) ** 2, dtype=np.float32)
        global_state = np.asarray(
            (global_state - mean) / np.sqrt(variance + np.float32(1e-5), dtype=np.float32),
            dtype=np.float32,
        )
        global_state = (
            global_state * self.__weights["global_encoder.2.weight"]
            + self.__weights["global_encoder.2.bias"]
        )
        action_state = _gelu(self._linear(feature["actions"], "action_encoder.0"))
        repeated = np.broadcast_to(global_state, action_state.shape)
        candidates = np.concatenate((repeated, action_state), axis=1)
        candidates = _gelu(self._linear(candidates, "candidate_head.0"))
        scores = self._linear(candidates, "candidate_head.2").reshape(-1)
        if not np.isfinite(scores).all():
            raise PokerError("browser policy 输出包含非有限值")
        result = np.array(scores, dtype=np.float32, copy=True)
        result.flags.writeable = False
        return result

    def probabilities(self, player: int, key: Any, actions: Any) -> tuple[float, ...]:
        features = encode_policy(
            player, key, actions, feature_version=MADE_POLICY_FEATURE_VERSION
        )
        return _regret_matching(self.score_features(features))
