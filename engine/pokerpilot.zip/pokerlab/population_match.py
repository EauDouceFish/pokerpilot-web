"""Paired full-hand evaluation against a fixed population of seat policies.

One IID block is one freshly sampled joint deal.  Within the block each
physical seat is occupied in turn by the challenger, and policies A and B use
the same deal and action-random stream.  Seat rotations are correlated, so all
reported uncertainty is computed from block means.
"""

from __future__ import annotations

import math
import random
import time
from collections.abc import Callable, Sequence
from copy import deepcopy
from typing import Any

from .compact_game import CompactHand, CompactPokerGame
from .contracts import PokerError, chips
from .decision_trace import sample_decision
from .exact_eval import EvaluationBudgetError
from .resampled_game import ResampledPokerGame

BehaviorPolicy = Callable[[dict[str, Any]], list[dict[str, Any]]]
_STREETS = ("preflop", "flop", "turn", "river")
_MASK64 = (1 << 64) - 1


def _summary(values: Sequence[float]) -> dict[str, float]:
    count = len(values)
    mean = math.fsum(values) / count
    variance = math.fsum((value - mean) ** 2 for value in values) / (count - 1)
    standard_error = math.sqrt(variance / count)
    if not all(math.isfinite(value) for value in (mean, variance, standard_error)):
        raise ValueError("population matchup statistics became non-finite")
    return {"mean": mean, "sample_variance": variance, "standard_error": standard_error}


def _mixed_action_seed(seed: int, block: int, seat: int) -> int:
    """Pure seed derivation, independent of chance rejection-sampling draws."""

    value = (seed & _MASK64) ^ ((block + 1) * 0x9E3779B97F4A7C15 & _MASK64)
    value ^= (seat + 1) * 0xD1B54A32D192ED03 & _MASK64
    value = (value ^ (value >> 30)) * 0xBF58476D1CE4E5B9 & _MASK64
    value = (value ^ (value >> 27)) * 0x94D049BB133111EB & _MASK64
    return value ^ (value >> 31)


def _empty_behavior() -> dict[str, dict[str, int]]:
    return {
        street: {
            "decisions": 0,
            "facing_bet": 0,
            "can_raise": 0,
            "fold": 0,
            "call": 0,
            "raise": 0,
            "check": 0,
            "aggressive_shove": 0,
            "all_in_call": 0,
        }
        for street in _STREETS
    }


def _sample_action(
    policy: BehaviorPolicy,
    observation: dict[str, Any],
    rng: random.Random,
) -> tuple[str, int, bool]:
    return sample_decision(policy, observation, rng, record_trace=False)["action"]


def evaluate_population_pair(
    spec: dict,
    policy_a: BehaviorPolicy,
    policy_b: BehaviorPolicy,
    opponents: Sequence[BehaviorPolicy],
    *,
    blocks: int,
    seed: int,
    deadline: float | None = None,
    max_actions_per_hand: int = 500,
    decision_sink: Callable[[dict], None] | None = None,
    decision_context: Callable[[dict, dict], dict] | None = None,
) -> dict[str, Any]:
    """Evaluate two challenger policies against fixed physical-seat opponents."""

    if not isinstance(spec, dict):
        raise ValueError("spec must be a dictionary")
    for name, policy in (("policy_a", policy_a), ("policy_b", policy_b)):
        if not callable(policy):
            raise ValueError(f"{name} must be callable")
    if decision_sink is not None and not callable(decision_sink):
        raise ValueError("decision_sink must be callable")
    if decision_context is not None and (not callable(decision_context) or decision_sink is None):
        raise ValueError("decision_context requires a decision_sink and callable")
    if isinstance(opponents, (str, bytes)) or not isinstance(opponents, Sequence):
        raise ValueError("opponents must be a sequence")
    if isinstance(blocks, bool) or not isinstance(blocks, int) or blocks < 2:
        raise ValueError("blocks must be an integer of at least two")
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise ValueError("seed must be an integer")
    if (isinstance(max_actions_per_hand, bool) or not isinstance(max_actions_per_hand, int)
            or max_actions_per_hand < 1):
        raise ValueError("max_actions_per_hand must be a positive integer")
    if deadline is not None and (
        isinstance(deadline, bool) or not isinstance(deadline, (int, float))
        or not math.isfinite(deadline)
    ):
        raise ValueError("deadline must be a finite absolute perf-counter time")
    absolute_deadline = None if deadline is None else float(deadline)

    started = time.perf_counter()
    if absolute_deadline is not None and started >= absolute_deadline:
        raise EvaluationBudgetError("population matchup deadline exceeded")
    game = CompactPokerGame(ResampledPokerGame(spec, [], [], rank_backend="native"))
    if absolute_deadline is not None and time.perf_counter() >= absolute_deadline:
        raise EvaluationBudgetError("population matchup deadline exceeded during game construction")
    players = game.num_players
    if len(opponents) != players or any(not callable(policy) for policy in opponents):
        raise ValueError("opponents must contain one callable for every physical seat")

    hand_seconds = 0.0
    total_decisions = 0
    behavior = {
        "policy_a": _empty_behavior(),
        "policy_b": _empty_behavior(),
        "opponents": _empty_behavior(),
    }

    def check_deadline() -> None:
        if absolute_deadline is not None and time.perf_counter() >= absolute_deadline:
            raise EvaluationBudgetError("population matchup deadline exceeded")

    def rollout(
        root: CompactHand,
        challenger: int,
        challenger_policy: BehaviorPolicy,
        label: str,
        action_seed: int,
    ) -> tuple[tuple[float, ...], int, float]:
        nonlocal total_decisions
        hand_started = time.perf_counter()
        hand = root
        seat_rngs = [random.Random(_mixed_action_seed(action_seed, 0, seat))
                     for seat in range(players)]
        actions = 0
        while not hand.is_terminal:
            check_deadline()
            if actions >= max_actions_per_hand:
                raise EvaluationBudgetError("population matchup max_actions_per_hand exceeded")
            actor = hand.actor
            assert actor is not None
            observation = hand.view(actor)
            current_label = label if actor == challenger else "opponents"
            policy = challenger_policy if actor == challenger else opponents[actor]
            decision = None
            if decision_sink is None:
                kind, amount_to, shove = _sample_action(policy, observation, seat_rngs[actor])
            else:
                context = {
                    "protocol": "paired-population-v1", "block": block, "challenger": challenger,
                    "arm": label, "role": current_label, "action_index": actions,
                    "stream_seed": _mixed_action_seed(action_seed, 0, actor), "stream_seat": actor}
                context["declared_snapshot"] = decision_context(deepcopy(context), deepcopy(observation)) if decision_context else None
                decision = sample_decision(policy, observation, seat_rngs[actor], context=context)
                kind, amount_to, shove = decision["action"]
            check_deadline()
            counters = behavior[current_label][observation["street"]]
            counters["decisions"] += 1
            if chips(observation["to_call"]):
                counters["facing_bet"] += 1
            if observation["can_raise"]:
                counters["can_raise"] += 1
            counters["raise" if kind in ("bet", "raise") else kind] += 1
            if shove:
                counters["aggressive_shove"] += 1
            if kind == "call" and amount_to == (
                chips(observation["players"][actor]["street_committed"])
                + chips(observation["players"][actor]["stack"])
            ):
                counters["all_in_call"] += 1
            try:
                hand = hand.apply(kind, amount_to, rank_backend="native")
            except PokerError as exc:
                raise ValueError("validated behavior action was rejected by the rules engine") from exc
            if decision is not None:
                decision_sink(decision)
            actions += 1
            total_decisions += 1
            check_deadline()
        assert hand.final_stacks is not None
        values = tuple(
            (final - initial) / hand.big_blind
            for final, initial in zip(hand.final_stacks, hand.initial_stacks, strict=True)
        )
        if not math.isclose(math.fsum(values), 0.0, rel_tol=0.0, abs_tol=1e-12):
            raise AssertionError("terminal population matchup returns must be zero-sum")
        return values, actions, time.perf_counter() - hand_started

    check_deadline()
    deal_rng = random.Random(seed)
    paired_blocks: list[dict[str, Any]] = []
    block_a_values: list[float] = []
    block_b_values: list[float] = []
    block_delta_values: list[float] = []
    for block in range(blocks):
        check_deadline()
        chance_state = game.initial_state()
        deal = game.sample_chance_on_policy(chance_state, deal_rng)
        check_deadline()
        dealt_state = game.next_state(chance_state, deal)
        root = dealt_state.hand
        assert root is not None
        roles = []
        for challenger in range(players):
            action_seed = _mixed_action_seed(seed, block, challenger)
            values_a, actions_a, seconds_a = rollout(
                root, challenger, policy_a, "policy_a", action_seed
            )
            values_b, actions_b, seconds_b = rollout(
                root, challenger, policy_b, "policy_b", action_seed
            )
            hand_seconds += seconds_a + seconds_b
            value_a = values_a[challenger]
            value_b = values_b[challenger]
            delta = value_a - value_b
            if not all(math.isfinite(value) for value in (value_a, value_b, delta)):
                raise ValueError("population matchup returns became non-finite")
            roles.append({
                "seat": challenger,
                "policy_a_net_bb": value_a,
                "policy_b_net_bb": value_b,
                "delta_net_bb": delta,
                "policy_a_actions_count": actions_a,
                "policy_b_actions_count": actions_b,
                "policy_a_returns": values_a,
                "policy_b_returns": values_b,
            })
        block_a = math.fsum(role["policy_a_net_bb"] for role in roles) / players
        block_b = math.fsum(role["policy_b_net_bb"] for role in roles) / players
        block_delta = math.fsum(role["delta_net_bb"] for role in roles) / players
        block_a_values.append(block_a)
        block_b_values.append(block_b)
        block_delta_values.append(block_delta)
        paired_blocks.append({
            "block": block,
            "roles": tuple(roles),
            "block_a_net_bb": block_a,
            "block_b_net_bb": block_b,
            "block_delta_net_bb": block_delta,
        })
        check_deadline()

    block_a = _summary(block_a_values)
    block_b = _summary(block_b_values)
    block_delta = _summary(block_delta_values)
    check_deadline()
    wall_seconds = time.perf_counter() - started
    planned_hands = blocks * players * 2
    return {
        "player_count": players,
        "seed": seed,
        "planned_blocks": blocks,
        "completed_blocks": blocks,
        "planned_hands": planned_hands,
        "completed_hands": planned_hands,
        "paired_blocks": tuple(paired_blocks),
        "block_a": block_a,
        "block_b": block_b,
        "block_delta": block_delta,
        "mean_delta_net_bb": block_delta["mean"],
        "decision_count": total_decisions,
        "decisions_per_second": total_decisions / wall_seconds if wall_seconds > 0.0 else math.inf,
        "wall_seconds": wall_seconds,
        "hand_seconds": hand_seconds,
        "behavior": behavior,
        "scope": "paired-full-hand-population-match",
        "interval_assumption": "iid_deal_blocks_roles_correlated_within_block",
        "quality_qualified": False,
        "equilibrium_claimed": False,
    }
