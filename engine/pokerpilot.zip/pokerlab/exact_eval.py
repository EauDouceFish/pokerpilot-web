"""Exact fixed-policy evaluation for small, enumerable perfect-recall games.

This module is a teacher-validation aid.  It deliberately builds the complete
finite tree and is not an online solver or a claim that large hold'em games can
be solved exactly.
"""

from __future__ import annotations

import math
import time
from collections.abc import Callable, Hashable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from .mccfr import CHANCE, ExtensiveGame


Policy = Callable[[int, Hashable, tuple[Hashable, ...]], Mapping[Hashable, float]]


class EvaluationBudgetError(RuntimeError):
    """Raised when exact enumeration exceeds its explicit resource budget."""


@dataclass
class _Node:
    kind: str
    cf_reach: tuple[float, ...]
    player: int | None = None
    key: Hashable | None = None
    actions: tuple[Hashable, ...] = ()
    probabilities: tuple[float, ...] = ()
    children: list["_Node"] = field(default_factory=list)
    returns: tuple[float, ...] | None = None


@dataclass
class _InfoSet:
    player: int
    actions: tuple[Hashable, ...]
    own_history: tuple[tuple[Hashable, Hashable], ...]
    probabilities: tuple[float, ...]
    nodes: list[_Node] = field(default_factory=list)


class _Budget:
    def __init__(self, max_nodes: int, deadline: float | None) -> None:
        self.max_nodes = max_nodes
        self.deadline = deadline
        self.nodes = 0

    def check(self) -> None:
        if self.deadline is not None and time.perf_counter() >= self.deadline:
            raise EvaluationBudgetError("exact evaluation deadline exceeded")

    def add_node(self) -> None:
        self.check()
        if self.nodes >= self.max_nodes:
            raise EvaluationBudgetError("exact evaluation max_nodes exceeded")
        self.nodes += 1


def _is_hashable(value: Any) -> bool:
    try:
        hash(value)
    except TypeError:
        return False
    return True


def _zero_sum(values: Sequence[float]) -> bool:
    magnitude = math.fsum(abs(value) for value in values)
    return math.isclose(
        math.fsum(values),
        0.0,
        rel_tol=0.0,
        abs_tol=max(1e-9, 1e-12 * magnitude),
    )


class _Evaluator:
    def __init__(self, game: ExtensiveGame, policy: Policy, budget: _Budget) -> None:
        self.game = game
        self.policy = policy
        self.budget = budget
        self.num_players = game.num_players
        self.infosets: dict[Hashable, _InfoSet] = {}

    @staticmethod
    def _actions(game: ExtensiveGame, state: Any) -> tuple[Hashable, ...]:
        actions = game.legal_actions(state)
        if not isinstance(actions, tuple) or not actions:
            raise ValueError("legal_actions must return a non-empty tuple")
        if any(not _is_hashable(action) for action in actions) or len(set(actions)) != len(actions):
            raise ValueError("legal actions must be unique hashable values")
        return actions

    def _policy_probabilities(
        self, player: int, key: Hashable, actions: tuple[Hashable, ...]
    ) -> tuple[float, ...]:
        raw = self.policy(player, key, actions)
        if not isinstance(raw, Mapping) or set(raw) != set(actions):
            raise ValueError("policy must map exactly the legal actions")
        probabilities: list[float] = []
        for action in actions:
            value = raw[action]
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(value)
                or value < 0
            ):
                raise ValueError("policy probabilities must be finite and non-negative")
            probabilities.append(float(value))
        if not math.isclose(math.fsum(probabilities), 1.0, rel_tol=1e-9, abs_tol=1e-12):
            raise ValueError("policy probabilities must sum to one")
        return tuple(probabilities)

    def _chance(self, state: Any) -> tuple[tuple[Hashable, float], ...]:
        try:
            outcomes = tuple(self.game.chance_outcomes(state))
        except TypeError as exc:
            raise ValueError("chance_outcomes must be iterable") from exc
        if not outcomes:
            raise ValueError("chance_outcomes cannot be empty")
        seen: set[Hashable] = set()
        checked: list[tuple[Hashable, float]] = []
        for item in outcomes:
            if not isinstance(item, tuple) or len(item) != 2:
                raise ValueError("chance outcomes must be (action, probability) pairs")
            action, probability = item
            if not _is_hashable(action) or action in seen:
                raise ValueError("chance actions must be unique and hashable")
            if (
                isinstance(probability, bool)
                or not isinstance(probability, (int, float))
                or not math.isfinite(probability)
                or probability <= 0
            ):
                raise ValueError("chance probabilities must be finite and positive")
            seen.add(action)
            checked.append((action, float(probability)))
        if not math.isclose(
            math.fsum(probability for _, probability in checked),
            1.0,
            rel_tol=1e-9,
            abs_tol=1e-12,
        ):
            raise ValueError("chance probabilities must sum to one")
        return tuple(checked)

    def _terminal(self, state: Any, cf_reach: tuple[float, ...]) -> _Node:
        values = self.game.returns(state)
        if not isinstance(values, Sequence) or len(values) != self.num_players:
            raise ValueError("terminal returns must contain one value per player")
        converted: list[float] = []
        for value in values:
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError("terminal returns must be finite numbers")
            converted.append(float(value))
        if not _zero_sum(converted):
            raise ValueError("terminal returns must be zero-sum net rewards")
        return _Node("terminal", cf_reach, returns=tuple(converted))

    def build(
        self,
        state: Any,
        cf_reach: tuple[float, ...],
        own_histories: tuple[tuple[tuple[Hashable, Hashable], ...], ...],
    ) -> _Node:
        self.budget.add_node()
        if self.game.is_terminal(state):
            return self._terminal(state, cf_reach)
        player = self.game.current_player(state)
        if isinstance(player, bool) or not isinstance(player, int) or player < CHANCE or player >= self.num_players:
            raise ValueError("current_player must be chance (-1) or a valid player")
        if player == CHANCE:
            outcomes = self._chance(state)
            node = _Node(
                "chance",
                cf_reach,
                actions=tuple(action for action, _ in outcomes),
                probabilities=tuple(probability for _, probability in outcomes),
            )
            for action, probability in outcomes:
                child_reach = tuple(reach * probability for reach in cf_reach)
                node.children.append(
                    self.build(self.game.next_state(state, action), child_reach, own_histories)
                )
            return node

        actions = self._actions(self.game, state)
        key = self.game.information_key(state)
        if not _is_hashable(key):
            raise ValueError("information_key must be hashable")
        probabilities = self._policy_probabilities(player, key, actions)
        history = own_histories[player]
        info = self.infosets.get(key)
        if info is None:
            info = _InfoSet(player, actions, history, probabilities)
            self.infosets[key] = info
        elif info.player != player or info.actions != actions:
            raise ValueError("an information key must keep the same player and legal actions")
        elif info.own_history != history:
            raise ValueError("game violates perfect recall at an information set")
        elif info.probabilities != probabilities:
            raise ValueError("policy must be fixed for each information key")

        node = _Node("player", cf_reach, player=player, key=key, actions=actions, probabilities=probabilities)
        info.nodes.append(node)
        for index, action in enumerate(actions):
            child_reach = tuple(
                reach if seat == player else reach * probabilities[index]
                for seat, reach in enumerate(cf_reach)
            )
            child_histories = list(own_histories)
            child_histories[player] = history + ((key, action),)
            node.children.append(
                self.build(
                    self.game.next_state(state, action),
                    child_reach,
                    tuple(child_histories),
                )
            )
        return node

    def fixed_value(self, node: _Node, memo: dict[int, tuple[float, ...]]) -> tuple[float, ...]:
        self.budget.check()
        identity = id(node)
        if identity in memo:
            return memo[identity]
        if node.kind == "terminal":
            assert node.returns is not None
            result = node.returns
        else:
            children = [self.fixed_value(child, memo) for child in node.children]
            result = tuple(
                math.fsum(probability * child[player] for probability, child in zip(node.probabilities, children))
                for player in range(self.num_players)
            )
        memo[identity] = result
        return result

    def best_response(self, root: _Node, traverser: int) -> float:
        node_memo: dict[int, float] = {}
        action_memo: dict[Hashable, int] = {}
        visiting: set[Hashable] = set()

        def node_value(node: _Node) -> float:
            self.budget.check()
            identity = id(node)
            if identity in node_memo:
                return node_memo[identity]
            if node.kind == "terminal":
                assert node.returns is not None
                value = node.returns[traverser]
            elif node.kind == "player" and node.player == traverser:
                value = node_value(node.children[solve_infoset(node.key)])
            else:
                value = math.fsum(
                    probability * node_value(child)
                    for probability, child in zip(node.probabilities, node.children)
                )
            node_memo[identity] = value
            return value

        def solve_infoset(key: Hashable) -> int:
            if key in action_memo:
                return action_memo[key]
            if key in visiting:
                raise ValueError("cyclic information-set dependency is not supported")
            visiting.add(key)
            info = self.infosets[key]
            scores = [
                math.fsum(node.cf_reach[traverser] * node_value(node.children[index]) for node in info.nodes)
                for index in range(len(info.actions))
            ]
            choice = max(range(len(scores)), key=scores.__getitem__)
            action_memo[key] = choice
            visiting.remove(key)
            return choice

        return node_value(root)


def evaluate_profile(
    game: ExtensiveGame,
    policy: Policy,
    *,
    max_nodes: int = 100_000,
    deadline: float | None = None,
    include_root_values: bool = False,
) -> dict[str, Any]:
    """Fully enumerate a small game and compute fixed values and unilateral BRs."""

    if getattr(game, "chance_mode", "enumerable") != "enumerable":
        raise ValueError("exact evaluation requires enumerable chance_outcomes")
    players = getattr(game, "num_players", None)
    if isinstance(players, bool) or not isinstance(players, int) or not 2 <= players <= 9:
        raise ValueError("game.num_players must be an integer from 2 to 9")
    if not callable(policy):
        raise ValueError("policy must be callable")
    if isinstance(max_nodes, bool) or not isinstance(max_nodes, int) or max_nodes < 1:
        raise ValueError("max_nodes must be a positive integer")
    if not isinstance(include_root_values, bool):
        raise ValueError("include_root_values must be a boolean")
    if deadline is not None and (
        isinstance(deadline, bool) or not isinstance(deadline, (int, float)) or not math.isfinite(deadline)
    ):
        raise ValueError("deadline must be a finite absolute perf-counter time")

    budget = _Budget(max_nodes, float(deadline) if deadline is not None else None)
    evaluator = _Evaluator(game, policy, budget)
    histories = tuple(() for _ in range(players))
    root = evaluator.build(game.initial_state(), tuple(1.0 for _ in range(players)), histories)
    fixed_memo: dict[int, tuple[float, ...]] = {}
    values = evaluator.fixed_value(root, fixed_memo)
    best_responses = tuple(evaluator.best_response(root, player) for player in range(players))
    gains = tuple(max(0.0, best_responses[player] - values[player]) for player in range(players))
    nash_conv = math.fsum(gains)
    result: dict[str, Any] = {
        "values": values,
        "best_response_values": best_responses,
        "deviation_gains": gains,
        "nash_conv": nash_conv,
        "nodes": budget.nodes,
        "information_sets": len(evaluator.infosets),
        "scope": "finite-enumerable-perfect-recall-game",
        "exact_full_nlhe_claimed": False,
        "multiplayer_equilibrium_claimed": False,
    }
    if players == 2:
        result["mean_exploitability"] = nash_conv / 2.0
    if include_root_values and root.kind == "chance":
        root_values = []
        for action, probability, child in zip(
            root.actions, root.probabilities, root.children, strict=True
        ):
            item: dict[str, Any] = {
                "action": action,
                "probability": probability,
                "values": evaluator.fixed_value(child, fixed_memo),
            }
            if child.kind == "player":
                item["decision_actions"] = [
                    {
                        "action": child_action,
                        "probability": child_probability,
                        "values": evaluator.fixed_value(grandchild, fixed_memo),
                    }
                    for child_action, child_probability, grandchild in zip(
                        child.actions, child.probabilities, child.children, strict=True
                    )
                ]
            root_values.append(item)
        result["root_chance_values"] = root_values
    return result
