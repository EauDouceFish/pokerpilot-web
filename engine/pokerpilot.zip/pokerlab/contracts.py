"""Wire contract helpers: chip quantities remain exact decimal strings."""

from __future__ import annotations

from typing import Any

SCHEMA_VERSION = 1
MAX_CHIPS = (1 << 63) - 1
STYLES = ("balanced", "tight_aggressive", "loose_aggressive", "loose_passive")


class PokerError(ValueError):
    """A user-facing invalid state or action, never a silent correction."""


def chips(value: Any, *, minimum: int = 0) -> int:
    if isinstance(value, bool) or isinstance(value, float):
        raise PokerError("筹码必须为整数或十进制整数字符串")
    if not isinstance(value, (str, int)):
        raise PokerError("筹码格式无效")
    if isinstance(value, str) and (not value or not value.isascii() or not value.isdecimal()):
        raise PokerError("筹码必须是非负十进制整数")
    try:
        number = int(value)
    except (ValueError, OverflowError) as exc:
        raise PokerError("筹码必须是有效的十进制整数") from exc
    if number < minimum:
        raise PokerError("筹码低于允许的最小值")
    return number


def money(value: int) -> str:
    number = chips(value)
    try:
        return str(number)
    except ValueError as exc:
        raise PokerError("筹码无法转换为十进制字符串") from exc
