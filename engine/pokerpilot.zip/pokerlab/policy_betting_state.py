"""Reconstruct current-street betting rights from public information only."""
from functools import lru_cache

from .betting_round import BettingRound
from .contracts import PokerError


@lru_cache(maxsize=8192)
def public_betting_state(actor, street, players, events, big_blind):
    """Input is the validated information key's public portion, never cards.

    Undo this street's public chip transfers, then replay its actions through
    BettingRound. This preserves short-all-in/reopening semantics without
    inventing hidden cards or rolling a deal just to obtain legal bounds.
    """
    current = tuple(e for e in events if e[4] == street)
    stacks = [int(p[1]) for p in players]
    bets = [int(p[5]) for p in players]
    active = [p[6] in ("active", "all_in") for p in players]
    for seat, kind, _, put_in, _, _ in reversed(current):
        stacks[seat] += int(put_in)
        bets[seat] -= int(put_in)
        if kind == "fold":
            active[seat] = True
    first = current[0][0] if current else actor
    count = len(players)
    pending = tuple(seat for offset in range(count)
                    if active[seat := (first+offset) % count] and stacks[seat])
    state = BettingRound(tuple(stacks), tuple(bets), tuple(active), pending,
                         (None,)*count, big_blind, big_blind if street == "preflop" else 0)
    for seat, kind, amount, put_in, _, _ in current:
        if state.actor != seat:
            raise PokerError("current-street history has an inconsistent actor")
        updated = state.apply(kind, int(amount))
        if state.stacks[seat] - updated.stacks[seat] != int(put_in):
            raise PokerError("current-street history has an inconsistent chip transfer")
        state = updated
    if (state.actor != actor or state.stacks != tuple(int(p[1]) for p in players)
            or state.bets != tuple(int(p[5]) for p in players)
            or state.active != tuple(p[6] in ("active", "all_in") for p in players)):
        raise PokerError("current-street history does not match the public state")
    return state
