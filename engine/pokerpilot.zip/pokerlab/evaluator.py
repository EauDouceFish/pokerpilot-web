"""Exact card comparison and deterministic side-pot settlement helpers."""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from itertools import combinations
from typing import TypeAlias

from pokerlab.contracts import PokerError, chips

Card: TypeAlias = tuple[int, str]
HandRank: TypeAlias = tuple[int, ...]

_RANKS = "23456789TJQKA"
_SUITS = "cdhs"


def parse_card(value: str) -> Card:
    """Parse the wire card form (``As``, ``Td``) into a comparable value."""

    if not isinstance(value, str) or len(value) != 2:
        raise PokerError("牌面格式必须为两个字符，例如 As 或 Td")
    rank, suit = value[0].upper(), value[1].lower()
    if rank not in _RANKS or suit not in _SUITS:
        raise PokerError(f"无效牌面：{value}")
    return (_RANKS.index(rank) + 2, suit)


def parse_cards(values: Iterable[str]) -> tuple[Card, ...]:
    cards = tuple(parse_card(value) for value in values)
    if len(set(cards)) != len(cards):
        raise PokerError("牌面不能重复")
    return cards


def _five_rank(cards: Sequence[Card]) -> HandRank:
    values = sorted((rank for rank, _ in cards), reverse=True)
    counts = {rank: values.count(rank) for rank in set(values)}
    groups = sorted(((count, rank) for rank, count in counts.items()), reverse=True)
    flush = len({suit for _, suit in cards}) == 1
    unique = sorted(set(values), reverse=True)
    if unique == [14, 5, 4, 3, 2]:
        straight_high = 5
    elif len(unique) == 5 and unique[0] - unique[-1] == 4:
        straight_high = unique[0]
    else:
        straight_high = 0

    if flush and straight_high:
        return (8, straight_high)
    if groups[0][0] == 4:
        return (7, groups[0][1], groups[1][1])
    if groups[0][0] == 3 and groups[1][0] == 2:
        return (6, groups[0][1], groups[1][1])
    if flush:
        return (5, *values)
    if straight_high:
        return (4, straight_high)
    if groups[0][0] == 3:
        kickers = sorted((rank for rank, count in counts.items() if count == 1), reverse=True)
        return (3, groups[0][1], *kickers)
    pairs = sorted((rank for rank, count in counts.items() if count == 2), reverse=True)
    if len(pairs) == 2:
        kicker = next(rank for rank, count in counts.items() if count == 1)
        return (2, *pairs, kicker)
    if len(pairs) == 1:
        kickers = sorted((rank for rank, count in counts.items() if count == 1), reverse=True)
        return (1, pairs[0], *kickers)
    return (0, *values)


def evaluate_hand(values: Sequence[str]) -> HandRank:
    """Return the exact best rank for a five-, six-, or seven-card hand."""

    cards = parse_cards(values)
    if len(cards) not in (5, 6, 7):
        raise PokerError("牌力比较需要 5、6 或 7 张牌")
    return max(_five_rank(combo) for combo in combinations(cards, 5))


def compare_hands(left: Sequence[str], right: Sequence[str]) -> int:
    """Return 1, 0, or -1 according to the exact hand ordering."""

    left_rank, right_rank = evaluate_hand(left), evaluate_hand(right)
    return (left_rank > right_rank) - (left_rank < right_rank)


def side_pot_payouts(
    contributions: Sequence[int | str],
    folded: Iterable[int],
    ranks: Mapping[int, HandRank | Sequence[str]],
    *,
    dead_money: int | str = 0,
    seat_order: Sequence[int] | None = None,
) -> list[int]:
    """Split every contribution tier, including uncalled chips, exactly.

    ``contributions`` contains live contributions only. ``dead_money`` first
    forms a common pool open to every non-folded seat, including seats with no
    live contribution. A live tier is awarded only among non-folded seats that
    reached it. Adjacent pools with the same eligibility are merged before ties
    and indivisible chips are resolved in ``seat_order``.
    """

    amounts = [chips(value) for value in contributions]
    dead = chips(dead_money)
    player_count = len(amounts)
    if not 2 <= player_count <= 9:
        raise PokerError("边池结算需要 2 到 9 个座位")
    folded_set = set(folded)
    if any(not isinstance(seat, int) or not 0 <= seat < player_count for seat in folded_set):
        raise PokerError("弃牌座位无效")
    order = list(range(player_count)) if seat_order is None else list(seat_order)
    if sorted(order) != list(range(player_count)):
        raise PokerError("seat_order 必须恰好包含全部座位")

    parsed_ranks: dict[int, HandRank] = {}
    for seat, value in ranks.items():
        if not isinstance(seat, int) or not 0 <= seat < player_count:
            raise PokerError("牌力座位无效")
        if isinstance(value, tuple) and value and all(isinstance(part, int) for part in value):
            parsed_ranks[seat] = value
        else:
            parsed_ranks[seat] = evaluate_hand(value)

    non_folded = [seat for seat in range(player_count) if seat not in folded_set]
    if not non_folded:
        raise PokerError("边池没有可获胜的未弃牌玩家")
    if len(non_folded) == 1:
        # A fold ends the hand without a showdown. After uncalled chips have
        # been returned, the sole survivor can have a lower live contribution
        # than a folded blind/bettor; every remaining chip still belongs to it.
        payouts = [0] * player_count
        payouts[non_folded[0]] = sum(amounts) + dead
        return payouts

    pots: list[tuple[int, tuple[int, ...]]] = []

    def append_pot(amount: int, eligible: Sequence[int]) -> None:
        if amount == 0:
            return
        key = tuple(sorted(eligible))
        if not key:
            raise PokerError("边池没有可获胜的未弃牌玩家")
        if pots and pots[-1][1] == key:
            pots[-1] = (pots[-1][0] + amount, key)
        else:
            pots.append((amount, key))

    append_pot(dead, non_folded)
    previous = 0
    for level in sorted({amount for amount in amounts if amount > 0}):
        contributors = [seat for seat, amount in enumerate(amounts) if amount >= level]
        pot = (level - previous) * len(contributors)
        eligible = [seat for seat in contributors if seat not in folded_set]
        append_pot(pot, eligible)
        previous = level

    payouts = [0] * player_count
    for pot, eligible_tuple in pots:
        eligible = list(eligible_tuple)
        missing = [seat for seat in eligible if seat not in parsed_ranks]
        if missing:
            raise PokerError("缺少未弃牌玩家的牌力")
        best = max(parsed_ranks[seat] for seat in eligible)
        winners = [seat for seat in order if seat in eligible and parsed_ranks[seat] == best]
        share, remainder = divmod(pot, len(winners))
        for seat in winners:
            payouts[seat] += share
        for seat in winners[:remainder]:
            payouts[seat] += 1

    if sum(payouts) != sum(amounts) + dead:
        raise AssertionError("边池结算未守恒")
    return payouts
