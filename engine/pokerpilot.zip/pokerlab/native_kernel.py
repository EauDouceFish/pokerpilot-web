"""Validated Python boundary for the exact native rank and payout kernel.

The library is loaded lazily; importing this module never builds native code.
Totals beyond int64 use the independent arbitrary-precision payout
implementation; each input still follows the existing wire chip contract.
"""

from __future__ import annotations

import ctypes as ct
from functools import lru_cache
from typing import Iterable, Mapping, Sequence

from .contracts import PokerError, chips
from .evaluator import HandRank, parse_card
from .native_build import artifact_path


_RANK_LENGTHS = (6, 5, 4, 4, 2, 6, 3, 3, 2)
_MAX_INT64 = (1 << 63) - 1


@lru_cache(maxsize=1)
def load_native() -> ct.CDLL:
    path = artifact_path()
    if not path.is_file():
        raise RuntimeError("Native kernel not built; run python -m pokerlab.native_build")
    library = ct.CDLL(str(path))
    library.pl_core_abi.argtypes = []
    library.pl_core_abi.restype = ct.c_uint32
    library.pl_rank.argtypes = [ct.POINTER(ct.c_uint8), ct.c_int32, ct.POINTER(ct.c_uint32)]
    library.pl_rank.restype = ct.c_int32
    library.pl_rank_batch.argtypes = [ct.POINTER(ct.c_uint8), ct.c_int32, ct.c_int32,
                                     ct.POINTER(ct.c_uint32)]
    library.pl_rank_batch.restype = ct.c_int32
    library.pl_payouts.argtypes = [ct.POINTER(ct.c_int64), ct.c_int64, ct.c_int32,
                                  ct.c_uint32, ct.POINTER(ct.c_uint32), ct.c_int32,
                                  ct.POINTER(ct.c_int64)]
    library.pl_payouts.restype = ct.c_int32
    if library.pl_core_abi() != 1:
        raise RuntimeError("Unsupported native kernel ABI")
    return library


def _card_ids(values: Sequence[str]) -> list[int]:
    if len(values) not in (5, 6, 7):
        raise PokerError("牌力比较需要 5、6 或 7 张牌")
    parsed = [parse_card(value) for value in values]
    return [(rank - 2) * 4 + "cdhs".index(suit) for rank, suit in parsed]


def _decode(value: int) -> HandRank:
    category = value >> 20
    if not 0 <= category < len(_RANK_LENGTHS):
        raise RuntimeError("Invalid native rank category")
    return (category, *(value >> shift & 15
                        for shift in (16, 12, 8, 4, 0)[:_RANK_LENGTHS[category] - 1]))


def _encode(value: HandRank | Sequence[str]) -> int:
    if not isinstance(value, tuple) or not value or not all(type(v) is int for v in value):
        value = evaluate_hand(value)
    if (not 0 <= value[0] < len(_RANK_LENGTHS)
            or len(value) != _RANK_LENGTHS[value[0]]
            or any(not 2 <= part <= 14 for part in value[1:])):
        raise PokerError("无效牌力元组")
    return (value[0] << 20) | sum(part << shift for part, shift in zip(value[1:], (16, 12, 8, 4, 0)))


def evaluate_hand(values: Sequence[str]) -> HandRank:
    cards = _card_ids(values)
    result = ct.c_uint32()
    code = load_native().pl_rank((ct.c_uint8 * len(cards))(*cards), len(cards), ct.byref(result))
    if code:
        raise PokerError(f"原生牌力输入无效 ({code})")
    return _decode(result.value)


def evaluate_many(hands: Sequence[Sequence[str]]) -> list[HandRank]:
    if not hands:
        return []
    if len(hands) > (1 << 31) - 1:
        raise PokerError("批量牌力输入过大")
    count = len(hands[0])
    rows = [_card_ids(hand) for hand in hands]
    if any(len(row) != count for row in rows):
        raise PokerError("批量牌力每行牌数必须相同")
    packed = (ct.c_uint8 * (len(rows) * count))(*(card for row in rows for card in row))
    results = (ct.c_uint32 * len(rows))()
    code = load_native().pl_rank_batch(packed, count, len(rows), results)
    if code:
        raise PokerError(f"原生批量牌力输入无效 ({code})")
    return [_decode(value) for value in results]


def side_pot_payouts(contributions: Sequence[int | str], folded: Iterable[int],
                     ranks: Mapping[int, HandRank | Sequence[str]], *,
                     dead_money: int | str = 0, button: int = 0) -> list[int]:
    amounts = [chips(value) for value in contributions]
    dead = chips(dead_money)
    count = len(amounts)
    if not 2 <= count <= 9:
        raise PokerError("边池结算需要 2 到 9 个座位")
    if type(button) is not int or not 0 <= button < count:
        raise PokerError("按钮座位无效")
    folded_set = set(folded)
    if any(type(seat) is not int or not 0 <= seat < count for seat in folded_set):
        raise PokerError("弃牌座位无效")
    if any(type(seat) is not int or not 0 <= seat < count for seat in ranks):
        raise PokerError("牌力座位无效")
    encoded = [0] * count
    for seat, value in ranks.items():
        encoded[seat] = _encode(value)
    if sum(amounts) + dead > _MAX_INT64:
        from .evaluator import side_pot_payouts as python_payouts
        return python_payouts(amounts, folded_set,
                              {seat: _decode(encoded[seat]) for seat in ranks}, dead_money=dead,
                              seat_order=[(button + 1 + i) % count for i in range(count)])
    output = (ct.c_int64 * count)()
    code = load_native().pl_payouts((ct.c_int64 * count)(*amounts), dead, count,
                                   sum(1 << seat for seat in folded_set),
                                   (ct.c_uint32 * count)(*encoded), button, output)
    if code:
        raise PokerError(f"原生边池输入无效 ({code})")
    return list(output)
