"""Offline continuous cash games with explicit, per-seat external cash ledgers."""
from __future__ import annotations

import hashlib
import json
import random
import time
from collections.abc import Callable, Sequence
from copy import deepcopy

from .compact_game import CompactHand
from .exact_eval import EvaluationBudgetError
from .game import PokerHand
from .decision_trace import sample_decision
from .population_match import _empty_behavior, _mixed_action_seed, _sample_action


def settle_cash(final_stacks: Sequence[int], *, big_blind: int = 100,
                top_up: Sequence[bool] | None = None) -> dict:
    """Apply withdrawals strictly above 200 BB; busted seats rebuy 100 BB.
    Seats flagged in top_up are refilled to 100 BB whenever they end below it."""
    if type(big_blind) is not int or big_blind <= 0:
        raise ValueError('big_blind must be a positive integer')
    if (not isinstance(final_stacks, (list, tuple)) or not 2 <= len(final_stacks) <= 9
            or any(type(value) is not int or value < 0 for value in final_stacks)):
        raise ValueError('final_stacks must contain 2..9 nonnegative integer balances')
    top_up = [False]*len(final_stacks) if top_up is None else list(top_up)
    if len(top_up) != len(final_stacks) or any(type(flag) is not bool for flag in top_up):
        raise ValueError('top_up must flag every seat with a boolean')
    withdrawals = [value-100*big_blind if value > 200*big_blind else 0 for value in final_stacks]
    deposits = [100*big_blind-value if value == 0 or (flag and value < 100*big_blind) else 0
                for value, flag in zip(final_stacks, top_up, strict=True)]
    next_stacks = [v-w+d for v, w, d in zip(final_stacks, withdrawals, deposits, strict=True)]
    assert all(0 < value <= 200*big_blind for value in next_stacks)
    return dict(next_stacks=next_stacks, withdrawals=withdrawals, deposits=deposits)


def run_cash_session(
    policies: Sequence[Callable], *, hands: int, seed: int, button: int = 0,
    deadline: float | None = None, max_actions_per_hand: int = 500,
    record_sink: Callable[[dict], None] | None = None,
    decision_sink: Callable[[dict], None] | None = None,
    decision_context: Callable[[dict, dict], dict] | None = None,
) -> dict:
    """Play a fixed number of complete hands; callbacks receive every settled hand.

    Every seat starts with 100 BB. Policies see only their own observation.
    Chance/action streams are isolated per hand and physical seat. This runner
    never fits or changes policies and never stops early because of profit.
    """
    if (not isinstance(policies, (list, tuple)) or not 2 <= len(policies) <= 9
            or any(not callable(policy) for policy in policies)):
        raise ValueError('policies must contain 2..9 callables')
    if type(hands) is not int or hands < 1 or type(seed) is not int:
        raise ValueError('hands must be positive and seed must be an integer')
    n = len(policies)
    if type(button) is not int or not 0 <= button < n:
        raise ValueError('invalid starting button')
    if type(max_actions_per_hand) is not int or max_actions_per_hand < 1:
        raise ValueError('max_actions_per_hand must be positive')
    if deadline is not None:
        import math
        if isinstance(deadline, bool) or not isinstance(deadline, (int, float)) or not math.isfinite(deadline):
            raise ValueError('invalid absolute deadline')
    if record_sink is not None and not callable(record_sink):
        raise ValueError('record_sink must be callable')
    if decision_sink is not None and not callable(decision_sink):
        raise ValueError('decision_sink must be callable')
    if decision_context is not None and (not callable(decision_context) or decision_sink is None):
        raise ValueError('decision_context requires a decision_sink and callable')

    def check_time():
        if deadline is not None and time.perf_counter() >= deadline:
            raise EvaluationBudgetError('cash session deadline exceeded')

    started = time.perf_counter()
    check_time()
    initial = [10000]*n
    stacks, withdrawals, deposits, profits = initial[:], [0]*n, [0]*n, [0]*n
    behavior = [_empty_behavior() for _ in range(n)]
    totals = [0]*n
    completed = 0
    for hand_index in range(hands):
        check_time()
        hand_button = (button+hand_index) % n
        deal_seed = _mixed_action_seed(seed, hand_index, 101)
        root = PokerHand(stacks[:], button=hand_button, small_blind=50, big_blind=100,
                         ante_mode='none', ante=0, bba_order='blind_first', seed=deal_seed,
                         rules_version='chip-rules-v3')
        deal = [root.config['hole_cards'], root.config['board_cards']]
        deal_digest = hashlib.blake2b(json.dumps(deal, separators=(',', ':')).encode('utf-8'),
                                      digest_size=16).hexdigest()
        actions = []
        seat_rngs = [random.Random(_mixed_action_seed(seed, hand_index, 201+seat)) for seat in range(n)]
        if root.is_terminal:
            final = [int(value) for value in root.result['final_stacks']]
        else:
            hand = CompactHand.from_hand(root)
            while not hand.is_terminal:
                check_time()
                if len(actions) >= max_actions_per_hand:
                    raise EvaluationBudgetError('cash session action cap exceeded')
                actor = hand.actor
                assert actor is not None
                observation = hand.view(actor)
                decision = None
                if decision_sink is None:
                    kind, amount, shove = _sample_action(policies[actor], observation, seat_rngs[actor])
                else:
                    context = {
                        "protocol": "continuous-cash-v1", "hand": hand_index+1, "action_index": len(actions),
                        "stream_seed": _mixed_action_seed(seed, hand_index, 201+actor), "stream_seat": actor}
                    context["declared_snapshot"] = decision_context(deepcopy(context), deepcopy(observation)) if decision_context else None
                    decision = sample_decision(policies[actor], observation, seat_rngs[actor], context=context)
                    kind, amount, shove = decision["action"]
                check_time()
                count = behavior[actor][observation['street']]
                count['decisions'] += 1
                count['facing_bet'] += int(int(observation['to_call']) > 0)
                count['can_raise'] += int(observation['can_raise'])
                count['raise' if kind in ('bet', 'raise') else kind] += 1
                count['aggressive_shove'] += int(shove)
                player = observation['players'][actor]
                count['all_in_call'] += int(kind == 'call' and amount ==
                                           int(player['stack'])+int(player['street_committed']))
                actions.append([actor, kind, amount])
                hand = hand.apply(kind, amount, rank_backend='native')
                if decision is not None:
                    decision_sink(decision)
            final = list(hand.final_stacks)
        check_time()
        assert all(type(value) is int and value >= 0 for value in final)
        assert sum(final) == sum(stacks), 'hand chip conservation'
        net = [f-s for f, s in zip(final, stacks, strict=True)]
        cash = settle_cash(final)
        for seat in range(n):
            profits[seat] += net[seat]
            withdrawals[seat] += cash['withdrawals'][seat]
            deposits[seat] += cash['deposits'][seat]
            totals[seat] += int(final[seat] == 0)
            assert profits[seat] == (cash['next_stacks'][seat]+withdrawals[seat]
                                     -deposits[seat]-initial[seat]), 'per-seat external cash ledger'
        record = dict(hand=hand_index+1, button=hand_button, deal_seed=deal_seed,
                      deal_digest=deal_digest, starting_stacks=stacks, final_stacks=final,
                      net_chips=net, cumulative_net_chips=profits[:], actions=actions, **cash)
        if record_sink is not None:
            record_sink(record)
        stacks = cash['next_stacks']
        completed += 1
        check_time()
    return dict(players=n, planned_hands=hands, completed_hands=completed, seed=seed,
                starting_button=button, final_stacks=stacks, net_chips=profits,
                net_bb=[value/100 for value in profits], withdrawals=withdrawals,
                deposits=deposits, busts=totals, behavior=behavior,
                seconds=time.perf_counter()-started, complete=True,
                quality_qualified=False, scope='continuous-cash-with-per-seat-cash-ledger')
