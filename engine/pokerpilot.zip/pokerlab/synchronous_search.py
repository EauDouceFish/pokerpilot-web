"""Round-synchronous policy snapshots for sampled MCCFR traversals.

This module changes only the timing of current-policy reads: every traverser
in one completed round reads the same regret-matched profile.  It is a research
coordination wrapper, not a complete CFR-D implementation or a multiplayer
equilibrium guarantee.
"""

from __future__ import annotations

import math
from collections.abc import Hashable, Mapping, Sequence
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from .mccfr import MCCFRTrainer, _is_hashable, _regret_strategy
from .outcome_sampling import OutcomeSamplingTrainer


@dataclass(frozen=True, slots=True)
class _PolicyEntry:
    player: int
    actions: tuple[Hashable, ...]
    probabilities: tuple[float, ...]


class CurrentPolicyProfile:
    """An immutable, self-contained current-regret policy profile."""

    def __init__(self, num_players: int, entries: Mapping, generation: int):
        if isinstance(num_players, bool) or not isinstance(num_players, int) or not 2 <= num_players <= 9:
            raise ValueError("num_players must be an integer from 2 through 9")
        if not isinstance(entries, Mapping):
            raise ValueError("entries must be a mapping")
        if isinstance(generation, bool) or not isinstance(generation, int) or generation < 0:
            raise ValueError("generation must be a non-negative integer")

        copied: dict[Hashable, _PolicyEntry] = {}
        for key, raw_entry in entries.items():
            if not _is_hashable(key):
                raise ValueError("entry keys must be hashable")
            if isinstance(raw_entry, _PolicyEntry):
                player = raw_entry.player
                actions = tuple(raw_entry.actions)
                probabilities = tuple(raw_entry.probabilities)
            else:
                try:
                    player = raw_entry.player
                    raw_actions = raw_entry.actions
                    regrets = raw_entry.regrets
                except AttributeError as exc:
                    raise ValueError("entries must provide player, actions, and regrets") from exc
                if not isinstance(raw_actions, tuple):
                    raise ValueError("entry actions must be a non-empty tuple")
                actions = tuple(raw_actions)
                if not isinstance(regrets, Sequence) or isinstance(regrets, (str, bytes)):
                    raise ValueError("entry regrets must be a finite numeric sequence")
                copied_regrets = tuple(regrets)
                if len(copied_regrets) != len(actions) or any(
                    isinstance(value, bool)
                    or not isinstance(value, (int, float))
                    or not math.isfinite(value)
                    for value in copied_regrets
                ):
                    raise ValueError("entry regrets must match actions and contain finite numbers")
                probabilities = _regret_strategy(tuple(float(value) for value in copied_regrets))

            self._validate_signature(num_players, player, actions)
            if len(probabilities) != len(actions) or any(
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(value)
                or value < 0.0
                for value in probabilities
            ) or not math.isclose(math.fsum(probabilities), 1.0, rel_tol=1e-9, abs_tol=1e-12):
                raise ValueError("entry probabilities must be finite and sum to one")
            copied[key] = _PolicyEntry(
                player,
                tuple(actions),
                tuple(float(value) for value in probabilities),
            )

        self._num_players = num_players
        self._entries = MappingProxyType(copied)
        self._generation = generation

    @staticmethod
    def _validate_signature(
        num_players: int, player: int, actions: tuple[Hashable, ...]
    ) -> None:
        if isinstance(player, bool) or not isinstance(player, int) or not 0 <= player < num_players:
            raise ValueError("player must be a valid player index")
        if not isinstance(actions, tuple) or not actions:
            raise ValueError("actions must be a non-empty tuple")
        if any(not _is_hashable(action) for action in actions) or len(set(actions)) != len(actions):
            raise ValueError("actions must contain unique hashable values")

    @property
    def num_players(self) -> int:
        return self._num_players

    @property
    def entries(self) -> Mapping:
        return self._entries

    @property
    def generation(self) -> int:
        return self._generation

    def probabilities(
        self, player: int, key: Hashable, actions: tuple[Hashable, ...]
    ) -> tuple[float, ...]:
        self._validate_signature(self._num_players, player, actions)
        if not _is_hashable(key):
            raise ValueError("key must be hashable")
        entry = self._entries.get(key)
        if entry is None:
            probability = 1.0 / len(actions)
            return tuple(probability for _ in actions)
        if entry.player != player or entry.actions != actions:
            raise ValueError("profile query does not match the registered information set")
        return tuple(entry.probabilities)


class SynchronousMCCFRSearch:
    """Coordinate MCCFR rounds against one current-policy snapshot per round."""

    def __init__(
        self,
        game: Any,
        *,
        seed: int = 0,
        exploration: float = 0.1,
        leaf_evaluator: Any = None,
        traversal_mode: str = "external-sampling",
    ) -> None:
        if not isinstance(traversal_mode, str) or traversal_mode not in (
            "external-sampling", "outcome-sampling"
        ):
            raise ValueError("traversal_mode must be 'external-sampling' or 'outcome-sampling'")
        self._active_profile: CurrentPolicyProfile | None = None
        self._training = False
        self._failed = False
        self._generation = 0
        self._traversal_mode = traversal_mode
        trainer_type = (
            MCCFRTrainer if traversal_mode == "external-sampling" else OutcomeSamplingTrainer
        )
        self._trainer = trainer_type(
            game,
            seed=seed,
            exploration=exploration,
            leaf_evaluator=leaf_evaluator,
            strategy_provider=self._distribution,
            retain_tables=True,
        )
        self._profile = CurrentPolicyProfile(self._trainer.num_players, self._trainer._nodes, 0)

    def _ensure_exportable(self) -> None:
        if self._training:
            raise ValueError("policies cannot be exported while training")
        if self._failed:
            raise ValueError("search cannot export policies after an incomplete round")

    def _distribution(
        self, player: int, key: Hashable, actions: tuple[Hashable, ...]
    ) -> tuple[float, ...]:
        profile = self._active_profile
        if profile is None or not self._training or self._failed:
            raise ValueError("no synchronous policy profile is active")
        return profile.probabilities(player, key, actions)

    @property
    def diagnostics(self) -> dict[str, Any]:
        update_mode = (
            "simultaneous-current-profile-external-sampling"
            if self._traversal_mode == "external-sampling"
            else "simultaneous-current-profile-outcome-sampling"
        )
        return {
            **self._trainer.diagnostics,
            "traversal_mode": self._traversal_mode,
            "update_mode": update_mode,
            "failed": self._failed,
            "quality_qualified": False,
            "gto_claimed": False,
        }

    def current_profile(self) -> CurrentPolicyProfile:
        self._ensure_exportable()
        return CurrentPolicyProfile(
            self._profile.num_players, self._profile.entries, self._profile.generation
        )

    def average_policy(
        self, key: Hashable, actions: tuple[Hashable, ...]
    ) -> dict[Hashable, float]:
        self._ensure_exportable()
        return self._trainer.average_policy(key, actions)

    def train(
        self, iterations: int, deadline: float | None = None, max_nodes: int | None = None
    ) -> dict[str, Any]:
        if self._failed:
            raise ValueError("search cannot be trained after an incomplete round")
        if self._training:
            raise ValueError("train cannot be re-entered while a round is active")
        if isinstance(iterations, bool) or not isinstance(iterations, int) or iterations < 1:
            raise ValueError("iterations must be a positive integer")
        if deadline is not None and (
            isinstance(deadline, bool)
            or not isinstance(deadline, (int, float))
            or not math.isfinite(deadline)
        ):
            raise ValueError("deadline must be a finite absolute perf-counter time")
        if max_nodes is not None and (
            isinstance(max_nodes, bool) or not isinstance(max_nodes, int) or max_nodes < 0
        ):
            raise ValueError("max_nodes must be a non-negative integer")

        before = self._trainer.diagnostics
        call_iterations = 0
        call_traversals = 0
        call_nodes = 0
        remaining_nodes = max_nodes
        self._training = True
        try:
            try:
                for _ in range(iterations):
                    self._active_profile = CurrentPolicyProfile(
                        self._trainer.num_players, self._trainer._nodes, self._generation
                    )
                    result = self._trainer.train(
                        1, deadline=deadline, max_nodes=remaining_nodes
                    )

                    round_nodes = result["call_nodes_touched"]
                    call_nodes += round_nodes
                    call_traversals += result["call_traversals_completed"]
                    if remaining_nodes is not None:
                        remaining_nodes -= round_nodes
                    if result["call_iterations_completed"] != 1:
                        self._failed = True
                        break

                    call_iterations += 1
                    self._generation += 1
                    self._profile = CurrentPolicyProfile(
                        self._trainer.num_players, self._trainer._nodes, self._generation
                    )
            except Exception:
                self._failed = True
                raise
        finally:
            self._active_profile = None
            self._training = False

        after = self.diagnostics
        return {
            **after,
            "call_iterations_completed": call_iterations,
            "call_traversals_completed": call_traversals,
            "call_nodes_touched": call_nodes,
            "call_regret_updates": after["regret_updates"] - before["regret_updates"],
            "call_average_updates": after["average_updates"] - before["average_updates"],
            "call_leaf_values_evaluated": (
                after["leaf_values_evaluated"] - before["leaf_values_evaluated"]
            ),
        }
