"""Generic external-sampling MCCFR core for finite extensive-form games.

The equilibrium guarantees in the MCCFR literature assume two-player zero-sum
perfect-recall games. This implementation accepts two through nine players as an
experimental regret-minimization engine; that generality is not a multiplayer
equilibrium guarantee.
"""

from __future__ import annotations

import math
import random
import time
from collections.abc import Callable, Hashable, Iterator, Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol

from .cfr_samples import AdvantageSample, StrategySample, TraversalBatch

CHANCE = -1


class ExtensiveGame(Protocol):
    num_players: int

    def initial_state(self) -> Any: ...
    def is_terminal(self, state: Any) -> bool: ...
    def current_player(self, state: Any) -> int: ...
    def chance_outcomes(self, state: Any) -> Sequence[tuple[Hashable, float]]: ...
    def legal_actions(self, state: Any) -> tuple[Hashable, ...]: ...
    def next_state(self, state: Any, action: Hashable) -> Any: ...
    def information_key(self, state: Any) -> Hashable: ...
    def returns(self, state: Any) -> Sequence[float]: ...


@dataclass
class _Node:
    player: int
    actions: tuple[Hashable, ...]
    regrets: list[float]
    strategy_sum: list[float]


@dataclass
class _Delta:
    player: int
    actions: tuple[Hashable, ...]
    regrets: list[float]
    strategy_sum: list[float]


class _AbortTraversal(Exception):
    pass


@dataclass
class _Context:
    deadline: float | None
    max_nodes: int | None
    nodes: int = 0
    deadline_hit: bool = False
    node_limit_hit: bool = False
    leaf_values_evaluated: int = 0
    iteration: int = 1
    traversal_id: int = 1
    advantages: list[AdvantageSample] = field(default_factory=list)
    strategies: list[StrategySample] = field(default_factory=list)

    def touch(self) -> None:
        if self.deadline is not None and time.perf_counter() >= self.deadline:
            self.deadline_hit = True
            raise _AbortTraversal
        if self.max_nodes is not None and self.nodes >= self.max_nodes:
            self.node_limit_hit = True
            raise _AbortTraversal
        self.nodes += 1

    def check_deadline(self) -> None:
        if self.deadline is not None and time.perf_counter() >= self.deadline:
            self.deadline_hit = True
            raise _AbortTraversal


def _is_hashable(value: Any) -> bool:
    try:
        hash(value)
    except TypeError:
        return False
    return True


def _regret_strategy(regrets: Sequence[float]) -> tuple[float, ...]:
    positive = [max(0.0, value) for value in regrets]
    total = sum(positive)
    if total > 0.0:
        return tuple(value / total for value in positive)
    return tuple(1.0 / len(positive) for _ in positive)


class FrozenStrategy:
    """Lazy, read-only regret-matching view for one traverser pass."""

    def __init__(self, trainer: MCCFRTrainer) -> None:
        self._trainer = trainer
        self._regrets: dict[Hashable, tuple[float, ...]] = {}
        self._signatures: dict[Hashable, tuple[int, tuple[Hashable, ...]]] = {}
        self._active = True
        self._external: dict[Hashable, tuple[float, ...]] = {}

    def _ensure_active(self) -> None:
        if not self._active:
            raise ValueError("frozen strategy is no longer active")

    def invalidate(self) -> None:
        """Expire this traversal-scoped view without copying the trainer table."""

        self._active = False

    def __iter__(self) -> Iterator[Hashable]:
        """Expose only lazily visited keys for lightweight instrumentation."""

        self._ensure_active()
        return iter(self._regrets)

    def probabilities(
        self, player: int, key: Hashable, actions: tuple[Hashable, ...]
    ) -> tuple[float, ...]:
        self._ensure_active()
        if isinstance(player, bool) or not isinstance(player, int) or not 0 <= player < self._trainer.num_players:
            raise ValueError("player must be a valid player index")
        if not _is_hashable(key):
            raise ValueError("key must be hashable")
        if not isinstance(actions, tuple) or not actions:
            raise ValueError("actions must be a non-empty tuple")
        if any(not _is_hashable(action) for action in actions) or len(set(actions)) != len(actions):
            raise ValueError("actions must contain unique hashable values")
        signature = (player, actions)
        declared = self._signatures.get(key)
        existing = self._trainer._nodes.get(key)
        if declared is not None and declared != signature:
            raise ValueError("a frozen information key must keep the same player and legal actions")
        if existing is not None and (existing.player, existing.actions) != signature:
            raise ValueError("frozen strategy query does not match the registered information set")
        if declared is None:
            self._signatures[key] = signature
        if self._trainer.strategy_provider is not None:
            if key not in self._external:
                raw = self._trainer.strategy_provider(player, key, actions)
                if (not isinstance(raw, Sequence) or isinstance(raw, (str, bytes))
                        or len(raw) != len(actions)
                        or any(isinstance(v, bool) or not isinstance(v, (int, float))
                               or not math.isfinite(v) or v < 0 for v in raw)
                        or not math.isclose(math.fsum(raw), 1.0, rel_tol=1e-9, abs_tol=1e-12)):
                    raise ValueError("strategy_provider must return finite action probabilities summing to one")
                self._external[key] = tuple(float(v) for v in raw)
                self._regrets[key] = ()  # Preserve the visited-key instrumentation API.
            return self._external[key]
        if key not in self._regrets:
            self._regrets[key] = (
                tuple(existing.regrets)
                if existing is not None
                else tuple(0.0 for _ in actions)
            )
        return _regret_strategy(self._regrets[key])


class MCCFRTrainer:
    """External-sampling trainer with atomic per-traverser updates.

    A leaf provider must return cooperatively: a blocking callback cannot be
    preempted, and the deadline is checked immediately after it returns.  A
    failed traverser drops only its pending deltas; earlier traversers remain
    committed and random-generator state is not rolled back.
    """

    def __init__(
        self,
        game: ExtensiveGame,
        seed: int = 0,
        exploration: float = 0.1,
        leaf_evaluator: Callable[[Any, int, FrozenStrategy], float | None] | None = None,
        sample_sink: Any = None,
        strategy_provider: Callable[[int, Hashable, tuple[Hashable, ...]], Sequence[float]] | None = None,
        retain_tables: bool = True,
        *,
        opponent_sampling: str = "exploratory",
        regret_only: bool = False,
    ):
        players = getattr(game, "num_players", None)
        if isinstance(players, bool) or not isinstance(players, int) or not 2 <= players <= 9:
            raise ValueError("num_players must be an integer from 2 through 9")
        if isinstance(seed, bool) or not isinstance(seed, int):
            raise ValueError("seed must be an integer")
        if (
            isinstance(exploration, bool)
            or not isinstance(exploration, (int, float))
            or not math.isfinite(exploration)
            or not 0.0 < float(exploration) <= 1.0
        ):
            raise ValueError("exploration must be finite and in (0, 1]")
        self.game = game
        self.num_players = players
        self.chance_mode = getattr(game, "chance_mode", "enumerable")
        if self.chance_mode not in ("enumerable", "sampled_on_policy"):
            raise ValueError("chance_mode must be 'enumerable' or 'sampled_on_policy'")
        if self.chance_mode == "sampled_on_policy" and not callable(
            getattr(game, "sample_chance_on_policy", None)
        ):
            raise ValueError("sampled_on_policy games must define sample_chance_on_policy")
        if leaf_evaluator is not None and not callable(leaf_evaluator):
            raise ValueError("leaf_evaluator must be callable or None")
        if sample_sink is not None and not callable(getattr(sample_sink, "commit", None)):
            raise ValueError("sample_sink must provide atomic commit(batch)")
        if strategy_provider is not None and not callable(strategy_provider):
            raise ValueError("strategy_provider must be callable or None")
        if type(retain_tables) is not bool or (not retain_tables and strategy_provider is None):
            raise ValueError("retain_tables must be bool; table-free collection requires a strategy provider")
        if not isinstance(opponent_sampling, str) or opponent_sampling not in ("exploratory", "on-policy"):
            raise ValueError("opponent_sampling must be 'exploratory' or 'on-policy'")
        if type(regret_only) is not bool:
            raise ValueError("regret_only must be bool")
        self.sample_sink = sample_sink
        self.strategy_provider = strategy_provider
        self.retain_tables = retain_tables
        self.exploration = float(exploration)
        self.opponent_sampling = opponent_sampling
        self.regret_only = regret_only
        self.leaf_evaluator = leaf_evaluator
        self._rng = random.Random(seed)
        self._nodes: dict[Hashable, _Node] = {}
        self._counts = {
            "iterations_completed": 0,
            "traversals_completed": 0,
            "traversals_aborted": 0,
            "nodes_touched": 0,
            "regret_updates": 0,
            "average_updates": 0,
            "leaf_values_evaluated": 0,
        }
        self._last_stop_reason: str | None = None
        self._training = False

    @property
    def diagnostics(self) -> dict[str, Any]:
        result = {
            **self._counts,
            "information_sets": len(self._nodes),
            "last_stop_reason": self._last_stop_reason,
            "algorithm": "external-sampling-mccfr",
            "chance_mode": self.chance_mode,
            "multiplayer_guarantee": False,
            "experimental_leaf_evaluator": self.leaf_evaluator is not None,
            "leaf_evaluator_quality_qualified": False,
            "external_strategy": self.strategy_provider is not None,
            "retains_tables": self.retain_tables,
            "sample_collection": self.sample_sink is not None,
        }
        if self.opponent_sampling != "exploratory":
            result["opponent_sampling"] = self.opponent_sampling
        if self.regret_only:
            result["regret_only"] = True
        return result

    def _proposal(
        self, strategy: tuple[float, ...], player: int, traverser: int
    ) -> tuple[float, ...]:
        if player != traverser and self.opponent_sampling == "on-policy":
            return strategy
        return tuple(
            (1.0 - self.exploration) * probability + self.exploration / len(strategy)
            for probability in strategy
        )

    def _sample_proposal_index(
        self, probabilities: Sequence[float], player: int, traverser: int
    ) -> int:
        if player == traverser or self.opponent_sampling != "on-policy":
            return self._sample_index(probabilities)
        target = self._rng.random()
        cumulative = 0.0
        last_positive = None
        for index, probability in enumerate(probabilities):
            cumulative += probability
            if probability > 0.0:
                last_positive = index
            if target < cumulative:
                return index
        if last_positive is None:
            raise ValueError("on-policy opponent proposal must contain positive probability")
        return last_positive

    def _actions_and_strategy(
        self,
        state: Any,
        player: int,
        snapshot: FrozenStrategy,
        deltas: dict[Hashable, _Delta],
    ) -> tuple[Hashable, tuple[Hashable, ...], tuple[float, ...]]:
        actions = self.game.legal_actions(state)
        if not isinstance(actions, tuple) or not actions:
            raise ValueError("legal_actions must return a non-empty tuple")
        if any(not _is_hashable(action) for action in actions) or len(set(actions)) != len(actions):
            raise ValueError("legal actions must be unique hashable values")
        key = self.game.information_key(state)
        if not _is_hashable(key):
            raise ValueError("information_key must be hashable")
        existing = self._nodes.get(key)
        pending = deltas.get(key)
        expected_player = existing.player if existing is not None else pending.player if pending is not None else player
        expected_actions = existing.actions if existing is not None else pending.actions if pending is not None else actions
        if expected_player != player or expected_actions != actions:
            raise ValueError("an information key must keep the same player and legal actions")
        if pending is None:
            pending = _Delta(player, actions, [0.0] * len(actions), [0.0] * len(actions))
            deltas[key] = pending
        strategy = snapshot.probabilities(player, key, actions)
        return key, actions, strategy

    def _chance(self, state: Any) -> tuple[tuple[Hashable, float], ...]:
        raw = self.game.chance_outcomes(state)
        try:
            outcomes = tuple(raw)
        except TypeError as exc:
            raise ValueError("chance_outcomes must be iterable") from exc
        if not outcomes:
            raise ValueError("chance_outcomes cannot be empty")
        actions: set[Hashable] = set()
        total = 0.0
        checked: list[tuple[Hashable, float]] = []
        for item in outcomes:
            if not isinstance(item, tuple) or len(item) != 2:
                raise ValueError("chance outcomes must be (action, probability) pairs")
            action, probability = item
            if not _is_hashable(action) or action in actions:
                raise ValueError("chance actions must be unique and hashable")
            if (
                isinstance(probability, bool)
                or not isinstance(probability, (int, float))
                or not math.isfinite(probability)
                or probability <= 0.0
            ):
                raise ValueError("chance probabilities must be finite and positive")
            probability = float(probability)
            actions.add(action)
            checked.append((action, probability))
            total += probability
        if not math.isclose(total, 1.0, rel_tol=1e-9, abs_tol=1e-12):
            raise ValueError("chance probabilities must sum to one")
        return tuple(checked)

    def _terminal_value(self, state: Any, traverser: int) -> float:
        values = self.game.returns(state)
        if not isinstance(values, Sequence) or len(values) != self.num_players:
            raise ValueError("terminal returns must contain one value per player")
        converted: list[float] = []
        for value in values:
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError("terminal returns must be finite numbers")
            converted.append(float(value))
        magnitude = math.fsum(abs(value) for value in converted)
        tolerance = max(1e-9, 1e-12 * magnitude)
        if not math.isclose(math.fsum(converted), 0.0, rel_tol=0.0, abs_tol=tolerance):
            raise ValueError("terminal returns must be zero-sum net rewards")
        return converted[traverser]

    def _sample_index(self, probabilities: Sequence[float]) -> int:
        target = self._rng.random()
        cumulative = 0.0
        for index, probability in enumerate(probabilities):
            cumulative += probability
            if target < cumulative:
                return index
        return len(probabilities) - 1

    def _traverse(
        self,
        state: Any,
        traverser: int,
        reaches: tuple[float, ...],
        chance_reach: float,
        sample_reach: float,
        snapshot: FrozenStrategy,
        deltas: dict[Hashable, _Delta],
        sampled_actions: dict[tuple[int, Hashable], Hashable],
        context: _Context,
    ) -> float:
        context.touch()
        if self.game.is_terminal(state):
            return self._terminal_value(state, traverser)
        player = self.game.current_player(state)
        if isinstance(player, bool) or not isinstance(player, int) or player < CHANCE or player >= self.num_players:
            raise ValueError("current_player must be chance (-1) or a valid player")
        if player == CHANCE:
            # Opt-in continuation boundary, before a fixed rollout chance action.
            # This is a single traverser's conditional value, not a vector of
            # terminal rewards; independently conditioned player values need not
            # sum to zero. The existing path importance ratios remain unchanged.
            evaluate_chance = getattr(self.leaf_evaluator, "evaluate_chance", None)
            if callable(evaluate_chance):
                value = evaluate_chance(state, traverser, snapshot)
                context.check_deadline()
                if value is not None:
                    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                        raise ValueError("chance leaf must return a finite scalar or None")
                    context.leaf_values_evaluated += 1
                    return float(value)
            if self.chance_mode == "sampled_on_policy":
                action = self.game.sample_chance_on_policy(state, self._rng)
                if not _is_hashable(action):
                    raise ValueError("sample_chance_on_policy must return a hashable action")
                # The sampler is the game's fixed target chance kernel.  Its
                # target/proposal ratio is exactly one, so no numerical chance
                # probability is needed.  Chance visitation mass is a fixed
                # per-infoset factor in the normalized average strategy.
                return self._traverse(
                    self.game.next_state(state, action),
                    traverser,
                    reaches,
                    chance_reach,
                    sample_reach,
                    snapshot,
                    deltas,
                    sampled_actions,
                    context,
                )
            outcomes = self._chance(state)
            index = self._sample_index([probability for _, probability in outcomes])
            action, probability = outcomes[index]
            return self._traverse(
                self.game.next_state(state, action),
                traverser,
                reaches,
                chance_reach * probability,
                sample_reach * probability,
                snapshot,
                deltas,
                sampled_actions,
                context,
            )

        if self.leaf_evaluator is not None:
            value = self.leaf_evaluator(state, traverser, snapshot)
            context.check_deadline()
            if value is not None:
                if (
                    isinstance(value, bool)
                    or not isinstance(value, (int, float))
                    or not math.isfinite(value)
                ):
                    raise ValueError("leaf_evaluator must return a finite non-boolean scalar or None")
                context.leaf_values_evaluated += 1
                return float(value)

        key, actions, strategy = self._actions_and_strategy(state, player, snapshot, deltas)
        if player != traverser:
            if self.sample_sink is not None and not self.regret_only:
                context.strategies.append(StrategySample(
                    context.iteration, context.traversal_id, player, key, actions,
                    strategy, reaches[player] / sample_reach))
            sampling = self._proposal(strategy, player, traverser)
            sample_key = (player, key)
            if sample_key not in sampled_actions:
                action = actions[self._sample_proposal_index(sampling, player, traverser)]
                sampled_actions[sample_key] = action
            else:
                action = sampled_actions[sample_key]
            index = actions.index(action)
            if sampling[index] <= 0.0:
                raise ValueError("sampled opponent action must have positive proposal probability")
            updated = list(reaches)
            updated[player] *= strategy[index]
            child = self._traverse(
                self.game.next_state(state, action),
                traverser,
                tuple(updated),
                chance_reach,
                sample_reach * sampling[index],
                snapshot,
                deltas,
                sampled_actions,
                context,
            )
            if self.regret_only and self.opponent_sampling == "on-policy":
                return child
            return child * strategy[index] / sampling[index]

        children: list[float] = []
        for index, action in enumerate(actions):
            updated = list(reaches)
            updated[player] *= strategy[index]
            children.append(
                self._traverse(
                    self.game.next_state(state, action),
                    traverser,
                    tuple(updated),
                    chance_reach,
                    sample_reach,
                    snapshot,
                    deltas,
                    sampled_actions,
                    context,
                )
            )
        node_value = sum(probability * value for probability, value in zip(strategy, children, strict=True))
        if self.regret_only and self.opponent_sampling == "on-policy":
            regret_weight = 1.0
        else:
            counterfactual = chance_reach
            for other, reach in enumerate(reaches):
                if other != traverser:
                    counterfactual *= reach
            regret_weight = counterfactual / sample_reach
        sampled_regrets = tuple(regret_weight * (value - node_value) for value in children)
        if self.sample_sink is not None:
            context.advantages.append(AdvantageSample(
                context.iteration, context.traversal_id, player, key, actions,
                strategy, tuple(children), node_value, regret_weight, sampled_regrets))
        delta = deltas[key]
        if not self.regret_only:
            average_weight = reaches[traverser] / sample_reach
        for index, probability in enumerate(strategy):
            delta.regrets[index] += sampled_regrets[index]
            if not self.regret_only:
                delta.strategy_sum[index] += average_weight * probability
        return node_value

    def _commit(self, deltas: dict[Hashable, _Delta]) -> None:
        for key, delta in deltas.items():
            if not self.retain_tables:
                self._counts["regret_updates"] += len(delta.actions)
                if not self.regret_only:
                    self._counts["average_updates"] += len(delta.actions)
                continue
            node = self._nodes.get(key)
            if node is None:
                node = _Node(delta.player, delta.actions, [0.0] * len(delta.actions), [0.0] * len(delta.actions))
                self._nodes[key] = node
            for index in range(len(delta.actions)):
                node.regrets[index] += delta.regrets[index]
                if not self.regret_only:
                    node.strategy_sum[index] += delta.strategy_sum[index]
            self._counts["regret_updates"] += len(delta.actions)
            if not self.regret_only:
                self._counts["average_updates"] += len(delta.actions)

    def train(
        self, iterations: int, deadline: float | None = None, max_nodes: int | None = None
    ) -> dict[str, Any]:
        if self._training:
            raise ValueError("train cannot be re-entered while a traversal is active")
        self._training = True
        try:
            return self._train(iterations, deadline=deadline, max_nodes=max_nodes)
        finally:
            self._training = False

    def _train(
        self, iterations: int, deadline: float | None = None, max_nodes: int | None = None,
        *, selected_traverser: int | None = None, sample_iteration: int | None = None,
    ) -> dict[str, Any]:
        """Train sequential traversers; ``deadline`` is an absolute perf-counter time."""

        if isinstance(iterations, bool) or not isinstance(iterations, int) or iterations < 1:
            raise ValueError("iterations must be a positive integer")
        if deadline is not None and (
            isinstance(deadline, bool) or not isinstance(deadline, (int, float)) or not math.isfinite(deadline)
        ):
            raise ValueError("deadline must be a finite absolute perf-counter time")
        if max_nodes is not None and (
            isinstance(max_nodes, bool) or not isinstance(max_nodes, int) or max_nodes < 0
        ):
            raise ValueError("max_nodes must be a non-negative integer")
        context = _Context(float(deadline) if deadline is not None else None, max_nodes)
        self._last_stop_reason = None
        call_iterations = 0
        call_traversals = 0
        aborted = False
        for _ in range(iterations):
            completed_players = 0
            players = range(self.num_players) if selected_traverser is None else (selected_traverser,)
            for traverser in players:
                snapshot = FrozenStrategy(self)
                deltas: dict[Hashable, _Delta] = {}
                context.advantages.clear()
                context.strategies.clear()
                context.iteration = sample_iteration if sample_iteration is not None else self._counts["iterations_completed"] + 1
                context.traversal_id = self._counts["traversals_completed"] + self._counts["traversals_aborted"] + 1
                try:
                    self._traverse(
                        self.game.initial_state(),
                        traverser,
                        tuple(1.0 for _ in range(self.num_players)),
                        1.0,
                        1.0,
                        snapshot,
                        deltas,
                        {},
                        context,
                    )
                    context.check_deadline()
                    # Validate before either owner commits. A custom sink must
                    # implement atomic commit; arbitrary callback side effects
                    # cannot be rolled back by this trainer.
                    for key, delta in deltas.items():
                        node = self._nodes.get(key)
                        for index in range(len(delta.actions)):
                            before_regret = node.regrets[index] if node is not None else 0.0
                            before_average = node.strategy_sum[index] if node is not None else 0.0
                            if not all(math.isfinite(v) for v in (
                                before_regret + delta.regrets[index], before_average + delta.strategy_sum[index])):
                                raise ValueError("traversal update became non-finite")
                    if self.sample_sink is not None:
                        self.sample_sink.commit(TraversalBatch(
                            context.iteration, context.traversal_id, traverser,
                            tuple(context.advantages), tuple(context.strategies)))
                except _AbortTraversal:
                    self._counts["traversals_aborted"] += 1
                    aborted = True
                    break
                except Exception:
                    self._counts["traversals_aborted"] += 1
                    self._counts["nodes_touched"] += context.nodes
                    self._counts["leaf_values_evaluated"] += context.leaf_values_evaluated
                    self._last_stop_reason = "error"
                    raise
                finally:
                    snapshot.invalidate()
                self._commit(deltas)
                self._counts["traversals_completed"] += 1
                call_traversals += 1
                completed_players += 1
            if selected_traverser is None and completed_players == self.num_players:
                self._counts["iterations_completed"] += 1
                call_iterations += 1
            if aborted:
                break
        self._counts["nodes_touched"] += context.nodes
        self._counts["leaf_values_evaluated"] += context.leaf_values_evaluated
        if context.deadline_hit:
            self._last_stop_reason = "deadline"
        elif context.node_limit_hit:
            self._last_stop_reason = "max_nodes"
        return {
            **self.diagnostics,
            "call_iterations_completed": call_iterations,
            "call_traversals_completed": call_traversals,
            "call_nodes_touched": context.nodes,
        }

    def collect(
        self, traverser: int, traversals: int, *, iteration: int,
        deadline: float | None = None, max_nodes: int | None = None,
    ) -> dict[str, Any]:
        """Collect K passes for one player under the caller's frozen provider.

        This does not count as an iteration over all players. The caller must
        not update a neural provider until this method returns.
        """
        if type(traverser) is not int or not 0 <= traverser < self.num_players:
            raise ValueError("traverser must be a valid player")
        if type(iteration) is not int or iteration < 1:
            raise ValueError("iteration must be a positive integer")
        if self._training:
            raise ValueError("collect cannot be re-entered")
        self._training = True
        try:
            return self._train(traversals, deadline, max_nodes,
                               selected_traverser=traverser, sample_iteration=iteration)
        finally:
            self._training = False

    def has_average_policy(self, key: Hashable) -> bool:
        """Whether a key has positive averaging mass, rather than a fallback."""
        if not _is_hashable(key):
            raise ValueError("key must be hashable")
        if self.regret_only:
            return False
        node = self._nodes.get(key)
        return node is not None and sum(node.strategy_sum) > 0.0

    def average_policy(
        self, key: Hashable, actions: tuple[Hashable, ...]
    ) -> dict[Hashable, float]:
        if self.regret_only:
            raise ValueError("average_policy is unavailable in regret-only mode")
        if not _is_hashable(key):
            raise ValueError("key must be hashable")
        if not isinstance(actions, tuple) or not actions:
            raise ValueError("actions must be a non-empty tuple")
        if any(not _is_hashable(action) for action in actions) or len(set(actions)) != len(actions):
            raise ValueError("actions must contain unique hashable values")
        node = self._nodes.get(key)
        if node is not None and node.actions != actions:
            raise ValueError("actions do not match the registered information set")
        values = node.strategy_sum if node is not None else [0.0] * len(actions)
        total = sum(values)
        probabilities = [value / total for value in values] if total > 0.0 else [1.0 / len(actions)] * len(actions)
        return dict(zip(actions, probabilities, strict=True))
