"""Private-information policy features for offline continuation experiments."""

from __future__ import annotations

import math
from functools import lru_cache
from itertools import permutations
from typing import Any

import numpy as np

from .belief import DECK
from .continuation_policy import _actions, _key
from .contracts import PokerError
from .evaluator import evaluate_hand as evaluate_hand_python
from . import native_kernel

POLICY_FEATURE_VERSION = "private-policy-v1"
ZERO_MADE_POLICY_FEATURE_VERSION = "private-policy-v2-zero-made"
MADE_POLICY_FEATURE_VERSION = "private-policy-v2-made"
POKER_POLICY_FEATURE_VERSION = "private-policy-v3-poker"
SUPPORTED_POLICY_FEATURE_VERSIONS = frozenset(
    {POLICY_FEATURE_VERSION, ZERO_MADE_POLICY_FEATURE_VERSION, MADE_POLICY_FEATURE_VERSION, POKER_POLICY_FEATURE_VERSION}
)
DECISION_FEATURE_DIM = 17
DECISION_PLAYER_FEATURE_DIM = 4
DECISION_ACTION_FEATURE_DIM = 4
MADE_HAND_FEATURE_DIM = 80
MAX_SEATS = 9
CARD_ROWS = 7
CARD_COUNT = 52
PLAYER_FEATURE_DIM = 11
CONTEXT_FEATURE_DIM = 12
HISTORY_FEATURE_DIM = 20
ACTION_FEATURE_DIM = 9

STREETS = ("preflop", "flop", "turn", "river")
STATUSES = ("active", "folded", "all_in", "out")
ANTE_MODES = ("none", "uniform", "big_blind")
BBA_ORDERS = ("ante_first", "blind_first")
ACTION_KINDS = ("fold", "check", "call", "bet", "raise")

_CARD_INDEX = {card: index for index, card in enumerate(DECK)}
_SUITS = "cdhs"


def _made_hand_feature(
    holes: tuple[str, ...], board: tuple[str, ...], feature_version: str
) -> np.ndarray:
    result = np.zeros(MADE_HAND_FEATURE_DIM, dtype=np.float32)
    if feature_version == ZERO_MADE_POLICY_FEATURE_VERSION or not board:
        return result
    if feature_version not in (MADE_POLICY_FEATURE_VERSION, POKER_POLICY_FEATURE_VERSION):
        raise PokerError("made hand 特征版本无效")
    rank = _rank_known_cards((*holes, *board))
    category, kickers = rank[0], rank[1:]
    if not 0 <= category <= 8 or len(kickers) > 5:
        raise PokerError("精确牌型编码无效")
    result[0] = 1.0
    result[1 + category] = 1.0
    for slot, value in enumerate(kickers):
        if not 2 <= value <= 14:
            raise PokerError("精确牌型 kicker 无效")
        result[10 + slot * 13 + value - 2] = 1.0
        result[75 + slot] = 1.0
    return result


def _log_ratio(numerator: int, denominator: int, name: str) -> float:
    """Compute log1p(numerator / denominator) without bigint-to-float overflow."""

    if numerator < 0 or denominator <= 0:
        raise PokerError(f"{name} 金额无效")
    if numerator == 0:
        return 0.0
    try:
        result = math.log(numerator + denominator) - math.log(denominator)
    except (OverflowError, ValueError) as exc:
        raise PokerError(f"{name} 无法编码") from exc
    if not math.isfinite(result):
        raise PokerError(f"{name} 产生非有限特征")
    return result


def _float32(values: Any, name: str) -> np.ndarray:
    try:
        result = np.asarray(values, dtype=np.float32)
    except (TypeError, ValueError, OverflowError) as exc:
        raise PokerError(f"{name} 无法转换为 float32") from exc
    if not np.isfinite(result).all():
        raise PokerError(f"{name} 包含非有限值或发生 float32 溢出")
    return result


@lru_cache(maxsize=8192)
def _canonical_cards(holes: tuple[str, ...], board: tuple[str, ...]) -> tuple[str, ...]:
    """Choose the minimum signature among all 24 global suit renamings."""

    best: tuple[str, ...] | None = None
    for target in permutations(_SUITS):
        suit_map = dict(zip(_SUITS, target, strict=True))

        def rename(card: str) -> str:
            return card[0] + suit_map[card[1]]

        renamed_holes = tuple(sorted(map(rename, holes), key=_CARD_INDEX.__getitem__))
        flop = tuple(sorted(map(rename, board[:3]), key=_CARD_INDEX.__getitem__))
        signature = (*renamed_holes, *flop, *(rename(card) for card in board[3:]))
        if best is None or signature < best:
            best = signature
    assert best is not None
    return best


@lru_cache(maxsize=8192)
def _rank_known_cards(cards: tuple[str, ...]) -> tuple[int, ...]:
    """Rank validated known cards, falling back only when native loading fails."""

    try:
        native_kernel.load_native()
    except (RuntimeError, OSError):
        return tuple(evaluate_hand_python(cards))
    return tuple(native_kernel.evaluate_hand(cards))


def encode_policy(
    player: int,
    key: Any,
    actions: Any,
    *,
    feature_version: str = POLICY_FEATURE_VERSION,
) -> dict[str, Any]:
    """Encode one validated finite-NLHE information set and its candidates."""
    return _encode_policy(player, key, actions, feature_version=feature_version)


def encode_policy_batch(requests, *, feature_version=POLICY_FEATURE_VERSION):
    """Share public tensors within a batch, never private card features."""
    shared, features = {}, []
    for request in requests:
        if not isinstance(request, (tuple, list)) or len(request) != 3:
            raise PokerError("policy batch requires player/key/actions triples")
        features.append(_encode_policy(*request, feature_version=feature_version, shared=shared))
    return features


def _encode_policy(player, key, actions, *, feature_version, shared=None):

    if not isinstance(feature_version, str) or feature_version not in SUPPORTED_POLICY_FEATURE_VERSIONS:
        raise PokerError("policy feature_version 不受支持")
    if isinstance(player, bool) or not isinstance(player, int) or not 0 <= player < MAX_SEATS:
        raise PokerError("player 必须为 0 到 8 的整数")
    normalized_key = _key(key, expected_player=player)
    normalized_actions = _actions(actions)
    _, actor, button, street, holes, board, raw_players, raw_rules, events = normalized_key
    player_count = len(raw_players)
    rules = dict(raw_rules)
    big_blind = int(rules["big_blind"])
    small_blind = int(rules["small_blind"])
    ante = int(rules["ante"])

    cards = np.zeros((CARD_ROWS, CARD_COUNT), dtype=np.float32)
    for row, card in enumerate(_canonical_cards(holes, board)):
        cards[row, _CARD_INDEX[card]] = 1.0

    public = (*normalized_key[:4], (), *normalized_key[5:]), normalized_actions
    if shared is not None and shared.get("key") == public:
        result = {**shared["features"], "cards": cards}
        if feature_version != POLICY_FEATURE_VERSION:
            result["made_hand"] = _made_hand_feature(holes, board, feature_version)
        return result

    seat_mask = np.zeros(MAX_SEATS, dtype=np.bool_)
    seat_mask[:player_count] = True
    player_features = np.zeros((MAX_SEATS, PLAYER_FEATURE_DIM), dtype=np.float64)
    for relative in range(player_count):
        physical = (actor + relative) % player_count
        item = raw_players[physical]
        amounts = tuple(int(value) for value in item[1:6])
        player_features[relative, :5] = tuple(
            _log_ratio(value, big_blind, f"players[{physical}]") for value in amounts
        )
        player_features[relative, 5 + STATUSES.index(item[6])] = 1.0
        player_features[relative, 9] = float(physical == actor)
        player_features[relative, 10] = float(physical == button)

    context = np.zeros(CONTEXT_FEATURE_DIM, dtype=np.float64)
    context[STREETS.index(street)] = 1.0
    context[4] = _log_ratio(small_blind, big_blind, "small_blind")
    context[5] = _log_ratio(ante, big_blind, "ante")
    context[6 + ANTE_MODES.index(rules["ante_mode"])] = 1.0
    context[9 + BBA_ORDERS.index(rules["bba_order"])] = 1.0
    context[11] = player_count / MAX_SEATS

    history_length = len(events)
    history = np.zeros((max(1, history_length), HISTORY_FEATURE_DIM), dtype=np.float64)
    for index, event in enumerate(events):
        event_seat, kind, amount_to, put_in, event_street, _ = event
        history[index, (event_seat - actor) % player_count] = 1.0
        history[index, 9 + STREETS.index(event_street)] = 1.0
        history[index, 13 + ACTION_KINDS.index(kind)] = 1.0
        history[index, 18] = _log_ratio(int(amount_to), big_blind, f"events[{index}].amount_to")
        history[index, 19] = _log_ratio(int(put_in), big_blind, f"events[{index}].put_in")

    actor_item = raw_players[actor]
    actor_stack = int(actor_item[1])
    actor_street_paid = int(actor_item[5])
    wager_level = max(int(item[5]) for item in raw_players)
    # BettingRound.wager_level preserves the nominal big-blind wager before the
    # flop when a short blind (including one exhausted by an ante) posted less
    # than the blind and another active player with chips can still respond.
    if street == "preflop" and any(
        seat != actor and item[6] == "active" and int(item[1]) > 0
        for seat, item in enumerate(raw_players)
    ):
        wager_level = max(wager_level, big_blind)
    to_call = min(actor_stack, max(0, wager_level - actor_street_paid))
    pot = sum(int(item[3]) for item in raw_players)
    denominator = pot + to_call + big_blind
    action_features = np.zeros((len(normalized_actions), ACTION_FEATURE_DIM), dtype=np.float64)
    for index, (kind, declared_amount) in enumerate(normalized_actions):
        action_features[index, ACTION_KINDS.index(kind)] = 1.0
        if kind == "call":
            amount_to = to_call
            increment = to_call
        elif kind in ("bet", "raise"):
            assert declared_amount is not None
            amount_to = declared_amount
            increment = amount_to - actor_street_paid
            if increment <= 0 or increment > actor_stack:
                raise PokerError(f"actions[{index}] 的下注金额超出当前筹码或未增加下注")
        else:
            amount_to = 0
            increment = 0
        action_features[index, 5] = _log_ratio(amount_to, big_blind, f"actions[{index}].amount_to")
        action_features[index, 6] = _log_ratio(increment, big_blind, f"actions[{index}].increment")
        action_features[index, 7] = _log_ratio(increment, denominator, f"actions[{index}].pot_fraction")
        action_features[index, 8] = float(increment > 0 and increment == actor_stack)

    result = {
        "version": feature_version,
        "cards": cards,
        "players": _float32(player_features, "players 特征"),
        "context": _float32(context, "context 特征"),
        "history": _float32(history, "history 特征"),
        "actions": _float32(action_features, "actions 特征"),
        "seat_mask": seat_mask,
        "history_length": history_length,
    }
    if feature_version != POLICY_FEATURE_VERSION:
        result["made_hand"] = _made_hand_feature(holes, board, feature_version)
    if feature_version == POKER_POLICY_FEATURE_VERSION:
        result.update(_decision_features(normalized_key, normalized_actions))
    if shared is not None:
        shared.update(key=public, features=result)
    return result


def _decision_features(key, actions):
    from .policy_betting_state import public_betting_state
    _, actor, _, street, _, _, players, raw_rules, events = key
    rules = dict(raw_rules)
    bb = int(rules["big_blind"])
    state = public_betting_state(actor, street, players, events, bb)
    call = state.to_call()
    assert call is not None
    bounds = state.raise_bounds()
    low, high = bounds if bounds is not None else (0, 0)
    stack, paid = state.stacks[actor], state.bets[actor]
    contributions = [int(p[3])-int(p[4]) for p in players]
    if any(x < 0 for x in contributions):
        raise PokerError("committed chips cannot be smaller than paid antes")
    pot = sum(int(p[3]) for p in players)
    dead = sum(int(p[4]) for p in players)
    cap = contributions[actor]+call
    # Unmatched layers above the hero's post-call contribution are not winnable.
    eligible = dead + sum(min(x, cap) for x in contributions)
    raisers = sum(e[1] in ("bet", "raise") and e[4] == street for e in events)
    log = lambda x: _log_ratio(x, bb, "decision BB amount")
    decision = [log(pot), log(call), call/(eligible+call) if call else 0.0,
                log(eligible), log(stack), log(low), log(high), float(bounds is not None),
                log(state.full_increment), log(state.wager_level()),
                sum(state.active)/MAX_SEATS,
                sum(a and s == 0 for a, s in zip(state.active, state.stacks, strict=True))/MAX_SEATS,
                raisers/(1+raisers), log(int(players[actor][3])), log(paid),
                log(state.nominal_floor), call/stack if stack else 0.0]
    pairs = np.zeros((MAX_SEATS, DECISION_PLAYER_FEATURE_DIM), dtype=np.float64)
    for relative in range(1, len(players)):
        other = (actor+relative) % len(players)
        if not state.active[other]:
            continue
        street_effective = min(stack+paid, state.stacks[other]+state.bets[other])
        remaining_effective = min(stack, state.stacks[other])
        pairs[relative] = (1, log(street_effective), log(remaining_effective),
                           _log_ratio(remaining_effective, max(pot, 1), "pairwise remaining SPR"))
    extras = np.zeros((len(actions), DECISION_ACTION_FEATURE_DIM), dtype=np.float64)
    passive = {kind for kind, _ in state.legal_actions()}
    aggressive = "raise" if state.nominal_floor or max(state.bets) else "bet"
    for index, (kind, amount) in enumerate(actions):
        if kind in ("bet", "raise"):
            if kind != aggressive or bounds is None or not low <= amount <= high:
                raise PokerError("candidate is outside reconstructed legal raise bounds")
            increment = amount-paid
            interval = (amount-low)/(high-low) if high > low else 0.0
        else:
            if kind not in passive:
                raise PokerError("candidate is not legal in reconstructed betting state")
            increment, interval = (call if kind == "call" else 0), 0.0
        extras[index] = (_log_ratio(increment, max(pot+call, 1), "candidate pot fraction"),
                         increment/stack if stack else 0.0,
                         _log_ratio(max(0, increment-call), max(pot+call, 1), "candidate raise fraction"),
                         interval)
    return {"decision": _float32(decision, "decision"),
            "decision_players": _float32(pairs, "decision_players"),
            "decision_actions": _float32(extras, "decision_actions")}
