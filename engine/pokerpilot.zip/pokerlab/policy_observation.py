"""Bridge private information-set policies to observation-only full-hand matches."""
from __future__ import annotations

from collections.abc import Mapping, Sequence
import math

from .action_menu import FULL_ACTION_MENU, raise_targets, validate_action_menu
from .continuation_policy import _key
from .contracts import PokerError, chips
from .poker_game import FinitePokerGame
from .solver import _validate


def _information_key(data):
    actor = data['actor']
    players = tuple((p['seat'], str(chips(p['stack'])), str(chips(p['starting_stack'])),
                     str(chips(p['committed'])), str(chips(p.get('ante_paid', 0))),
                     str(chips(p['street_committed'])), p['status']) for p in data['players'])
    events = tuple((e['seat'], e['kind'], str(chips(e['amount_to'])), str(chips(e['put_in'])),
                    e['street'], e['version']) for e in data['history'])
    key = ('finite-nlhe-v1', actor, data['button'], data['street'],
           tuple(sorted(data['hero_cards'])), tuple(data['board']), players,
           tuple(sorted(data['rules'].items())), events)
    return _key(key, expected_player=actor)


def information_key_from_observation(observation):
    """Rebuild only the visible key, with no fabricated hidden cards or deal."""
    return _information_key(_validate(observation))


def _finite_actions(data, fractions, action_menu=FULL_ACTION_MENU):
    menu = validate_action_menu(action_menu)
    paid = chips(data['players'][data['actor']]['street_committed'])
    pot, call = chips(data['pot']), chips(data['to_call'])
    result = []
    for legal in data['legal_actions']:
        kind = legal['kind']
        if kind not in ('bet', 'raise'):
            result.append((kind, None))
        else:
            low, high = chips(legal['min_to']), chips(legal['max_to'])
            targets = raise_targets(kind=kind, paid=paid, call=call, pot=pot, low=low,
                                    high=high, fractions=fractions, action_menu=menu)
            result.extend((kind, amount) for amount in targets)
    if len(set(result)) != len(result):
        raise PokerError('observation contains duplicate legal actions')
    return tuple(result)


def finite_actions_from_observation(
    observation, *, raise_fractions=(.5, 1.0), action_menu=FULL_ACTION_MENU
):
    """Match CompactPokerGame's finite betting menu, including exact call cost."""
    menu = validate_action_menu(action_menu)
    fractions = FinitePokerGame._validate_fractions(raise_fractions)
    return _finite_actions(_validate(observation), fractions, menu)


class InformationObservationPolicy:
    """Present a frozen information-set provider to the population evaluator."""

    def __init__(self, provider, *, raise_fractions=(.5, 1.0), action_menu=FULL_ACTION_MENU):
        if not callable(provider):
            raise ValueError('provider must be callable')
        self._provider = provider
        self._fractions = FinitePokerGame._validate_fractions(raise_fractions)
        self._action_menu = validate_action_menu(action_menu)

    @property
    def action_menu_version(self) -> str:
        return self._action_menu

    def __call__(self, observation):
        data = _validate(observation)
        key = _information_key(data)
        actions = _finite_actions(data, self._fractions, self._action_menu)
        raw = self._provider(data['actor'], key, actions)
        if isinstance(raw, Mapping):
            if set(raw) != set(actions):
                raise ValueError('provider mapping must contain exactly the offered actions')
            raw = tuple(raw[action] for action in actions)
        if isinstance(raw, (str, bytes)) or not isinstance(raw, Sequence) or len(raw) != len(actions):
            raise ValueError('provider must return one probability per offered action')
        if any(isinstance(p, bool) or not isinstance(p, (int, float))
               or not math.isfinite(p) or p < 0 for p in raw):
            raise ValueError('provider probabilities must be finite nonnegative real values')
        if not math.isclose(math.fsum(raw), 1.0, rel_tol=0.0, abs_tol=1e-12):
            raise ValueError('provider probabilities must sum to one')
        passive = {row['kind']: row['amount_to'] for row in data['legal_actions']
                   if row['kind'] not in ('bet', 'raise')}
        return [dict(kind=kind, amount_to=str(amount) if amount is not None else passive[kind],
                     probability=float(probability))
                for (kind, amount), probability in zip(actions, raw, strict=True)]
