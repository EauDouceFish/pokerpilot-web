"""Explicit, reproducible build of the optional portable C ABI kernel."""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[1]
COMPILER_VERSION = "0.13.0"
FLAGS = ("-shared", "-std=c++17", "-O3", "-DNDEBUG")


def _configuration() -> tuple[Path, list[str], dict]:
    if platform.system() != "Windows" or platform.machine().lower() not in ("amd64", "x86_64"):
        raise RuntimeError("Native build currently supports Windows x86-64 only")
    try:
        version = importlib.metadata.version("ziglang")
    except importlib.metadata.PackageNotFoundError as exc:
        raise RuntimeError("Install the optional native dependency: pip install '.[native]'") from exc
    if version != COMPILER_VERSION:
        raise RuntimeError(f"Expected ziglang {COMPILER_VERSION}, found {version}")
    flags = [*FLAGS, "-target", "x86_64-windows-gnu"]
    digest = hashlib.blake2b(digest_size=16)
    manifest = {"abi": 1, "compiler": f"ziglang-{version}", "flags": flags,
                "platform": "windows-x86_64", "sources": ["poker_core.h", "poker_core.cpp"]}
    digest.update(json.dumps(manifest, sort_keys=True).encode("utf-8"))
    for name in manifest["sources"]:
        digest.update(name.encode("utf-8"))
        digest.update((ROOT / "native" / name).read_bytes())
    key = digest.hexdigest()
    manifest["build_key_blake2b"] = key
    return ROOT / "artifacts" / "native" / key / "pokerlab_core.dll", flags, manifest


def artifact_path() -> Path:
    """Return the source-specific expected artifact; never start a compiler."""
    return _configuration()[0]


def build_native(force: bool = False) -> Path:
    """Compile explicitly and publish only a complete DLL via atomic replace."""
    target, flags, manifest = _configuration()
    if target.is_file() and not force:
        return target
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="build-", dir=target.parent) as temporary:
        output = Path(temporary) / target.name
        command = [sys.executable, "-m", "ziglang", "c++", *flags,
                   str(ROOT / "native" / "poker_core.cpp"), "-o", str(output)]
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True,
                                encoding="utf-8", errors="replace", timeout=600)
        if result.returncode:
            raise RuntimeError(f"Native build failed ({result.returncode}):\n{result.stderr}")
        # A loaded Windows DLL cannot be replaced. Preserve it and report the
        # OS error instead of deleting a working build before compilation.
        os.replace(output, target)
    (target.parent / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return target


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    print(build_native(force=args.force))


if __name__ == "__main__":
    main()
