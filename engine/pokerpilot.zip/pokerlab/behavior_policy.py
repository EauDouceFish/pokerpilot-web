"""Composable, observation-only behavior scripts for fast poker rollouts.

The formulas in this module are deliberately explicit and testable.  They are
behavioral fixtures for training and evaluation, not fitted models of humans or
claims of strategically reliable play.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, fields
import math
import random
from collections.abc import Mapping
from typing import Any

from pokerlab.contracts import PokerError, chips
from pokerlab.continuation_policy import _actions
from pokerlab.evaluator import parse_cards, evaluate_hand as evaluate_hand_python
from pokerlab.native_kernel import evaluate_hand
from pokerlab.solver import _candidate_actions, _validate


_RANKS = "23456789TJQKA"
_PRIVATE_KEYS = {"private_cards", "privatecards", "opponent_cards", "all_hole_cards", "holes"}


def _unit(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise PokerError(f"{name} 必须是有限数值")
    result = float(value)
    if not 0.0 <= result <= 1.0:
        raise PokerError(f"{name} 必须在 0 到 1 之间")
    return result


@dataclass(frozen=True, slots=True)
class BehaviorTraits:
    preflop_looseness: float
    aggression: float
    call_stickiness: float
    pressure_fear: float
    bluff: float
    sizing: float
    pair_attachment: float
    draw_chase: float
    position_awareness: float
    mistake_rate: float

    def __post_init__(self) -> None:
        for field in fields(self):
            object.__setattr__(self, field.name, _unit(getattr(self, field.name), field.name))


def _preset(**values: float) -> BehaviorTraits:
    return BehaviorTraits(**values)


def preset_traits() -> dict[str, BehaviorTraits]:
    """Return named, composable trait bundles; names do not imply strength."""

    return {
        "novice_curious": _preset(preflop_looseness=.72, aggression=.35, call_stickiness=.70,
            pressure_fear=.35, bluff=.25, sizing=.35, pair_attachment=.72, draw_chase=.72,
            position_awareness=.10, mistake_rate=.22),
        "calling_station": _preset(preflop_looseness=.82, aggression=.12, call_stickiness=.96,
            pressure_fear=.08, bluff=.05, sizing=.30, pair_attachment=.95, draw_chase=.88,
            position_awareness=.08, mistake_rate=.08),
        "fit_or_fold": _preset(preflop_looseness=.38, aggression=.32, call_stickiness=.18,
            pressure_fear=.72, bluff=.08, sizing=.50, pair_attachment=.38, draw_chase=.25,
            position_awareness=.45, mistake_rate=.05),
        "tight_weak": _preset(preflop_looseness=.12, aggression=.12, call_stickiness=.12,
            pressure_fear=.94, bluff=.03, sizing=.28, pair_attachment=.30, draw_chase=.14,
            position_awareness=.60, mistake_rate=.03),
        "loose_aggressive": _preset(preflop_looseness=.88, aggression=.86, call_stickiness=.58,
            pressure_fear=.20, bluff=.72, sizing=.68, pair_attachment=.62, draw_chase=.60,
            position_awareness=.55, mistake_rate=.10),
        "tight_aggressive_leaky": _preset(preflop_looseness=.24, aggression=.80, call_stickiness=.32,
            pressure_fear=.42, bluff=.38, sizing=.76, pair_attachment=.76, draw_chase=.30,
            position_awareness=.82, mistake_rate=.15),
        "maniac": _preset(preflop_looseness=.98, aggression=.99, call_stickiness=.66,
            pressure_fear=.04, bluff=.96, sizing=.90, pair_attachment=.65, draw_chase=.76,
            position_awareness=.12, mistake_rate=.18),
        "trapper": _preset(preflop_looseness=.35, aggression=.38, call_stickiness=.70,
            pressure_fear=.25, bluff=.18, sizing=.62, pair_attachment=.86, draw_chase=.42,
            position_awareness=.72, mistake_rate=.06),
        "draw_chaser": _preset(preflop_looseness=.70, aggression=.28, call_stickiness=.76,
            pressure_fear=.28, bluff=.15, sizing=.40, pair_attachment=.55, draw_chase=.99,
            position_awareness=.25, mistake_rate=.09),
        "timid_bluffer": _preset(preflop_looseness=.46, aggression=.45, call_stickiness=.20,
            pressure_fear=.90, bluff=.88, sizing=.55, pair_attachment=.35, draw_chase=.25,
            position_awareness=.48, mistake_rate=.14),
    }


def sample_traits(seed: int, count: int, *, jitter: float = .12) -> list[BehaviorTraits]:
    """Cycle through presets and add deterministic, bounded independent jitter."""

    if isinstance(seed, bool) or not isinstance(seed, int):
        raise PokerError("seed 必须是整数")
    if isinstance(count, bool) or not isinstance(count, int) or count < 0:
        raise PokerError("count 必须是非负整数")
    amount = _unit(jitter, "jitter")
    rng = random.Random(seed)
    bases = list(preset_traits().values())
    result = []
    for index in range(count):
        values = asdict(bases[index % len(bases)])
        changed = {
            name: max(0.0, min(1.0, value + rng.uniform(-amount, amount)))
            for name, value in values.items()
        }
        result.append(BehaviorTraits(**changed))
    return result


def _sigmoid(value: float) -> float:
    if value >= 0.0:
        inverse = math.exp(-min(value, 60.0))
        return 1.0 / (1.0 + inverse)
    exponent = math.exp(max(value, -60.0))
    return exponent / (1.0 + exponent)


def _preflop_strength(cards: list[str]) -> float:
    parsed = parse_cards(cards)
    ranks = sorted((rank for rank, _suit in parsed), reverse=True)
    pair = float(ranks[0] == ranks[1])
    suited = float(parsed[0][1] == parsed[1][1])
    gap = abs(ranks[0] - ranks[1])
    connected = max(0.0, 1.0 - max(0, gap - 1) / 5.0)
    strength = (
        .48 * ((ranks[0] - 2) / 12.0)
        + .18 * ((ranks[1] - 2) / 12.0)
        + .27 * pair + .04 * suited + .03 * connected
    )
    return max(0.0, min(1.0, strength))


def _postflop_strength(cards: list[str], rank_backend: str = "native") -> float:
    rank = evaluate_hand_python(cards) if rank_backend == "python" else evaluate_hand(cards)
    category = rank[0] / 8.0
    kicker = sum((part - 2) / 12.0 / (4 ** index) for index, part in enumerate(rank[1:]))
    return max(0.0, min(1.0, .80 * category + .20 * min(1.0, kicker)))


def _pair_attachment(hero: list[str], board: list[str]) -> bool:
    hero_ranks = [card[0].upper() for card in hero]
    board_ranks = {card[0].upper() for card in board}
    return hero_ranks[0] == hero_ranks[1] or any(rank in board_ranks for rank in hero_ranks)


def _preflop_position(actor: int, button: int, players: int) -> float:
    """Map physical seats to a simple preflop positional advantage in [0, 1]."""

    offset = (actor - button) % players
    if players == 2:
        return 1.0 if offset == 0 else 0.0
    if offset == 0:
        return 1.0
    if offset == 1:
        return 0.0
    if offset == 2:
        return .1
    if players == 4:
        return .8
    return .2 + .6 * (offset - 3) / (players - 4)


def _has_draw(hero: list[str], board: list[str]) -> bool:
    if len(board) not in (3, 4):
        return False
    parsed = parse_cards([*hero, *board])
    suits = [suit for _rank, suit in parsed]
    if any(suits.count(suit) == 4 for suit in "cdhs"):
        return True
    ranks = {rank for rank, _suit in parsed}
    if 14 in ranks:
        ranks.add(1)
    window_counts = [len(ranks.intersection(range(start, start + 5))) for start in range(1, 11)]
    return 5 not in window_counts and 4 in window_counts


def _action_groups(actions: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    groups = {"fold": [], "passive": [], "aggressive": []}
    for action in actions:
        kind = action["kind"]
        groups["fold" if kind == "fold" else "aggressive" if kind in ("bet", "raise") else "passive"].append(action)
    return {name: group for name, group in groups.items() if group}


def _score_behavior(
    traits: BehaviorTraits,
    data: Mapping[str, Any],
    actions: list[dict[str, Any]],
    rank_backend: str = "native",
) -> list[dict[str, Any]]:
    """Score an already validated minimal context and exact candidate list."""

    hero = list(data["hero_cards"])
    board = list(data["board"])
    street = data["street"]
    actor = data["actor"]
    raw_players = data["players"]
    players = raw_players if type(raw_players) is int else len(raw_players)
    strength = _preflop_strength(hero) if street == "preflop" else _postflop_strength([*hero, *board], rank_backend)
    attached = street != "preflop" and _pair_attachment(hero, board)
    drawing = street in ("flop", "turn") and _has_draw(hero, board)

    to_call = chips(data["to_call"])
    pot = chips(data["pot"])
    pressure = to_call / max(1.0, pot + to_call)
    if street == "preflop":
        position = _preflop_position(actor, data["button"], players)
        threshold = .68 - .42 * traits.preflop_looseness
        threshold -= .18 * traits.position_awareness * (position - .5)
    else:
        threshold = .43
    acceptance_score = (
        5.0 * (strength - threshold)
        - 4.0 * traits.pressure_fear * pressure
        + 1.8 * (traits.call_stickiness - .5)
        + (2.2 * traits.pair_attachment if attached else 0.0)
        + (2.2 * traits.draw_chase if drawing else 0.0)
    )
    acceptance = _sigmoid(acceptance_score)
    aggression_score = (
        4.0 * (traits.aggression - .5)
        + 5.0 * (strength - .5)
        + 2.0 * traits.bluff * (1.0 - strength)
    )
    aggressive_rate = .04 + .84 * _sigmoid(aggression_score)

    groups = _action_groups(actions)
    masses: dict[str, float]
    if "fold" in groups:
        continue_mass = acceptance
        aggressive_mass = continue_mass * aggressive_rate if "aggressive" in groups else 0.0
        masses = {"fold": 1.0 - continue_mass, "passive": continue_mass - aggressive_mass,
                  "aggressive": aggressive_mass}
    else:
        aggressive_mass = aggressive_rate if "aggressive" in groups else 0.0
        masses = {"passive": 1.0 - aggressive_mass, "aggressive": aggressive_mass}
    masses = {name: value for name, value in masses.items() if name in groups}
    total = math.fsum(masses.values())
    masses = {name: value / total for name, value in masses.items()}

    # Mistakes are uniform over semantic action groups, never over size candidates.
    uniform_group = 1.0 / len(groups)
    masses = {
        name: (1.0 - traits.mistake_rate) * masses.get(name, 0.0)
              + traits.mistake_rate * uniform_group
        for name in groups
    }
    probabilities: dict[tuple[str, str], float] = {}
    for name, group in groups.items():
        if name != "aggressive" or len(group) == 1:
            weights = [1.0 / len(group)] * len(group)
        else:
            target = .25 + 1.25 * traits.sizing
            scores = []
            for action in group:
                ratio = chips(action["put_in"]) / max(1.0, float(pot))
                distance = abs(math.log((ratio + .05) / (target + .05)))
                scores.append(-distance / .38)
            peak = max(scores)
            raw = [math.exp(score - peak) for score in scores]
            denominator = math.fsum(raw)
            weights = [value / denominator for value in raw]
        for action, weight in zip(group, weights, strict=True):
            probabilities[(action["kind"], action["amount_to"])] = masses[name] * weight

    output = [{**action, "probability": probabilities[(action["kind"], action["amount_to"])]}
              for action in actions]
    denominator = math.fsum(action["probability"] for action in output)
    if (not output or not math.isfinite(denominator) or denominator <= 0.0
            or any(not math.isfinite(action["probability"]) or action["probability"] < 0.0
                   for action in output)):
        raise PokerError("行为策略产生了无效概率")
    for action in output:
        action["probability"] /= denominator
    return output


class BehaviorPolicy:
    """Deterministic probability policy over legal actions from one observation."""

    def __init__(self, traits: BehaviorTraits, name: str = "custom", *, rank_backend: str = "native") -> None:
        if not isinstance(traits, BehaviorTraits):
            raise PokerError("traits 必须是 BehaviorTraits")
        if not isinstance(name, str) or not name:
            raise PokerError("name 必须是非空字符串")
        if rank_backend not in ("native", "python"):
            raise PokerError("rank_backend 必须是 native 或 python")
        self.traits = traits
        self.name = name
        self.rank_backend = rank_backend

    def __call__(self, observation: Mapping[str, Any]) -> list[dict[str, Any]]:
        if isinstance(observation, Mapping) and _PRIVATE_KEYS.intersection(observation):
            raise PokerError("行为策略不得接收整局或对手私牌")
        data = _validate(observation)
        return _score_behavior(self.traits, data, _candidate_actions(data), self.rank_backend)

    def on_actions(
        self, observation: Mapping[str, Any], actions: Any
    ) -> list[dict[str, Any]]:
        """Score an exact finite action set after checking it against the observation."""

        if isinstance(observation, Mapping) and _PRIVATE_KEYS.intersection(observation):
            raise PokerError("行为策略不得接收整局或对手私牌")
        data = _validate(observation)
        normalized = _actions(actions)
        legal = {item["kind"]: item for item in data["legal_actions"]}
        actor = data["actor"]
        paid = chips(data["players"][actor]["street_committed"])
        stack = chips(data["players"][actor]["stack"])
        candidates = []
        for kind, amount in normalized:
            details = legal.get(kind)
            if details is None:
                raise PokerError("finite action 不在 observation 合法动作中")
            if kind in ("fold", "check", "call"):
                target = chips(details["amount_to"])
                put_in = chips(details["put_in"])
                all_in = bool(details["all_in"])
            else:
                assert amount is not None
                minimum, maximum = chips(details["min_to"]), chips(details["max_to"])
                if not minimum <= amount <= maximum:
                    raise PokerError("finite 下注金额超出 observation 合法范围")
                target = amount
                put_in = target - paid
                all_in = put_in == stack
            candidates.append({"kind": kind, "amount_to": str(target),
                               "put_in": str(put_in), "all_in": all_in})
        return _score_behavior(self.traits, data, candidates, self.rank_backend)
