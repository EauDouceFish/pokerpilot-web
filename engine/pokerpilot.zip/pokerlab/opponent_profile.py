"""Public-action opportunity profiles with fixed time and hand decay."""

from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Any

from .contracts import PokerError

VERSION = "opportunity-profile-v1"
STREETS = ("preflop", "flop", "turn", "river")
HALF_LIFE_HANDS = 100
HALF_LIFE_DAYS = 30
PRIOR_STRENGTH = 20
_KINDS = frozenset(("fold", "check", "call", "bet", "raise"))
_PAIR_KEYS = frozenset(("opportunities", "successes"))
_COUNT_KEYS = frozenset(("version", "vpip", "streets"))
_STATE_KEYS = frozenset(
    ("version", "observed_hands", "as_of", "half_life_hands", "half_life_days", "vpip", "streets")
)


def _timestamp(value: Any, name: str) -> datetime:
    if not isinstance(value, str) or not value:
        raise PokerError(f"{name} 必须是带时区 ISO 时间字符串")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        offset = parsed.utcoffset()
        normalized = parsed.astimezone(timezone.utc)
    except (TypeError, ValueError, OverflowError) as exc:
        raise PokerError(f"{name} 必须是带时区 ISO 时间字符串") from exc
    if parsed.tzinfo is None or offset is None:
        raise PokerError(f"{name} 必须包含时区")
    return normalized


def _utc(value: datetime) -> str:
    return value.isoformat()


def _count_pair(value: Any, name: str) -> dict[str, int]:
    if not isinstance(value, dict) or set(value) != _PAIR_KEYS:
        raise PokerError(f"{name} 字段必须严格为 opportunities/successes")
    opportunities, successes = value["opportunities"], value["successes"]
    if (
        isinstance(opportunities, bool)
        or not isinstance(opportunities, int)
        or opportunities < 0
        or isinstance(successes, bool)
        or not isinstance(successes, int)
        or successes < 0
        or successes > opportunities
    ):
        raise PokerError(f"{name} 必须是 success 不超过 opportunity 的非负整数计数")
    return {"opportunities": opportunities, "successes": successes}


def _evidence_pair(value: Any, name: str) -> dict[str, float]:
    if not isinstance(value, dict) or set(value) != _PAIR_KEYS:
        raise PokerError(f"{name} 字段必须严格为 opportunities/successes")
    converted = []
    for key in ("opportunities", "successes"):
        item = value[key]
        if isinstance(item, bool) or not isinstance(item, (int, float)):
            raise PokerError(f"{name}.{key} 必须是有限非负实数")
        try:
            number = float(item)
        except (ValueError, OverflowError) as exc:
            raise PokerError(f"{name}.{key} 必须是有限非负实数") from exc
        if not math.isfinite(number) or number < 0.0:
            raise PokerError(f"{name}.{key} 必须是有限非负实数")
        converted.append(number)
    if converted[1] > converted[0]:
        raise PokerError(f"{name}.successes 不能超过 opportunities")
    return {"opportunities": converted[0], "successes": converted[1]}


def _streets(value: Any, pair_validator, name: str) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != set(STREETS):
        raise PokerError(f"{name} 必须严格包含四条街")
    output = {}
    for street in STREETS:
        entry = value[street]
        if not isinstance(entry, dict) or set(entry) != {"facing", "aggression"}:
            raise PokerError(f"{name}.{street} 必须严格包含 facing/aggression")
        output[street] = {
            "facing": pair_validator(entry["facing"], f"{name}.{street}.facing"),
            "aggression": pair_validator(entry["aggression"], f"{name}.{street}.aggression"),
        }
    return output


def _counts(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != _COUNT_KEYS or value.get("version") != VERSION:
        raise PokerError("counts schema 或 version 无效")
    vpip = _count_pair(value["vpip"], "counts.vpip")
    if vpip["opportunities"] > 1:
        raise PokerError("counts.vpip 每手最多一个机会")
    return {"version": VERSION, "vpip": vpip, "streets": _streets(value["streets"], _count_pair, "counts.streets")}


def _state(value: Any) -> tuple[dict[str, Any], datetime]:
    if not isinstance(value, dict) or set(value) != _STATE_KEYS or value.get("version") != VERSION:
        raise PokerError("state schema 或 version 无效")
    observed = value["observed_hands"]
    if isinstance(observed, bool) or not isinstance(observed, int) or observed < 0:
        raise PokerError("state.observed_hands 必须是非负整数")
    if type(value["half_life_hands"]) is not int or value["half_life_hands"] != HALF_LIFE_HANDS:
        raise PokerError("state.half_life_hands 必须严格为 100")
    if type(value["half_life_days"]) is not int or value["half_life_days"] != HALF_LIFE_DAYS:
        raise PokerError("state.half_life_days 必须严格为 30")
    as_of = _timestamp(value["as_of"], "state.as_of")
    return ({
        "version": VERSION,
        "observed_hands": observed,
        "as_of": _utc(as_of),
        "half_life_hands": HALF_LIFE_HANDS,
        "half_life_days": HALF_LIFE_DAYS,
        "vpip": _evidence_pair(value["vpip"], "state.vpip"),
        "streets": _streets(value["streets"], _evidence_pair, "state.streets"),
    }, as_of)


def _blank_pairs(pair: dict[str, int] | None = None) -> dict[str, Any]:
    source = pair or {"opportunities": 0, "successes": 0}
    return {
        street: {
            kind: {"opportunities": source["opportunities"], "successes": source["successes"]}
            for kind in ("facing", "aggression")
        }
        for street in STREETS
    }


def collect_opportunities(decisions: Any) -> dict[str, Any]:
    if not isinstance(decisions, list):
        raise PokerError("decisions 必须是列表")
    streets = _blank_pairs()
    preflop_seen = False
    vpip_success = False
    for index, decision in enumerate(decisions):
        if not isinstance(decision, dict) or set(decision) != {"street", "to_call", "legal_actions", "action"}:
            raise PokerError(f"decisions[{index}] 字段无效")
        street = decision["street"]
        if street not in STREETS:
            raise PokerError(f"decisions[{index}].street 无效")
        to_call = decision["to_call"]
        if isinstance(to_call, bool) or not isinstance(to_call, int) or to_call < 0:
            raise PokerError(f"decisions[{index}].to_call 必须是非负整数")
        legal = decision["legal_actions"]
        if (
            not isinstance(legal, list)
            or not legal
            or any(not isinstance(kind, str) or kind not in _KINDS for kind in legal)
            or len(set(legal)) != len(legal)
        ):
            raise PokerError(f"decisions[{index}].legal_actions 必须是非空唯一合法 kind 列表")
        action = decision["action"]
        if not isinstance(action, str) or action not in legal:
            raise PokerError(f"decisions[{index}].action 必须属于 legal_actions")

        if street == "preflop":
            preflop_seen = True
            vpip_success = vpip_success or action in ("call", "bet", "raise")
        if to_call > 0 and "fold" in legal:
            streets[street]["facing"]["opportunities"] += 1
            streets[street]["facing"]["successes"] += int(action == "fold")
        if "bet" in legal or "raise" in legal:
            streets[street]["aggression"]["opportunities"] += 1
            streets[street]["aggression"]["successes"] += int(action in ("bet", "raise"))
    return {
        "version": VERSION,
        "vpip": {"opportunities": int(preflop_seen), "successes": int(vpip_success)},
        "streets": streets,
    }


def _decay_pair(pair: dict[str, float], factor: float, name: str) -> dict[str, float]:
    values = []
    for key in ("opportunities", "successes"):
        result = pair[key] * factor
        if not math.isfinite(result):
            raise PokerError(f"{name}.{key} 衰减结果非有限")
        values.append(result)
    return {"opportunities": values[0], "successes": values[1]}


def _decay(state: dict[str, Any], factor: float, as_of: datetime) -> dict[str, Any]:
    return {
        "version": VERSION,
        "observed_hands": state["observed_hands"],
        "as_of": _utc(as_of),
        "half_life_hands": HALF_LIFE_HANDS,
        "half_life_days": HALF_LIFE_DAYS,
        "vpip": _decay_pair(state["vpip"], factor, "state.vpip"),
        "streets": {
            street: {
                kind: _decay_pair(state["streets"][street][kind], factor, f"state.{street}.{kind}")
                for kind in ("facing", "aggression")
            }
            for street in STREETS
        },
    }


def _time_factor(old: datetime, current: datetime) -> float:
    days = max(0.0, (current - old).total_seconds() / 86400.0)
    return 2.0 ** (-days / HALF_LIFE_DAYS)


def summarize_state(state: Any, timestamp: Any) -> dict[str, Any]:
    checked, old_time = _state(state)
    current = _timestamp(timestamp, "timestamp")
    later = max(old_time, current)
    return _decay(checked, _time_factor(old_time, current), later)


def update_state(previous: Any, counts: Any, timestamp: Any) -> dict[str, Any]:
    checked_counts = _counts(counts)
    current = _timestamp(timestamp, "timestamp")
    if previous is None:
        state = {
            "version": VERSION, "observed_hands": 0, "as_of": _utc(current),
            "half_life_hands": HALF_LIFE_HANDS, "half_life_days": HALF_LIFE_DAYS,
            "vpip": {"opportunities": 0.0, "successes": 0.0},
            "streets": _blank_pairs(),
        }
        old_time = current
    else:
        state, old_time = _state(previous)
    factor = _time_factor(old_time, current) * 2.0 ** (-1.0 / HALF_LIFE_HANDS)
    updated = _decay(state, factor, max(old_time, current))
    updated["observed_hands"] += 1

    def add(target: dict[str, float], source: dict[str, int], name: str) -> None:
        for key in ("opportunities", "successes"):
            try:
                value = target[key] + source[key]
            except OverflowError as exc:
                raise PokerError(f"{name}.{key} 更新结果非有限") from exc
            if not math.isfinite(value):
                raise PokerError(f"{name}.{key} 更新结果非有限")
            target[key] = value

    add(updated["vpip"], checked_counts["vpip"], "vpip")
    for street in STREETS:
        for kind in ("facing", "aggression"):
            add(updated["streets"][street][kind], checked_counts["streets"][street][kind], f"{street}.{kind}")
    return updated


def contextual_call_rate(state: Any, street: Any, prior_call: Any) -> tuple[float, float, dict[str, Any]]:
    checked, _ = _state(state)
    if not isinstance(street, str) or street not in STREETS:
        raise PokerError("street 无效")
    if isinstance(prior_call, bool) or not isinstance(prior_call, (int, float)):
        raise PokerError("prior_call 必须是 [0,1] 有限数")
    try:
        prior = float(prior_call)
    except (ValueError, OverflowError) as exc:
        raise PokerError("prior_call 必须是 [0,1] 有限数") from exc
    if not math.isfinite(prior) or not 0.0 <= prior <= 1.0:
        raise PokerError("prior_call 必须是 [0,1] 有限数")
    facing = checked["streets"][street]["facing"]
    opportunities, folds = facing["opportunities"], facing["successes"]
    if opportunities == 0.0:
        rate, weight = prior, 0.0
    else:
        rate = (PRIOR_STRENGTH * prior + opportunities - folds) / (PRIOR_STRENGTH + opportunities)
        weight = opportunities / (PRIOR_STRENGTH + opportunities)
        if not math.isfinite(rate) or not math.isfinite(weight):
            raise PokerError("contextual call rate 结果非有限")
    evidence = {
        "version": VERSION,
        "street": street,
        "opportunities": opportunities,
        "folds": folds,
        "prior_strength": PRIOR_STRENGTH,
        "profile_observed_hands": checked["observed_hands"],
    }
    return rate, weight, evidence
