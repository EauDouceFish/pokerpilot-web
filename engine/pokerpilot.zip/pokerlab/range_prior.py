"""Versioned frozen policies for unvisited rows of a range-search profile.

These are action priors, not terminal values or equilibrium certificates.
The search supplies its exact candidate menu; no action is added or reordered.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

from .action_menu import validate_action_menu
from .belief import COMBOS
from .contracts import PokerError


PRIOR_VERSION = "unvisited-frozen-policy-prior-v1"


@dataclass(frozen=True, slots=True)
class PolicyPriorDescriptor:
    num_players: int
    action_menu_version: str
    component_id: str
    feature_version: str
    training_identity: str
    inference_version: str
    rules_version: str = "chip-rules-v3"
    version: str = PRIOR_VERSION

    def __post_init__(self) -> None:
        if type(self.num_players) is not int or not 2 <= self.num_players <= 9:
            raise PokerError("prior num_players must be an integer in 2..9")
        try:
            validate_action_menu(self.action_menu_version)
        except ValueError as exc:
            raise PokerError(str(exc)) from exc
        for name in ("component_id", "feature_version", "training_identity", "inference_version"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip() or value != value.strip():
                raise PokerError(f"prior {name} must be a non-empty string")
        if self.rules_version != "chip-rules-v3" or self.version != PRIOR_VERSION:
            raise PokerError("unsupported policy prior version or rules")

    def protocol(self) -> dict[str, Any]:
        return {**asdict(self), "fallback": "missing-public-node-or-unvisited-combo",
                "visited_nonpositive_regrets": "uniform", "probability_floor": None}


class UnvisitedPolicyPrior(ABC):
    """Immutable provider contract shared by search, belief and evaluation.

Implementations must not change probabilities or identity after construction.
Only the neural implementation below is used for trained-model experiments.
"""

    @property
    @abstractmethod
    def descriptor(self) -> PolicyPriorDescriptor:
        raise NotImplementedError

    @abstractmethod
    def matrix(self, key: tuple, player: int, actions: tuple, indices: np.ndarray) -> np.ndarray:
        raise NotImplementedError


def validate_prior(prior: UnvisitedPolicyPrior | None, num_players: int,
                   action_menu_version: str | None = None) -> PolicyPriorDescriptor | None:
    if prior is None:
        return None
    if not isinstance(prior, UnvisitedPolicyPrior):
        raise PokerError("prior must provide an immutable PolicyPriorDescriptor")
    descriptor = prior.descriptor
    if type(descriptor) is not PolicyPriorDescriptor:
        raise PokerError("prior must provide an immutable PolicyPriorDescriptor")
    if descriptor.num_players != num_players:
        raise PokerError("prior player count does not match search/profile")
    if action_menu_version is not None and descriptor.action_menu_version != action_menu_version:
        raise PokerError("prior action menu does not match search game")
    return descriptor


def checked_prior_matrix(prior: UnvisitedPolicyPrior, descriptor: PolicyPriorDescriptor,
                         key: tuple, player: int, actions: tuple, indices: np.ndarray) -> np.ndarray:
    if prior.descriptor != descriptor:
        raise PokerError("prior identity changed after profile construction")
    raw = prior.matrix(key, player, actions, indices)
    if (not isinstance(raw, np.ndarray) or raw.dtype != np.float64
            or raw.shape != (len(indices), len(actions)) or not np.isfinite(raw).all()
            or np.any(raw < 0) or not np.allclose(raw.sum(axis=1), 1.0, rtol=0.0, atol=1e-12)):
        raise PokerError("prior must return finite normalized float64 probability rows")
    if prior.descriptor != descriptor:
        raise PokerError("prior identity changed during query")
    return raw


def profile_prior_descriptor(profile: Any, game: Any) -> PolicyPriorDescriptor | None:
    descriptor = getattr(profile, "prior_descriptor", None)
    if descriptor is not None and (
        type(descriptor) is not PolicyPriorDescriptor or descriptor.num_players != game.num_players
        or descriptor.action_menu_version != game.action_menu_version
    ):
        raise PokerError("profile prior identity does not match evaluation game")
    return descriptor


def prior_query_diagnostics(descriptor: PolicyPriorDescriptor | None,
                            queries: int, unvisited_queries: int) -> dict[str, Any]:
    if descriptor is None:
        return {"uniform_fallback_query_count": unvisited_queries}
    return {"uniform_fallback_query_count": 0, "prior_fallback_query_count": unvisited_queries,
            "searched_policy_query_count": queries - unvisited_queries,
            "unvisited_policy_prior": descriptor.protocol()}


class FrozenNeuralPolicyPrior(UnvisitedPolicyPrior):
    """Strictly loaded, privately owned snapshot with a single batched forward.

Snapshot schema predates player-count/menu metadata. The caller must bind the
audited training manifest explicitly; this adapter never infers these fields.
"""

    def __init__(self, payload: Any, *, num_players: int, action_menu_version: str,
                 training_identity: str, query_mode: str = "generic-batch-v1") -> None:
        from .advantage_snapshot import load_advantage_snapshot

        if not isinstance(query_mode, str) or query_mode not in ("generic-batch-v1", "public-range-v1"):
            raise PokerError("unsupported prior query_mode")
        provider = load_advantage_snapshot(payload)
        metadata = payload["metadata"]
        self.__descriptor = PolicyPriorDescriptor(
            num_players, action_menu_version, metadata["component_id"], metadata["feature_version"],
            training_identity, metadata["inference_backend"] + (
                "-batched-v1" if query_mode == "generic-batch-v1" else "-public-range-v1"))
        self.__provider = provider
        self.__query_mode = query_mode

    @property
    def descriptor(self) -> PolicyPriorDescriptor:
        return self.__descriptor

    def matrix(self, key: tuple, player: int, actions: tuple, indices: np.ndarray) -> np.ndarray:
        normalized_actions = _public_prior_request(key, player, actions, indices, self.descriptor)
        if not len(indices):
            return np.empty((0, len(normalized_actions)), dtype=np.float64)
        if self.__query_mode == "public-range-v1":
            return np.asarray(self.__provider.probabilities_public_range(
                player, key, normalized_actions, indices), dtype=np.float64)
        queries = tuple((player, (*key[:4], tuple(sorted(COMBOS[int(index)])), *key[5:]), normalized_actions)
                        for index in indices)
        return np.asarray(self.__provider.probabilities_batch(queries), dtype=np.float64)


def _public_prior_request(key, player, actions, indices, descriptor):
    from .continuation_policy import _actions, _key
    from .range_profile import public_key

    if (public_key(key) != key or type(player) is not int or key[1] != player
            or not 0 <= player < descriptor.num_players):
        raise PokerError("prior matrix query requires a matching public actor key")
    if (not isinstance(indices, np.ndarray) or indices.ndim != 1 or indices.dtype.kind not in "iu"
            or np.any(indices < 0) or np.any(indices >= len(COMBOS))):
        raise PokerError("prior indices must be an integer combo vector")
    normalized_actions = _actions(actions)
    if not isinstance(key[5], tuple) or any(not isinstance(card, str) for card in key[5]):
        raise PokerError("prior public board must be a card tuple")
    first = int(indices[0]) if len(indices) else next(
        (i for i, combo in enumerate(COMBOS) if not set(combo).intersection(key[5])), -1)
    if first < 0:
        raise PokerError("prior public board leaves no private combination")
    normalized_key = _key((*key[:4], tuple(sorted(COMBOS[first])), *key[5:]), expected_player=player)
    if len(normalized_key[6]) != descriptor.num_players:
        raise PokerError("prior query player count does not match descriptor")
    if not len(indices):
        from .policy_features import encode_policy
        encode_policy(player, normalized_key, normalized_actions, feature_version=descriptor.feature_version)
    return normalized_actions


class FrozenAveragePolicyPrior(UnvisitedPolicyPrior):
    """Bind the deployed average policy, not a last-iteration advantage snapshot.

Player count, menu and training provenance are explicit caller declarations;
they do not certify that the model has passed those coverage/strength gates.
"""

    def __init__(self, policy, *, num_players, action_menu_version, training_identity):
        from .policy_training import FrozenNeuralPolicy
        if not isinstance(policy, FrozenNeuralPolicy):
            raise PokerError("average prior requires FrozenNeuralPolicy")
        self.__provider = policy
        self.__descriptor = PolicyPriorDescriptor(num_players, action_menu_version,
            policy.policy_id, policy.metadata["feature_version"], training_identity, "average-policy-cpu-batched-v1")

    @property
    def descriptor(self):
        return self.__descriptor

    def matrix(self, key, player, actions, indices):
        actions = _public_prior_request(key, player, actions, indices, self.descriptor)
        output = np.empty((len(indices), len(actions)), dtype=np.float64)
        for start in range(0, len(indices), 128):
            queries = tuple((player, (*key[:4], tuple(sorted(COMBOS[int(i)])), *key[5:]), actions)
                            for i in indices[start:start+128])
            output[start:start+len(queries)] = self.__provider.probabilities_batch(queries)
        return output
