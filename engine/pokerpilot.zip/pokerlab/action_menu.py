"""Shared finite-action menu versions for search and observation policies."""
from __future__ import annotations


FULL_ACTION_MENU = "full-minimum-v1"
GROWTH_ACTION_MENU = "quarter-pot-extra-raise-v1"


def validate_action_menu(value) -> str:
    if type(value) is not str or value not in (FULL_ACTION_MENU, GROWTH_ACTION_MENU):
        raise ValueError("action_menu must be full-minimum-v1 or quarter-pot-extra-raise-v1")
    return value


def raise_targets(
    *,
    kind,
    paid,
    call,
    pot,
    low,
    high,
    fractions,
    action_menu=FULL_ACTION_MENU,
) -> tuple[int, ...]:
    """Return the ordered, clipped target amounts for one aggressive action."""

    menu = validate_action_menu(action_menu)
    if kind not in ("bet", "raise"):
        raise ValueError("kind must be bet or raise")
    proposed = [high, *(paid + call + round((pot + call) * fraction) for fraction in fractions)]
    if menu == FULL_ACTION_MENU or kind == "bet" or 4 * (low - paid - call) >= pot + call:
        proposed.append(low)
    return tuple(sorted({max(low, min(high, value)) for value in proposed}))
