"""Per-hand PokerKit adapter for the native standard-high rank kernel."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from pokerkit import Card, StandardHighHand

from pokerlab.contracts import PokerError
from pokerlab.native_kernel import evaluate_hand, load_native

if TYPE_CHECKING:
    from pokerlab.game import PokerHand


class NativeHighRank:
    """PokerKit-compatible ``from_game`` provider returning rank tuples.

    This adapter is intentionally limited to standard high-only hold'em.  The
    returned tuples have the same total ordering as ``StandardHighHand`` and
    are used only by PokerKit's internal showdown comparisons.
    """

    @classmethod
    def from_game(
        cls, hole_cards: Any, board_cards: Any = ()
    ) -> tuple[int, ...]:
        cards = tuple(
            card
            for card in (*Card.clean(hole_cards), *Card.clean(board_cards))
            if card
        )
        if not 5 <= len(cards) <= 7:
            raise ValueError("标准高牌比较需要 5 到 7 张已知牌")
        return evaluate_hand(tuple(repr(card) for card in cards))


def attach_native_ranker(hand: PokerHand) -> PokerHand:
    """Attach the native rank provider to one standard NLHE hand instance."""

    state = getattr(hand, "_state", None)
    hand_types = getattr(state, "hand_types", None)
    if hand_types == (NativeHighRank,):
        load_native()
        return hand
    if hand_types != (StandardHighHand,):
        raise PokerError("原生排名仅支持标准单一高牌制德州扑克")
    load_native()
    state.hand_types = (NativeHighRank,)
    return hand
