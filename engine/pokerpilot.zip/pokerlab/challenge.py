"""Transactional, private persistence for fixed-model heads-up challenges."""
from __future__ import annotations

from copy import deepcopy
import json
import secrets
import sqlite3
import uuid
from typing import Any, Callable

from .cash_session import settle_cash
from .challenge_metrics import summarize_records
from .contracts import PokerError
from .game import PokerHand
from .population_match import _mixed_action_seed
from .storage import ActionConflict, Store, now


_BIG_BLIND = 100
_SMALL_BLIND = 50
_INITIAL_STACK = 100 * _BIG_BLIND
_HAND_CONFIG_FIELDS = (
    "button", "small_blind", "big_blind", "ante_mode", "ante", "bba_order",
    "seed", "hole_cards", "board_cards", "rules_version",
)
_STATUSES = frozenset(("active", "won", "lost", "draw"))


def _json(value: Any, message: str) -> tuple[str, Any]:
    try:
        encoded = json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
            allow_nan=False,
        )
        return encoded, json.loads(encoded)
    except (TypeError, ValueError, OverflowError) as exc:
        raise PokerError(message) from exc


def _bb(value: int) -> float:
    return value / _BIG_BLIND


def _bb_array(values: list[int]) -> list[float]:
    return [_bb(value) for value in values]


class ChallengeStore:
    """Own challenge state without exposing it through the ordinary hand tables."""

    def __init__(self, store: Store):
        if not isinstance(store, Store):
            raise TypeError("store must be a Store")
        self.store = store
        self.connection = store.connection
        self.lock = store.lock
        with self.lock, self.connection:
            self.connection.executescript("""
                CREATE TABLE IF NOT EXISTS challenges (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    target INTEGER NOT NULL,
                    model TEXT NOT NULL,
                    status TEXT NOT NULL,
                    revision INTEGER NOT NULL,
                    completed_hands INTEGER NOT NULL,
                    net TEXT NOT NULL,
                    withdrawals TEXT NOT NULL,
                    deposits TEXT NOT NULL,
                    next_stacks TEXT NOT NULL,
                    current_number INTEGER NOT NULL,
                    current_spec TEXT NOT NULL,
                    current_events TEXT NOT NULL,
                    last_result TEXT
                );
                CREATE TABLE IF NOT EXISTS challenge_records (
                    challenge_id TEXT NOT NULL,
                    number INTEGER NOT NULL,
                    data TEXT NOT NULL,
                    PRIMARY KEY(challenge_id,number)
                );
                CREATE TABLE IF NOT EXISTS challenge_commands (
                    scope TEXT NOT NULL,
                    request_id TEXT NOT NULL,
                    operation TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    response TEXT NOT NULL,
                    PRIMARY KEY(scope,request_id)
                );
                CREATE TABLE IF NOT EXISTS challenge_policies (
                    challenge_id TEXT NOT NULL,
                    hand_number INTEGER NOT NULL,
                    event_index INTEGER NOT NULL,
                    policy BLOB NOT NULL,
                    PRIMARY KEY(challenge_id,hand_number,event_index)
                );
                CREATE TABLE IF NOT EXISTS challenge_opponents (
                    challenge_id TEXT PRIMARY KEY,
                    counters TEXT NOT NULL
                );
            """)

    @staticmethod
    def _request_id(request_id: str) -> str:
        if not isinstance(request_id, str) or not 1 <= len(request_id) <= 100:
            raise PokerError("请求标识需为 1 至 100 个字符")
        return request_id

    @staticmethod
    def _revision(revision: int) -> int:
        if type(revision) is not int or revision < 0:
            raise PokerError("挑战版本必须是非负整数")
        return revision

    @staticmethod
    def _name(name: str) -> str:
        if not isinstance(name, str):
            raise PokerError("挑战名称需为 1 至 40 个字符")
        value = name.strip()
        if not 1 <= len(value) <= 40:
            raise PokerError("挑战名称需为 1 至 40 个字符")
        return value

    @staticmethod
    def _target(mode: str, target: int) -> tuple[str, int]:
        if mode not in ("profit", "hands"):
            raise PokerError("挑战模式必须是 profit 或 hands")
        if type(target) is not int or target <= 0:
            raise PokerError("挑战目标必须是正整数")
        limit = 1000 if mode == "profit" else 100_000
        if target > limit:
            raise PokerError("挑战目标超过允许上限")
        return mode, target

    @staticmethod
    def _model(model: dict) -> tuple[str, dict]:
        if type(model) is not dict:
            raise PokerError("模型身份必须是 JSON 对象")
        return _json(model, "模型身份必须是有限 JSON")

    @staticmethod
    def _action(action: dict | None) -> dict:
        if type(action) is not dict or "kind" not in action or not isinstance(action["kind"], str):
            raise PokerError("行动必须包含 kind")
        if not set(action) <= {"kind", "amount_to"}:
            raise PokerError("行动只能包含 kind 和 amount_to")
        canonical = {"kind": action["kind"]}
        if "amount_to" in action:
            canonical["amount_to"] = action["amount_to"]
        return _json(canonical, "行动必须是有限 JSON")[1]

    @staticmethod
    def _new_hand(stacks: list[int], button: int) -> tuple[PokerHand, dict]:
        deal_seed = secrets.randbits(63)
        action_seed = secrets.randbits(63)
        hand = PokerHand(
            stacks, button=button, small_blind=_SMALL_BLIND, big_blind=_BIG_BLIND,
            ante_mode="none", ante=0, bba_order="blind_first", seed=deal_seed,
            rules_version="chip-rules-v3",
        )
        spec = {"stacks": list(stacks), **hand.config, "action_seed": action_seed}
        return hand, spec

    @staticmethod
    def _reconstruct(spec: dict, events: list) -> PokerHand:
        if type(spec) is not dict or type(events) is not list:
            raise PokerError("挑战私有状态损坏")
        try:
            stacks = spec["stacks"]
            arguments = {field: spec[field] for field in _HAND_CONFIG_FIELDS}
            action_seed = spec["action_seed"]
        except KeyError as exc:
            raise PokerError("挑战私有状态损坏") from exc
        if type(action_seed) is not int:
            raise PokerError("挑战私有状态损坏")
        hand = PokerHand(stacks, **arguments)
        for event in events:
            if type(event) is not dict:
                raise PokerError("挑战行动记录损坏")
            hand.act(event.get("seat"), event.get("kind"), event.get("amount_to"))
        if hand.history != events:
            raise PokerError("挑战行动记录无法精确重放")
        return hand

    @staticmethod
    def _state(row: sqlite3.Row | dict) -> dict:
        raw = dict(row)
        return {
            **raw,
            "model": json.loads(raw["model"]),
            "net": json.loads(raw["net"]),
            "withdrawals": json.loads(raw["withdrawals"]),
            "deposits": json.loads(raw["deposits"]),
            "next_stacks": json.loads(raw["next_stacks"]),
            "current_spec": json.loads(raw["current_spec"]),
            "current_events": json.loads(raw["current_events"]),
            "last_result": (None if raw["last_result"] is None
                            else json.loads(raw["last_result"])),
        }

    @staticmethod
    def _summary(state: dict) -> dict:
        return {
            "id": state["id"], "name": state["name"],
            "created_at": state["created_at"], "mode": state["mode"],
            "target": state["target"], "status": state["status"],
            "revision": state["revision"],
            "completed_hands": state["completed_hands"],
            "net_bb": _bb(state["net"][0]), "model": deepcopy(state["model"]),
        }

    @classmethod
    def _envelope(cls, state: dict, hand: PokerHand) -> dict:
        result = cls._summary(state)
        result.update({
            "hand_number": state["current_number"],
            "observation": hand.view(0),
            "cash": {
                "withdrawn_bb": _bb_array(state["withdrawals"]),
                "deposited_bb": _bb_array(state["deposits"]),
                "next_stacks_bb": _bb_array(state["next_stacks"]),
            },
            "last_result": deepcopy(state["last_result"]),
        })
        return result

    def _load(self, key: str) -> dict:
        row = self.connection.execute("SELECT * FROM challenges WHERE id=?", (key,)).fetchone()
        if row is None:
            raise KeyError("挑战不存在")
        state = self._state(row)
        if state["status"] not in _STATUSES:
            raise PokerError("挑战状态损坏")
        return state

    def _prior_command(self, scope: str, request_id: str, operation: str,
                       payload_json: str) -> dict | None:
        row = self.connection.execute(
            "SELECT operation,payload,response FROM challenge_commands "
            "WHERE scope=? AND request_id=?", (scope, request_id),
        ).fetchone()
        if row is None:
            return None
        if row["operation"] != operation or row["payload"] != payload_json:
            raise ActionConflict("请求标识已用于不同操作或参数")
        return json.loads(row["response"])

    def _record_command(self, scope: str, request_id: str, operation: str,
                        payload_json: str, response: dict) -> None:
        response_json = _json(response, "挑战响应必须是有限 JSON")[0]
        self.connection.execute(
            "INSERT INTO challenge_commands(scope,request_id,operation,payload,response) "
            "VALUES(?,?,?,?,?)", (scope, request_id, operation, payload_json, response_json),
        )

    def _before_command_commit(self) -> None:
        """Private fault-injection seam; production behavior is intentionally empty."""

    @staticmethod
    def _public_record(data: dict, *, include_detail: bool) -> dict:
        result = {
            "number": data["number"], "net_bb": _bb(data["net"][0]),
            "cumulative_bb": _bb(data["cumulative"][0]),
            "starting_stacks_bb": _bb_array(data["starting_stacks"]),
            "final_stacks_bb": _bb_array(data["final_stacks"]),
            "withdrawals_bb": _bb_array(data["withdrawals"]),
            "deposits_bb": _bb_array(data["deposits"]),
        }
        if include_detail:
            result["observation"] = deepcopy(data["observation"])
            result["events"] = deepcopy(data["events"])
            result["frames"] = deepcopy(data.get("frames", []))
        return result

    @staticmethod
    def _public_frames(state: dict) -> list[dict]:
        spec = state["current_spec"]
        events = state["current_events"]
        try:
            stacks = spec["stacks"]
            arguments = {field: spec[field] for field in _HAND_CONFIG_FIELDS}
        except KeyError as exc:
            raise PokerError("挑战私有状态损坏") from exc
        replay = PokerHand(stacks, **arguments)
        frames = [{"index": 0, "event": None, "observation": replay.view(0)}]
        for index, event in enumerate(events, 1):
            replay.act(event.get("seat"), event.get("kind"), event.get("amount_to"))
            if replay.history[-1] != event:
                raise PokerError("挑战行动记录无法精确重放")
            frames.append({
                "index": index,
                "event": deepcopy(event),
                "observation": replay.view(0),
            })
        return frames

    @classmethod
    def _settle_terminal(cls, state: dict, hand: PokerHand) -> dict:
        if not hand.is_terminal or hand.result is None:
            raise PokerError("只能结算已完成手牌")
        if state["current_number"] != state["completed_hands"] + 1:
            raise PokerError("挑战手牌编号损坏")
        starting = [int(value) for value in state["current_spec"]["stacks"]]
        final = [int(value) for value in hand.result["final_stacks"]]
        net = [end - start for end, start in zip(final, starting, strict=True)]
        if len(net) != 2 or sum(net) != 0:
            raise PokerError("单手筹码不守恒")
        cash = settle_cash(final, big_blind=_BIG_BLIND, top_up=(False, True))
        cumulative = [state["net"][seat] + net[seat] for seat in range(2)]
        withdrawals = [state["withdrawals"][seat] + cash["withdrawals"][seat]
                       for seat in range(2)]
        deposits = [state["deposits"][seat] + cash["deposits"][seat]
                    for seat in range(2)]
        for seat in range(2):
            if (cash["next_stacks"][seat] + withdrawals[seat] - deposits[seat]
                    - _INITIAL_STACK != cumulative[seat]):
                raise PokerError("挑战现金账本不守恒")
        completed = state["completed_hands"] + 1
        status = "active"
        if state["mode"] == "profit" or abs(cumulative[0]) >= 1000 * _BIG_BLIND:
            limit_bb = min(state["target"], 1000) if state["mode"] == "profit" else 1000
            threshold = limit_bb * _BIG_BLIND
            if cumulative[0] >= threshold:
                status = "won"
            elif cumulative[0] <= -threshold:
                status = "lost"
        elif completed >= state["target"]:
            status = "won" if cumulative[0] > 0 else "lost" if cumulative[0] < 0 else "draw"
        record = {
            "number": state["current_number"], "net": net, "cumulative": cumulative,
            "starting_stacks": starting, "final_stacks": final,
            "withdrawals": cash["withdrawals"], "deposits": cash["deposits"],
            "observation": hand.view(0), "events": hand.history,
            "frames": cls._public_frames(state),
        }
        public = cls._public_record(record, include_detail=False)
        last_result = {
            "hand": record["number"], "net_bb": public["net_bb"],
            "cumulative_bb": public["cumulative_bb"],
            "withdrawals_bb": public["withdrawals_bb"],
            "deposits_bb": public["deposits_bb"],
        }
        state.update(status=status, completed_hands=completed, net=cumulative,
                     withdrawals=withdrawals, deposits=deposits,
                     next_stacks=cash["next_stacks"], last_result=last_result)
        return record

    def _write_state(self, state: dict, expected_revision: int) -> None:
        values = [
            state["status"], state["revision"], state["completed_hands"],
            _json(state["net"], "挑战账本损坏")[0],
            _json(state["withdrawals"], "挑战账本损坏")[0],
            _json(state["deposits"], "挑战账本损坏")[0],
            _json(state["next_stacks"], "挑战账本损坏")[0],
            state["current_number"],
            _json(state["current_spec"], "挑战私有状态损坏")[0],
            _json(state["current_events"], "挑战行动记录损坏")[0],
            None if state["last_result"] is None else
            _json(state["last_result"], "挑战结果损坏")[0],
            state["id"], expected_revision,
        ]
        cursor = self.connection.execute(
            "UPDATE challenges SET status=?,revision=?,completed_hands=?,net=?,withdrawals=?,"
            "deposits=?,next_stacks=?,current_number=?,current_spec=?,current_events=?,"
            "last_result=? WHERE id=? AND revision=?", values,
        )
        if cursor.rowcount != 1:
            raise ActionConflict("挑战版本已变化")

    def create(self, *, name: str, mode: str, target: int, model: dict,
               request_id: str) -> dict:
        name = self._name(name)
        mode, target = self._target(mode, target)
        model_json, canonical_model = self._model(model)
        request_id = self._request_id(request_id)
        payload_json = _json({"name": name, "mode": mode, "target": target,
                              "model": canonical_model}, "挑战参数必须是有限 JSON")[0]
        with self.lock:
            self.connection.execute("BEGIN IMMEDIATE")
            try:
                prior = self._prior_command("create", request_id, "create", payload_json)
                if prior is not None:
                    self.connection.commit()
                    return prior
                hand, spec = self._new_hand([_INITIAL_STACK, _INITIAL_STACK], secrets.randbelow(2))
                key, created = uuid.uuid4().hex, now()
                state = {
                    "id": key, "name": name, "created_at": created, "mode": mode,
                    "target": target, "model": canonical_model, "status": "active",
                    "revision": 0, "completed_hands": 0, "net": [0, 0],
                    "withdrawals": [0, 0], "deposits": [0, 0],
                    "next_stacks": [_INITIAL_STACK, _INITIAL_STACK], "current_number": 1,
                    "current_spec": spec, "current_events": hand.history, "last_result": None,
                }
                self.connection.execute(
                    "INSERT INTO challenges VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (key, name, created, mode, target, model_json, "active", 0, 0,
                     "[0,0]", "[0,0]", "[0,0]", "[10000,10000]", 1,
                     _json(spec, "挑战私有状态损坏")[0], "[]", None),
                )
                response = self._envelope(state, hand)
                self._record_command("create", request_id, "create", payload_json, response)
                self._before_command_commit()
                self.connection.commit()
                return response
            except BaseException:
                self.connection.rollback()
                raise

    def list(self) -> list[dict]:
        with self.lock:
            rows = self.connection.execute(
                "SELECT * FROM challenges ORDER BY created_at DESC,id DESC"
            ).fetchall()
            return [self._summary(self._state(row)) for row in rows]

    def get(self, key: str) -> dict:
        with self.lock:
            state = self._load(key)
            hand = self._reconstruct(state["current_spec"], state["current_events"])
            return self._envelope(state, hand)

    def command(self, key: str, *, kind: str, revision: int, request_id: str,
                action: dict | None = None,
                policy: Callable[[dict, int, dict], dict] | None = None,
                contextual_policy=None) -> dict:
        if kind not in ("act", "ai", "next", "buyin"):
            raise PokerError("挑战命令必须是 act、ai、next 或 buyin")
        if contextual_policy is not None and (kind != 'ai' or not callable(contextual_policy)):
            raise PokerError('上下文策略只能用于 AI 行动')
        revision = self._revision(revision)
        request_id = self._request_id(request_id)
        if kind == "act":
            canonical_action = self._action(action)
            if policy is not None:
                raise PokerError("玩家行动不能提供 AI policy")
        else:
            if action is not None:
                raise PokerError("该挑战命令不能提供玩家行动")
            canonical_action = None
            if kind in ("next", "buyin") and policy is not None:
                raise PokerError("下一手或补码命令不能提供 AI policy")
        payload_json = _json({"kind": kind, "revision": revision,
                              "action": canonical_action}, "挑战命令必须是有限 JSON")[0]
        scope = f"challenge:{key}"
        with self.lock:
            self.connection.execute("BEGIN IMMEDIATE")
            try:
                prior = self._prior_command(scope, request_id, kind, payload_json)
                if prior is not None:
                    self.connection.commit()
                    return prior
                state = self._load(key)
                if state["revision"] != revision:
                    raise ActionConflict("挑战版本已变化")
                if state["status"] != "active":
                    raise PokerError("挑战已经结束")
                hand = self._reconstruct(state["current_spec"], state["current_events"])
                record = None
                captured = []
                if kind == "buyin":
                    if not hand.is_terminal or state["completed_hands"] != state["current_number"]:
                        raise PokerError("请在本手结束后补码，不能改变进行中的筹码")
                    amount = _INITIAL_STACK - state["next_stacks"][0]
                    if amount <= 0:
                        raise PokerError("后手已达到 100BB，无需补码")
                    state["next_stacks"][0] += amount
                    state["deposits"][0] += amount
                elif kind == "next":
                    if not hand.is_terminal or state["completed_hands"] != state["current_number"]:
                        raise PokerError("当前手牌尚未结算，不能开始下一手")
                    hand, spec = self._new_hand(
                        list(state["next_stacks"]),
                        (state["current_spec"]["button"] + 1) % 2,
                    )
                    state["current_number"] = state["completed_hands"] + 1
                    state["current_spec"], state["current_events"] = spec, hand.history
                    if hand.is_terminal:
                        record = self._settle_terminal(state, hand)
                else:
                    if hand.is_terminal:
                        raise PokerError("当前手牌已经结束")
                    if kind == "act":
                        if hand.actor != 0:
                            raise PokerError("当前不是玩家行动")
                        selected = canonical_action
                    else:
                        if hand.actor != 1:
                            raise PokerError("当前不是 AI 行动")
                        if not callable(policy) and contextual_policy is None:
                            raise PokerError("AI 命令必须提供 policy")
                        observation = deepcopy(hand.view(1))
                        decision_seed = _mixed_action_seed(
                            state["current_spec"]["action_seed"], hand.version, 1
                        )
                        if contextual_policy is None:
                            selected = self._action(policy(
                                observation, decision_seed, deepcopy(state["model"])))
                        else:
                            from .policy_history import PolicyHistory, unpack_decision
                            previous = {}
                            for row in self.connection.execute(
                                'SELECT event_index,policy FROM challenge_policies '
                                'WHERE challenge_id=? AND hand_number=? AND event_index<? ORDER BY event_index',
                                (key, state['current_number'], len(hand.history))):
                                saved = unpack_decision(row['policy'])
                                Store._check_policy_event(saved, hand.history, row['event_index'])
                                previous[saved.key] = saved
                            selected = self._action(contextual_policy(
                                observation, decision_seed, deepcopy(state['model']),
                                recorded_policies=PolicyHistory(f'{key}:{state["current_number"]}', previous),
                                capture_policy=captured.append,
                                opponent_counters=self._opponent_counters(state)))
                            if len(captured) > 1:
                                raise PokerError('一次行动只能保存一份完整策略')
                    human_view = hand.view(0) if hand.actor == 0 else None
                    counters = self._opponent_counters(state) if human_view is not None else None
                    hand.act(hand.actor, selected["kind"], selected.get("amount_to"))
                    if counters is not None:
                        from .poker_frequencies import add_public_decision
                        add_public_decision(counters, human_view, hand.history[-1])
                        self.connection.execute('INSERT OR REPLACE INTO challenge_opponents VALUES(?,?)',
                            (key, _json(counters, '对手频率记录损坏')[0]))
                    if captured:
                        from .policy_history import pack_decision
                        index = len(hand.history)-1
                        Store._check_policy_event(captured[0], hand.history, index)
                        self.connection.execute('INSERT INTO challenge_policies VALUES(?,?,?,?)',
                            (key, state['current_number'], index, pack_decision(captured[0])))
                    state["current_events"] = hand.history
                    if hand.is_terminal:
                        record = self._settle_terminal(state, hand)
                expected_revision = state["revision"]
                state["revision"] = expected_revision + 1
                if record is not None:
                    data_json = _json(record, "挑战手牌记录损坏")[0]
                    self.connection.execute(
                        "INSERT INTO challenge_records(challenge_id,number,data) VALUES(?,?,?)",
                        (key, record["number"], data_json),
                    )
                self._write_state(state, expected_revision)
                response = self._envelope(state, hand)
                self._record_command(scope, request_id, kind, payload_json, response)
                self._before_command_commit()
                self.connection.commit()
                return response
            except BaseException:
                self.connection.rollback()
                raise

    def _opponent_counters(self, state):
        """Public decisions strictly before the pending action, scoped to this save."""
        from .poker_frequencies import add_public_decision
        row = self.connection.execute('SELECT counters FROM challenge_opponents WHERE challenge_id=?',
                                      (state['id'],)).fetchone()
        if row is not None:
            return json.loads(row['counters'])
        # Older saves have no incremental row. Rebuild only public frequency
        # events once on their next human action; never infer unshown bluffs.
        counters = {}
        def add_frames(frames):
            for before, after in zip(frames, frames[1:]):
                if after['event']['seat'] == 0:
                    add_public_decision(counters, before['observation'], after['event'])
        for row in self.connection.execute('SELECT data FROM challenge_records WHERE challenge_id=? ORDER BY number',
                                           (state['id'],)):
            add_frames(json.loads(row['data']).get('frames', []))
        if state['current_number'] > state['completed_hands']:
            add_frames(self._public_frames(state))
        return counters

    def recorded_policies(self, key: str, number: int):
        """Private completed-hand records; never serialize full matrices to the UI."""
        from .policy_history import unpack_decision
        with self.lock:
            hand = self.record(key, number)
            records = {}
            for row in self.connection.execute(
                'SELECT event_index,policy FROM challenge_policies WHERE challenge_id=? AND hand_number=? '
                'ORDER BY event_index', (key, number)):
                record = unpack_decision(row['policy'])
                Store._check_policy_event(record, hand['events'], row['event_index'])
                records[row['event_index']] = record
            return records

    def history(self, key: str, *, offset: int = 0, limit: int = 50) -> dict:
        if type(offset) is not int or offset < 0 or type(limit) is not int or limit < 1:
            raise PokerError("历史分页参数无效")
        with self.lock:
            self._load(key)
            total = self.connection.execute(
                "SELECT COUNT(*) FROM challenge_records WHERE challenge_id=?", (key,)
            ).fetchone()[0]
            rows = self.connection.execute(
                "SELECT data FROM challenge_records WHERE challenge_id=? "
                "ORDER BY number LIMIT ? OFFSET ?", (key, limit, offset),
            ).fetchall()
            return {"items": [self._public_record(json.loads(row["data"]), include_detail=False)
                              for row in rows], "total": total}

    def record(self, key: str, number: int) -> dict:
        if type(number) is not int or number < 1:
            raise PokerError("手牌编号必须是正整数")
        with self.lock:
            self._load(key)
            row = self.connection.execute(
                "SELECT data FROM challenge_records WHERE challenge_id=? AND number=?",
                (key, number),
            ).fetchone()
            if row is None:
                raise KeyError("挑战手牌记录不存在")
            return self._public_record(json.loads(row["data"]), include_detail=True)

    def curve(self, key: str) -> dict:
        with self.lock:
            self._load(key)
            rows = self.connection.execute(
                "SELECT number,data FROM challenge_records WHERE challenge_id=? ORDER BY number",
                (key,),
            ).fetchall()
            points = [{"hand": 0, "profit_bb": 0.0}]
            points.extend({"hand": row["number"],
                           "profit_bb": _bb(json.loads(row["data"])["cumulative"][0])}
                          for row in rows)
            return {"points": points}

    def metrics(self, key: str) -> dict:
        with self.lock:
            self._load(key)
            rows = self.connection.execute(
                "SELECT data FROM challenge_records WHERE challenge_id=? ORDER BY number",
                (key,),
            ).fetchall()
            records = [
                self._public_record(json.loads(row["data"]), include_detail=True)
                for row in rows
            ]
        return summarize_records(records)
