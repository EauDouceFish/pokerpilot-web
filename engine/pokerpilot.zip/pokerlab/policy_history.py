"""Immutable per-decision policy records and lossless hand-history snapshots."""
from __future__ import annotations

from dataclasses import dataclass
from collections.abc import Mapping
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import tempfile
from types import MappingProxyType
import zipfile
import zlib

import numpy as np

from .belief import COMBOS
from .continuation_policy import _actions, _key
from .contracts import PokerError
from .range_profile import public_key
from .policy_betting_state import public_betting_state

_INDEX = {frozenset(combo): i for i, combo in enumerate(COMBOS)}


@dataclass(frozen=True, slots=True)
class FrozenOwnDecision:
    key: tuple
    actions: tuple
    probabilities: np.ndarray
    source_id: str
    assumed: bool = False

    def __post_init__(self):
        if public_key(self.key) != self.key:
            raise PokerError("frozen own policy requires a public key")
        actions = _actions(self.actions)
        valid = np.array([not set(c).intersection(self.key[5]) for c in COMBOS])
        if not valid.any():
            raise PokerError("frozen decision has no compatible private combination")
        first = int(np.flatnonzero(valid)[0])
        key = _key((*self.key[:4], tuple(sorted(COMBOS[first])), *self.key[5:]), expected_player=self.key[1])
        _check_menu(key, actions)
        matrix = self.probabilities
        if (not isinstance(matrix, np.ndarray) or matrix.dtype != np.float64
                or matrix.shape != (len(COMBOS), len(actions)) or not np.isfinite(matrix).all()
                or np.any(matrix < 0) or np.any(matrix[~valid] != 0)
                or not np.allclose(matrix[valid].sum(axis=1), 1, rtol=0, atol=1e-12)):
            raise PokerError("frozen policy matrix must normalize compatible rows and zero blocked rows")
        if not isinstance(self.source_id, str) or not self.source_id.strip():
            raise PokerError("frozen policy requires its actual source identity")
        if type(self.assumed) is not bool:
            raise PokerError("assumed must explicitly be a bool")
        frozen = np.frombuffer(matrix.tobytes(order="C"), dtype=np.float64).reshape(matrix.shape)
        object.__setattr__(self, "key", public_key(key))
        object.__setattr__(self, "actions", actions)
        object.__setattr__(self, "probabilities", frozen)

    def for_cards(self, cards):
        try:
            index = _INDEX[frozenset(cards)]
        except (KeyError, TypeError) as exc:
            raise PokerError("invalid own private combination") from exc
        row = self.probabilities[index]
        if not math.isclose(float(row.sum()), 1., abs_tol=1e-12):
            raise PokerError("own private combination conflicts with the frozen public board")
        return tuple(map(float, row))

    @classmethod
    def capture(cls, key, actions, source, *, source_id):
        """Copy a complete combo policy at action time from an immutable source."""
        from .range_prior import UnvisitedPolicyPrior, checked_prior_matrix, validate_prior
        from .range_profile import DenseCurrentPolicyProfile
        if public_key(key) != key:
            raise PokerError("capture requires a public information key")
        actions = _actions(actions)
        indices = np.array([i for i, c in enumerate(COMBOS) if not set(c).intersection(key[5])], dtype=np.int64)
        if isinstance(source, UnvisitedPolicyPrior):
            descriptor = validate_prior(source, len(key[6]))
            rows = checked_prior_matrix(source, descriptor, key, key[1], actions, indices)
        elif isinstance(source, DenseCurrentPolicyProfile) and source.num_players == len(key[6]):
            rows = source.matrix(key, key[1], actions, indices)
        else:
            raise PokerError("capture requires an immutable range profile or policy prior")
        matrix = np.zeros((len(COMBOS), len(actions)), dtype=np.float64)
        matrix[indices] = rows
        return cls(key, actions, matrix, source_id)


def _check_menu(key, actions):
    betting = public_betting_state(key[1], key[3], key[6], key[8], int(dict(key[7])["big_blind"]))
    passive = {(kind, None) for kind, _ in betting.legal_actions()}
    if {a for a in actions if a[0] not in ("bet", "raise")} != passive:
        raise PokerError("historical policy has incompatible passive actions")
    bounds = betting.raise_bounds()
    aggressive = [a for a in actions if a[0] in ("bet", "raise")]
    if bool(aggressive) != (bounds is not None):
        raise PokerError("historical policy has incompatible raising rights")
    kind = "raise" if key[3] == "preflop" or max(betting.bets) else "bet"
    for action, amount in aggressive:
        if action != kind or not bounds[0] <= amount <= bounds[1]:
            raise PokerError("historical policy contains an illegal actual amount")


def checked_history(records):
    """Copy and validate a mapping without importing any search-game adapter."""
    if records is None:
        return {}
    if isinstance(records, PolicyHistory):
        return dict(records.records)
    if not isinstance(records, Mapping):
        raise PokerError("recorded policies must be a public-key mapping or PolicyHistory")
    copied = dict(records)
    for key, record in copied.items():
        if not isinstance(record, FrozenOwnDecision) or record.key != key:
            raise PokerError("recorded policy key or record type mismatch")
    return copied


class PolicyHistory:
    """Immutable records for one hand; public histories must form one prefix chain."""

    def __init__(self, hand_id, records):
        if not isinstance(hand_id, str) or not hand_id.strip() or len(hand_id) > 256:
            raise PokerError("hand_id must be a nonempty string of at most 256 characters")
        records = checked_history(records)
        ordered = sorted(records.values(), key=lambda r: len(r.key[8]))
        if len({len(r.key[8]) for r in ordered}) != len(ordered):
            raise PokerError("one hand cannot contain two policies for the same decision number")
        if ordered:
            last = ordered[-1].key
            identity = lambda k: (k[2], tuple(p[2] for p in k[6]), k[7])
            for record in ordered:
                key = record.key
                if (identity(key) != identity(last) or last[8][:len(key[8])] != key[8]
                        or last[5][:len(key[5])] != key[5]):
                    raise PokerError("policy records do not belong to one public hand history")
        self.__hand_id = hand_id
        self.__records = MappingProxyType({r.key: r for r in ordered})

    @property
    def hand_id(self):
        return self.__hand_id

    @property
    def records(self):
        return self.__records

    def before(self, action_count):
        """Exclude policies not yet executed at the requested replay position."""
        if type(action_count) is not int or action_count < 0:
            raise PokerError("action_count must be a nonnegative integer")
        return PolicyHistory(self.hand_id, {k: r for k, r in self.records.items() if len(k[8]) < action_count})


def save_policy_history(history, path):
    """Install a new lossless ZIP snapshot atomically; never replace an archive."""
    if not isinstance(history, PolicyHistory):
        raise PokerError("save requires PolicyHistory")
    entries, arrays = [], {}
    for record in history.records.values():
        buffer = io.BytesIO()
        np.save(buffer, record.probabilities, allow_pickle=False)
        blob = buffer.getvalue()
        identity = hashlib.blake2b(blob, digest_size=16).hexdigest()
        arrays[identity] = blob
        entries.append({"key": record.key, "actions": record.actions, "source_id": record.source_id,
                        "assumed": record.assumed, "array": identity})
    manifest = {"version": "hand-policy-history-v1", "hand_id": history.hand_id, "records": entries}
    encoded = json.dumps(manifest, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=destination.parent, prefix=".policy-history-", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                archive.writestr("manifest.json", encoded)
                for identity, blob in arrays.items():
                    archive.writestr(f"arrays/{identity}.npy", blob)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, destination)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return {"path": str(destination), "records": len(entries), "unique_matrices": len(arrays),
            "bytes": destination.stat().st_size, "hand_id": history.hand_id}


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise PokerError("duplicate JSON field in policy history")
        result[key] = value
    return result


def _tupled(value):
    return tuple(_tupled(v) for v in value) if isinstance(value, list) else value


def pack_decision(record):
    """Private database payload; never include it in a browser action response."""
    if not isinstance(record, FrozenOwnDecision) or record.assumed:
        raise PokerError("only actual executed policies may be persisted with an action")
    payload = {"version": "executed-decision-v1", "key": record.key,
               "actions": record.actions, "source_id": record.source_id,
               "probabilities": record.probabilities.tolist()}
    raw = json.dumps(payload, ensure_ascii=False, allow_nan=False,
                     separators=(",", ":")).encode("utf-8")
    if len(raw) > 16*1024*1024:
        raise PokerError("executed policy exceeds per-decision storage limit")
    return zlib.compress(raw)


def unpack_decision(blob):
    try:
        decoder = zlib.decompressobj()
        raw = decoder.decompress(blob, 16*1024*1024+1)
        if len(raw) > 16*1024*1024 or not decoder.eof or decoder.unused_data:
            raise PokerError("invalid or oversized executed policy payload")
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object)
        if set(value) != {"version", "key", "actions", "source_id", "probabilities"} or value["version"] != "executed-decision-v1":
            raise PokerError("invalid executed policy schema")
        return FrozenOwnDecision(_tupled(value["key"]), _tupled(value["actions"]),
                                 np.asarray(value["probabilities"], dtype=np.float64), value["source_id"])
    except (ValueError, TypeError, KeyError, zlib.error) as exc:
        raise PokerError("invalid executed policy payload") from exc


def load_policy_history(path, *, expected_hand_id, max_uncompressed_bytes=256*1024*1024):
    """No pickle/extraction; validate archive identity and every probability row."""
    if type(max_uncompressed_bytes) is not int or max_uncompressed_bytes < 1:
        raise PokerError("history byte limit must be a positive integer")
    try:
        with zipfile.ZipFile(path) as archive:
            infos = archive.infolist()
            if (len({i.filename for i in infos}) != len(infos)
                    or sum(i.file_size for i in infos) > max_uncompressed_bytes):
                raise PokerError("duplicate archive entries or policy history exceeds byte limit")
            manifest = json.loads(archive.read("manifest.json").decode("utf-8"), object_pairs_hook=_unique_object)
            if (not isinstance(manifest, dict) or set(manifest) != {"version", "hand_id", "records"}
                    or manifest["version"] != "hand-policy-history-v1" or manifest["hand_id"] != expected_hand_id
                    or not isinstance(manifest["records"], list)):
                raise PokerError("policy history schema or hand identity mismatch")
            expected, arrays, records = {"manifest.json"}, {}, {}
            for entry in manifest["records"]:
                if (not isinstance(entry, dict) or set(entry) != {"key", "actions", "source_id", "assumed", "array"}
                        or not isinstance(entry["array"], str) or re.fullmatch(r"[0-9a-f]{32}", entry["array"]) is None):
                    raise PokerError("invalid policy history entry")
                identity = entry["array"]
                name = f"arrays/{identity}.npy"
                expected.add(name)
                if identity not in arrays:
                    blob = archive.read(name)
                    if hashlib.blake2b(blob, digest_size=16).hexdigest() != identity:
                        raise PokerError("policy history matrix content identity mismatch")
                    buffer = io.BytesIO(blob)
                    arrays[identity] = np.load(buffer, allow_pickle=False)
                    if buffer.tell() != len(blob):
                        raise PokerError("trailing bytes in policy history matrix")
                record = FrozenOwnDecision(_tupled(entry["key"]), _tupled(entry["actions"]),
                                           arrays[identity], entry["source_id"], entry["assumed"])
                if record.key in records:
                    raise PokerError("duplicate public node in policy history")
                records[record.key] = record
            if set(archive.namelist()) != expected:
                raise PokerError("unexpected files in policy history archive")
        return PolicyHistory(expected_hand_id, records)
    except PokerError:
        raise
    except (OSError, ValueError, TypeError, KeyError, zipfile.BadZipFile, EOFError) as exc:
        raise PokerError(f"invalid policy history archive: {exc}") from exc
