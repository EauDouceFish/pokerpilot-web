"""Browser-local dispatch. No sockets, model server, or training dependencies."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import random
from urllib.parse import parse_qs, unquote, urlsplit

import numpy as np

from .behavior_policy import BehaviorPolicy, preset_traits
from .browser_policy import NumpyAdvantagePolicy
from .challenge import ChallengeStore
from .challenge_diagnostics import export_diagnostics
from .contracts import PokerError
from .policy_observation import InformationObservationPolicy
from .population_match import _sample_action
from .storage import ActionConflict, Store


STYLE_LABELS = {
    "novice_curious": ("好奇萌新", "入池较宽，好奇跟注，位置意识较弱。"),
    "calling_station": ("跟注站", "频繁跟注，较少主动下注，不轻易弃牌。"),
    "fit_or_fold": ("中牌继续型", "没中牌容易放弃，较少诈唬。"),
    "tight_weak": ("紧弱型", "入池范围紧，面对压力倾向弃牌。"),
    "loose_aggressive": ("松凶型", "宽范围入池，频繁主动下注。"),
    "tight_aggressive_leaky": ("有漏洞的紧凶型", "范围偏紧且积极，但存在跟注和尺度漏洞。"),
    "maniac": ("疯狂进攻型", "大量加注和大尺度施压。"),
    "trapper": ("慢打设陷型", "偏好跟注和慢打，强牌主动性不足。"),
    "draw_chaser": ("追听牌型", "频繁追听牌，容易付出过高成本。"),
    "timid_bluffer": ("胆小诈唬型", "会尝试诈唬，但受到反击时容易放弃。"),
}


class BrowserPolicies:
    def __init__(self, asset_dir: str | Path):
        asset_dir = Path(asset_dir)
        self._search = None
        self._pilot = None
        self.default_model = "u49"
        self._hidden: set[str] = set()
        manifest = json.loads((asset_dir / "u49-headsup.json").read_text(encoding="utf-8"))
        weight_bytes = (asset_dir / "u49-headsup.npz").read_bytes()
        if hashlib.blake2b(weight_bytes, digest_size=16).hexdigest() != manifest["weights_blake2b"]:
            raise PokerError("内置模型文件校验失败，请重新加载页面。")
        with np.load(asset_dir / "u49-headsup.npz", allow_pickle=False) as archive:
            provider = NumpyAdvantagePolicy(manifest["metadata"], dict(archive))
        self._policies = {"u49": InformationObservationPolicy(
            provider.probabilities, raise_fractions=(.5, 1.0),
            action_menu="quarter-pot-extra-raise-v1",
        )}
        self._models = {"u49": {
            "id": "u49", "label": "训练 AI · U49（实验）",
            "description": "已训练的固定策略；尚未验证职业水平，也不会根据历史自动调整。",
            "adaptive": False, "family": "U49", "players": 2,
            "component_id": manifest["metadata"]["component_id"],
            "snapshot_digest": manifest["weights_blake2b"],
            "source_snapshot_digest": manifest["source_blake2b"],
            "backend": "numpy-browser-v1", "action_menu": "quarter-pot-extra-raise-v1",
            "qualification": "experimental", "rules_version": "chip-rules-v3",
        }}
        pilot_dir = asset_dir/'pokerpilot-hu'
        if (pilot_dir/'model.json').exists():
            from pokerpilot.agent import HeadsUpAgent
            pilot = HeadsUpAgent(pilot_dir)
            digest = hashlib.blake2b((pilot_dir/'weights.npz').read_bytes(), digest_size=16).hexdigest()
            if digest != pilot.manifest['weights_blake2b']:
                raise PokerError("内置模型文件校验失败，请重新加载页面。")
            self._pilot = pilot
            adaptive = int(pilot.manifest.get('seat_features', 14)) > 14
            self._policies = {'pokerpilot-hu': pilot, **self._policies}
            self._models = {'pokerpilot-hu': {
                'id': 'pokerpilot-hu',
                'label': 'PokerPilot 新 AI · 第三版（单挑特化 + 对手建模）' if adaptive else 'PokerPilot 新 AI · 第一版',
                'description': ('平衡策略起步；同一存档交手满 10 手后，按你在各条街各种局面的公开行动统计'
                                '（以及摊牌亮出的牌）逐步调整，样本少时向平衡策略收缩。' if adaptive else
                                '自博弈 + 磁铁正则训练的平衡策略，直接出牌；暂不根据对手统计调整。'),
                'adaptive': adaptive, 'family': 'pokerpilot-mmd-ppo', 'players': 2,
                'component_id': 'pokerpilot:' + digest, 'snapshot_digest': digest,
                'backend': 'numpy-browser-pokerpilot-v1', 'action_menu': 'pokerpilot-dense-14',
                'qualification': 'experimental', 'rules_version': 'chip-rules-v3',
                **({'adaptation': 'pokerpilot-session-grid-v1'} if adaptive else {}),
            }, **self._models}
            self.default_model = 'pokerpilot-hu'
            self._hidden.add('u49')
        candidate_dir = asset_dir/'foundation-n2'
        if candidate_dir.exists():
            from .browser_average import NumpyAveragePolicy
            from .action_menu import GROWTH_ACTION_MENU
            candidate = NumpyAveragePolicy.from_directory(candidate_dir)
            if candidate.players != 2:
                raise PokerError('单挑挑战必须绑定2人模型')
            package = json.loads((candidate_dir/'model.json').read_text(encoding='utf-8'))
            self._policies['foundation-n2'] = InformationObservationPolicy(
                candidate.probabilities, action_menu=GROWTH_ACTION_MENU)
            self._models['foundation-n2'] = {
                'id': 'foundation-n2', 'label': '新平均策略 · 实验候选',
                'description': '自博弈平均策略直接出牌；此浏览器入口尚未启用搜索或对手适应，棋力未验证。',
                'adaptive': False, 'family': 'foundation-average-v3', 'players': 2,
                'component_id': candidate.policy_id, 'snapshot_digest': package['weights_blake2b'],
                'backend': 'numpy-browser-average-v3', 'action_menu': GROWTH_ACTION_MENU,
                'qualification': 'experimental', 'rules_version': 'chip-rules-v3',
            }
        if (asset_dir/'search/catalog.json').exists():
            from .browser_search import BrowserSearchCatalog
            self._search = BrowserSearchCatalog(asset_dir/'search')
            policy_package = json.loads((asset_dir/'search/N2/model.json').read_text(encoding='utf-8'))
            value_location = self._search.values.get('2')
            value_package = (json.loads((asset_dir/'search'/value_location/'model.json').read_text(encoding='utf-8'))
                             if value_location else None)
            self._models['search-n2'] = {
                'id': 'search-n2', 'label': '实时搜索 AI · 实验候选',
                'description': '本机搜索与价值估计；棋力和速度尚未验证。',
                'adaptive': False, 'family': 'browser-continuation-v1', 'players': 2,
                'component_id': policy_package['policy_id'],
                'snapshot_digest': policy_package['weights_blake2b'],
                'value_digest': value_package['weights_blake2b'] if value_package else None,
                'backend': 'numpy-browser-search-v1', 'action_menu': policy_package['action_menu'],
                'qualification': 'experimental', 'rules_version': 'chip-rules-v3',
            }
            self._models['search-exploit-n2'] = {
                **self._models['search-n2'], 'id': 'search-exploit-n2',
                'label': '针对性搜索 AI · 实验候选', 'adaptive': True,
                'description': '依据此存档已发生的公开行动调整对手模型；样本少时向基础策略收缩，收益未验证。',
                'adaptation': 'public-frequency-beta40-v1',
            }
        for name, traits in preset_traits().items():
            label, description = STYLE_LABELS[name]
            encoded = json.dumps(asdict(traits), sort_keys=True).encode()
            fingerprint = hashlib.blake2b(encoded, digest_size=16).hexdigest()
            self._policies[name] = BehaviorPolicy(traits, name, rank_backend="python")
            self._models[name] = {
                "id": name, "label": label, "description": description,
                "adaptive": False, "family": "scripted-style-v1", "players": 2,
                "component_id": "behavior-v1:" + name + ":" + fingerprint,
                "snapshot_digest": fingerprint, "backend": "python-browser-v1",
                "action_menu": "behavior-candidate-menu-v1",
                "qualification": "experimental", "rules_version": "chip-rules-v3",
            }

    def identity(self, model_id: str | None = None) -> dict:
        model_id = self.default_model if model_id is None else model_id
        if not isinstance(model_id, str) or model_id not in self._models:
            raise PokerError("未知 AI 类型")
        return deepcopy(self._models[model_id])

    def catalog(self) -> list[dict]:
        return [deepcopy(value) for key, value in self._models.items() if key not in self._hidden]

    def choose(self, observation: dict, seed: int, expected_model: dict) -> dict:
        self._validate_view(observation, expected_model)
        if type(seed) is not int:
            raise PokerError("AI 行动种子必须为整数。")
        if expected_model['id'] in ('search-n2', 'search-exploit-n2'):
            raise PokerError('搜索模型需要带历史策略记录的行动入口')
        kind, amount, _ = _sample_action(self._policies[expected_model["id"]], observation, random.Random(seed))
        return {"kind": kind, "amount_to": str(amount)}

    def choose_context(self, observation, seed, expected_model, *, recorded_policies, capture_policy,
                       opponent_counters=None, session=None):
        if expected_model.get('id') == 'pokerpilot-hu' and expected_model.get('adaptive') and session:
            self._validate_view(observation, expected_model)
            if type(seed) is not int:
                raise PokerError("AI 行动种子必须为整数。")
            key, load_hands = session
            stats = self._pilot.session_stats(key, load_hands)
            dist = self._pilot.evaluate(deepcopy(observation), stats)[0]
            kind, amount, _ = _sample_action(lambda _: dist, observation, random.Random(seed))
            return {"kind": kind, "amount_to": str(amount)}
        if expected_model.get('id') not in ('search-n2', 'search-exploit-n2'):
            return self.choose(observation, seed, expected_model)
        self._validate_view(observation, expected_model)
        counters = opponent_counters or {}
        evidence = any(name.endswith('/opportunities') and value > 0 for name, value in counters.items())
        exploit = expected_model['id'] == 'search-exploit-n2' and evidence
        captured = []
        result = self._search.analyze(observation, seed=seed, budget_ms=3000,
            recorded_policies=recorded_policies, capture_policy=captured.append,
            mode='exploit' if exploit else 'baseline', opponent_profiles={0: counters} if exploit else None)
        if result.get('chosen_action') is None:
            raise PokerError('本次搜索未能在 3 秒内完成，请重试；没有执行替代策略。')
        action = result['chosen_action']
        if len(captured) != 1:
            raise PokerError('搜索动作缺少完整的实际策略记录')
        capture_policy(captured[0])
        return {'kind': action['kind'], 'amount_to': action['amount_to']}

    def _validate_view(self, observation: dict, expected_model: dict) -> None:
        model_id = expected_model.get("id")
        if expected_model != self.identity(model_id):
            raise PokerError("存档绑定的模型版本已改变，不能静默替换。")
        if (observation.get("viewer") != 1 or observation.get("actor") != 1
                or len(observation.get("players", [])) != 2
                or observation["players"][0].get("hole_cards")
                or observation.get("is_terminal")):
            raise PokerError("AI 只能读取自己的行动视图。")

    def distribution(self, observation: dict, expected_model: dict) -> list[dict]:
        self._validate_view(observation, expected_model)
        if expected_model['id'] in ('search-n2', 'search-exploit-n2'):
            raise PokerError('搜索策略必须结合当时的历史记录分析，不能按固定策略重算')
        return deepcopy(self._policies[expected_model["id"]](deepcopy(observation)))


class BrowserChallenge:
    def __init__(self, policies: BrowserPolicies):
        self.policies = policies

    def dispatch(self, request_json: str, input_path: str, output_path: str) -> str:
        """One serialized transaction. The worker durably saves output before replying."""
        store = Store(":memory:")
        try:
            if Path(input_path).is_file():
                store.connection.deserialize(Path(input_path).read_bytes())
            challenges = ChallengeStore(store)
            request = json.loads(request_json)
            result = self._route(challenges, request)
            if request.get("method", "GET") == "POST":
                Path(output_path).write_bytes(store.connection.serialize())
            return json.dumps({"result": result}, ensure_ascii=False, allow_nan=False)
        except ActionConflict as exc:
            return json.dumps({"error": str(exc), "status": 409}, ensure_ascii=False)
        except TimeoutError:
            return json.dumps({'error': '本次搜索超时，未执行动作或修改存档。', 'status': 408}, ensure_ascii=False)
        except (PokerError, ValueError, KeyError, TypeError) as exc:
            return json.dumps({"error": str(exc), "status": 400}, ensure_ascii=False)
        finally:
            store.close()

    def _route(self, challenges: ChallengeStore, request: dict):
        url = urlsplit(request["path"])
        method = request.get("method", "GET")
        body = request.get("body") or {}
        segments = [unquote(part) for part in url.path.strip("/").split("/")]
        if segments == ['api', 'analyze-scenario'] and method == 'POST':
            if self.policies._search is None:
                raise PokerError('当前资源包没有多人搜索模型')
            from .game import PokerHand
            stacks = body['stacks']
            hero = body['hero_seat']
            if (not isinstance(stacks, list) or not 2 <= len(stacks) <= 9
                    or type(hero) is not int or not 0 <= hero < len(stacks)):
                raise PokerError('请选择 2～9 人以及合法分析座位')
            holes = [[] for _ in stacks]
            holes[hero] = body['hole_cards']
            if len(holes[hero]) != 2:
                raise PokerError('分析手牌必须为两张')
            board = body.get('board_cards', [])
            if not isinstance(board, list) or len(board) not in (0, 3, 4, 5):
                raise PokerError('公共牌数量必须是 0、3、4 或 5 张')
            hand = PokerHand(stacks, button=body['button'], small_blind=body['small_blind'],
                big_blind=body['big_blind'], ante_mode=body.get('ante_mode', 'none'),
                ante=body.get('ante', '0'), bba_order=body.get('bba_order', 'ante_first'),
                hole_cards=holes, board_cards=board, seed=0, rules_version='chip-rules-v3')
            for action in body.get('actions', []):
                hand.act(action['seat'], action['kind'], action.get('amount_to'))
            if hand.is_terminal or hand.actor != hero:
                raise PokerError('历史必须结束在分析座位尚未行动的决策点')
            observation = hand.view(hero)
            if observation['board'] != board:
                raise PokerError('公共牌必须与行动历史推进到的街一致')
            result = self.policies._search.analyze(observation, budget_ms=3000, seed=0)
            return {'observation': observation, 'analysis': result,
                    'history_assumption': 'Other players ranges inferred from the frozen baseline policy.'}
        if segments[:2] != ["api", "challenges"]:
            raise PokerError("未知本机操作")
        tail = segments[2:]
        if method == "GET" and not tail:
            return {"challenges": challenges.list()}
        if method == "GET" and tail == ["model"]:
            return {"available": True, "model": self.policies.identity(),
                    "catalog": self.policies.catalog(), "detail": None}
        if method == "POST" and not tail:
            return challenges.create(name=body["name"], mode=body["mode"],
                target=body["target"], model=self.policies.identity(body["model_id"]),
                request_id=body["request_id"])
        if not tail:
            raise PokerError("未知本机操作")
        key = tail[0]
        if method == "GET":
            if len(tail) == 1:
                return challenges.get(key)
            if tail[1:] == ["diagnostics"]:
                query = parse_qs(url.query, keep_blank_values=True)
                if set(query) - {"offset", "limit"} or any(len(v) != 1 for v in query.values()):
                    raise PokerError("未知或重复诊断参数")
                return export_diagnostics(challenges, self.policies, key,
                    offset=int(query["offset"][0]) if "offset" in query else None,
                    limit=int(query.get("limit", [10])[0]))
            if tail[1:] == ["curve"]:
                return challenges.curve(key)
            if tail[1:] == ["metrics"]:
                return challenges.metrics(key)
            if tail[1:] == ["history"]:
                query = parse_qs(url.query)
                return challenges.history(key, offset=int(query.get("offset", [0])[0]),
                                          limit=int(query.get("limit", [50])[0]))
            if len(tail) == 3 and tail[1] == "history":
                return challenges.record(key, int(tail[2]))
        if method == "POST" and len(tail) == 2 and tail[1] in ("act", "ai", "next", "buyin"):
            action = ({"kind": body["kind"], "amount_to": body.get("amount_to")}
                      if tail[1] == "act" else None)
            return challenges.command(key, kind=tail[1], revision=body["revision"],
                request_id=body["request_id"], action=action,
                contextual_policy=self.policies.choose_context if tail[1] == "ai" else None)
        raise PokerError("未知本机操作")
