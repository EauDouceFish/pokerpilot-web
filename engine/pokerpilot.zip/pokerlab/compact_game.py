"""Immutable search-only NLHE state, imported once from a verified v3 root.

PokerKit remains the application rules engine and the differential reference.
This adapter does not alter the public search information abstraction.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, replace
from typing import Any

from pokerkit import StandardHighHand

from .action_menu import FULL_ACTION_MENU, raise_targets, validate_action_menu
from .betting_round import BettingRound
from .belief import COMBOS, DECK
from .contracts import PokerError, chips
from .evaluator import side_pot_payouts
from .game import PokerHand
from .mccfr import CHANCE
from .native_kernel import evaluate_many, side_pot_payouts as native_payouts
from .poker_game import FinitePokerGame, _freeze
from .resampled_game import DealSample, ResampledPokerGame

_STREETS = ("preflop", "flop", "turn", "river")
_BOARD_COUNTS = (0, 3, 4, 5)
_COMBO_INDEX = {frozenset(combo): index for index, combo in enumerate(COMBOS)}


@dataclass(frozen=True, slots=True)
class CompactHand:
    initial_stacks: tuple[int, ...]
    button: int
    small_blind: int
    big_blind: int
    ante_mode: str
    ante: int
    bba_order: str
    street_index: int
    betting: BettingRound
    committed: tuple[int, ...]
    ante_paid: tuple[int, ...]
    events: tuple[tuple, ...]
    holes: tuple[tuple[str, ...], ...]
    full_board: tuple[str, ...]
    final_stacks: tuple[int, ...] | None = None

    @classmethod
    def from_hand(cls, hand: PokerHand) -> CompactHand:
        if hand.rules_version != "chip-rules-v3" or hand.is_terminal:
            raise PokerError("紧凑状态入口要求非终局 chip-rules-v3")
        state = hand._state
        internal = hand._physical_to_internal
        physical = hand._internal_to_physical
        config = hand.config
        return cls(
            tuple(hand.initial_stacks), hand.button, hand.small_blind, hand.big_blind,
            hand.ante_mode, hand.ante, hand.bba_order, state.street_index,
            BettingRound(
                tuple(state.stacks[i] for i in internal),
                tuple(state.bets[i] for i in internal),
                tuple(state.statuses[i] for i in internal),
                tuple(physical[i] for i in state.actor_indices),
                tuple(state._v3_acted_at[i] for i in internal),
                state._v3_full_increment, state._v3_nominal_floor,
            ),
            tuple(hand._committed), tuple(hand._ante_paid),
            tuple((e["seat"], e["kind"], e["amount_to"], e["put_in"], e["street"], e["version"])
                  for e in hand.history),
            tuple(tuple(cards) for cards in config["hole_cards"]),
            tuple(config["board_cards"]),
        )

    @property
    def actor(self) -> int | None:
        return None if self.is_terminal else self.betting.actor

    @property
    def is_terminal(self) -> bool:
        return self.final_stacks is not None

    @property
    def version(self) -> int:
        return len(self.events)

    @property
    def board(self) -> tuple[str, ...]:
        return self.full_board[:_BOARD_COUNTS[self.street_index]]

    @property
    def rules(self) -> dict[str, str]:
        return {"small_blind": str(self.small_blind), "big_blind": str(self.big_blind),
                "ante_mode": self.ante_mode, "ante": str(self.ante),
                "bba_order": self.bba_order, "version": "chip-rules-v3"}

    @property
    def result(self) -> dict | None:
        if self.final_stacks is None:
            return None
        return {"final_stacks": list(map(str, self.final_stacks)),
                "net": [str(final - start) for final, start in
                        zip(self.final_stacks, self.initial_stacks, strict=True)],
                "winners": [i for i, final in enumerate(self.final_stacks)
                            if final > self.initial_stacks[i] - self.committed[i]]}

    def apply(self, kind: str, amount_to: int | str | None = None,
              rank_backend: str = "native") -> CompactHand:
        if self.is_terminal:
            raise PokerError("终局不能继续行动")
        if rank_backend not in ("native", "pokerkit"):
            raise PokerError("rank_backend 必须是 native 或 pokerkit")
        actor = self.actor
        assert actor is not None
        updated = self.betting.apply(kind, None if amount_to is None else chips(amount_to))
        put_in = self.betting.stacks[actor] - updated.stacks[actor]
        committed = list(self.committed)
        committed[actor] += put_in
        event = (actor, kind, str(updated.bets[actor]), str(put_in),
                 _STREETS[self.street_index], self.version + 1)
        child = replace(self, betting=updated, committed=tuple(committed),
                        events=(*self.events, event))
        return child if updated.pending else child._close_round(rank_backend)

    def _close_round(self, rank_backend: str) -> CompactHand:
        betting = self.betting
        stacks, committed = list(betting.stacks), list(self.committed)
        live = [i for i, active in enumerate(betting.active) if active]
        cutoff = sorted(betting.bets)[-2]
        for seat, amount in enumerate(betting.bets):
            # A fold ends the hand: the sole survivor's current bet is not
            # part of the collected pool. Other unmatched bets are refunded.
            refund = amount if len(live) == 1 and seat == live[0] else max(0, amount - cutoff)
            stacks[seat] += refund
            committed[seat] -= refund
        count = len(stacks)
        still_betting = sum(bool(betting.active[i] and stacks[i]) for i in range(count))
        terminal = len(live) == 1 or still_betting < 2 or self.street_index == 3
        street = self.street_index if len(live) == 1 else 3 if terminal else self.street_index + 1
        pending = () if terminal else tuple(
            seat for offset in range(count)
            if betting.active[seat := (self.button + 1 + offset) % count] and stacks[seat]
        )
        next_round = BettingRound(tuple(stacks), (0,) * count, betting.active, pending,
                                  (None,) * count, self.big_blind, 0)
        child = replace(self, betting=next_round, committed=tuple(committed), street_index=street)
        if not terminal:
            return child
        folded = [i for i, active in enumerate(betting.active) if not active]
        amounts = [committed[i] - self.ante_paid[i] for i in range(count)]
        ranks = {}
        if len(live) > 1:
            hands = [(*self.holes[seat], *self.full_board) for seat in live]
            # PokerKit entry indexes are ordered from weaker to stronger.
            # The independent payout routine only compares rank tuples.
            values = (evaluate_many(hands) if rank_backend == "native" else
                      [(StandardHighHand.from_game("".join(self.holes[seat]),
                                                   "".join(self.full_board)).entry.index,)
                       for seat in live])
            ranks = dict(zip(live, values, strict=True))
        if rank_backend == "native":
            payouts = native_payouts(amounts, folded, ranks, dead_money=sum(self.ante_paid), button=self.button)
        else:
            payouts = side_pot_payouts(amounts, folded, ranks, dead_money=sum(self.ante_paid),
                                      seat_order=[(self.button + 1 + i) % count for i in range(count)])
        final = tuple(stack + payout for stack, payout in zip(stacks, payouts, strict=True))
        if sum(final) != sum(self.initial_stacks):
            raise AssertionError("紧凑状态筹码不守恒")
        return replace(child, final_stacks=final)

    def legal_details(self) -> list[dict]:
        if self.actor is None:
            return []
        actor = self.actor
        current = self.betting.bets[actor]
        stack = self.betting.stacks[actor]
        result = []
        for kind, _ in self.betting.legal_actions():
            call = self.betting.to_call() if kind == "call" else 0
            result.append({"kind": kind, "amount_to": str(current + call),
                           "put_in": str(call), "all_in": call > 0 and call == stack})
        bounds = self.betting.raise_bounds()
        if bounds is not None:
            minimum, maximum = bounds
            kind = "raise" if self.street_index == 0 or max(self.betting.bets) else "bet"
            result.append({"kind": kind, "amount_to": str(minimum), "put_in": str(minimum - current),
                           "all_in": minimum - current == stack, "min_to": str(minimum), "max_to": str(maximum)})
        return result

    def view(self, viewer: int) -> dict[str, Any]:
        count = len(self.initial_stacks)
        if type(viewer) is not int or not 0 <= viewer < count:
            raise PokerError("查看座位无效")
        betting = self.betting
        stacks = self.final_stacks if self.is_terminal else betting.stacks
        assert stacks is not None
        players = []
        for seat in range(count):
            status = ("folded" if not betting.active[seat] else
                      "out" if self.is_terminal and not stacks[seat] else
                      "all_in" if not self.is_terminal and not stacks[seat] else "active")
            players.append({"seat": seat, "stack": str(stacks[seat]),
                            "starting_stack": str(self.initial_stacks[seat]),
                            "committed": str(self.committed[seat]), "ante_paid": str(self.ante_paid[seat]),
                            "street_committed": str(betting.bets[seat]), "status": status,
                            "hole_cards": list(self.holes[seat]) if seat == viewer else []})
        pots: list[dict] = []
        if not self.is_terminal:
            active = [i for i in range(count) if betting.active[i]]
            if sum(self.ante_paid):
                pots.append({"amount": str(sum(self.ante_paid)), "eligible": active})
            live = [self.committed[i] - self.ante_paid[i] for i in range(count)]
            previous = 0
            for level in sorted({value for value in live if value}):
                amount = (level - previous) * sum(value >= level for value in live)
                eligible = [i for i in active if live[i] + stacks[i] >= level]
                if pots and pots[-1]["eligible"] == eligible:
                    pots[-1]["amount"] = str(int(pots[-1]["amount"]) + amount)
                else:
                    pots.append({"amount": str(amount), "eligible": eligible})
                previous = level
        bounds = None if self.actor is None else betting.raise_bounds()
        return {"schema_version": 1, "version": self.version,
                "street": "showdown" if self.is_terminal else _STREETS[self.street_index],
                "button": self.button, "actor": self.actor, "viewer": viewer,
                "hero_cards": list(self.holes[viewer]), "board": list(self.board),
                "pot": "0" if self.is_terminal else str(sum(self.committed)),
                "to_call": str(betting.to_call() if self.actor is not None else 0),
                "min_raise_to": str(bounds[0] if bounds else 0), "can_raise": bounds is not None,
                "is_terminal": self.is_terminal, "rules": self.rules, "players": players,
                "pots": pots, "legal_actions": self.legal_details(),
                "history": [dict(zip(("seat", "kind", "amount_to", "put_in", "street", "version"), e))
                            for e in self.events], "result": self.result}

    def information_key(self) -> tuple:
        if self.actor is None:
            raise PokerError("终局没有信息集")
        players = tuple((i, str(self.betting.stacks[i]), str(self.initial_stacks[i]),
                         str(self.committed[i]), str(self.ante_paid[i]), str(self.betting.bets[i]),
                         "folded" if not self.betting.active[i] else "all_in" if not self.betting.stacks[i] else "active")
                        for i in range(len(self.initial_stacks)))
        return ("finite-nlhe-v1", self.actor, self.button, _STREETS[self.street_index],
                tuple(sorted(self.holes[self.actor])), self.board, players, _freeze(self.rules), self.events)


@dataclass(frozen=True, slots=True)
class CompactState:
    hand: CompactHand | None = None


class CompactPokerGame:
    """Same chance/information protocol with tuple-only branch transitions."""

    def __init__(self, base: FinitePokerGame, *, action_menu=FULL_ACTION_MENU):
        if not isinstance(base, FinitePokerGame):
            raise PokerError("紧凑适配器需要 FinitePokerGame 或 ResampledPokerGame")
        self._action_menu = validate_action_menu(action_menu)
        self.base = base
        self.num_players = base.num_players
        self.chance_mode = getattr(base, "chance_mode", "enumerable")
        self._roots = tuple(CompactHand.from_hand(hand) for hand in base._roots)
        self._rank_backend = base._rank_backend
        self._fractions = base._raise_fractions
        self._chance_samples = 0

    @property
    def action_menu_version(self) -> str:
        return self._action_menu

    @property
    def diagnostics(self) -> dict:
        result = {**self.base.diagnostics, "state_backend": "compact-v1",
                  "settlement_backend": "native-int64-or-python-bigint" if self._rank_backend == "native" else "python",
                  "chance_samples": self._chance_samples, "quality_qualified": False}
        if self._action_menu != FULL_ACTION_MENU:
            result["action_menu_version"] = self._action_menu
        return result

    def initial_state(self) -> CompactState:
        return CompactState()

    def is_terminal(self, state: CompactState) -> bool:
        return state.hand is not None and state.hand.is_terminal

    def current_player(self, state: CompactState) -> int:
        if state.hand is None:
            return CHANCE
        if state.hand.actor is None:
            raise PokerError("终局没有行动玩家")
        return state.hand.actor

    def chance_outcomes(self, state: CompactState):
        if not isinstance(state, CompactState) or state.hand is not None:
            raise PokerError("只有根节点是 chance")
        return self.base.chance_outcomes(self.base.initial_state())

    def sample_chance_on_policy(self, state: CompactState, rng: random.Random) -> DealSample:
        if not isinstance(state, CompactState) or state.hand is not None or not isinstance(self.base, ResampledPokerGame):
            raise PokerError("只有生成式根节点可以采样")
        return self.base.sample_chance_on_policy(self.base.initial_state(), rng)

    def legal_actions(self, state: CompactState) -> tuple:
        hand = self._decision(state)
        actor = hand.actor
        assert actor is not None
        result = [(kind, None) for kind, _ in hand.betting.legal_actions()]
        bounds = hand.betting.raise_bounds()
        if bounds:
            low, high = bounds
            call = hand.betting.to_call()
            paid = hand.betting.bets[actor]
            pot = sum(hand.committed)
            kind = "raise" if hand.street_index == 0 or max(hand.betting.bets) else "bet"
            targets = raise_targets(kind=kind, paid=paid, call=call, pot=pot, low=low,
                                    high=high, fractions=self._fractions,
                                    action_menu=self._action_menu)
            result.extend((kind, value) for value in targets)
        return tuple(result)

    def next_state(self, state: CompactState, action) -> CompactState:
        if not isinstance(state, CompactState):
            raise PokerError("state 必须是 CompactState")
        if state.hand is None:
            if self.chance_mode == "sampled_on_policy":
                root = self._resampled_root(action)
            else:
                if type(action) is not int or not 0 <= action < len(self._roots):
                    raise PokerError("chance 索引无效")
                root = self._roots[action]
            self._chance_samples += 1
            return CompactState(root)
        if not isinstance(action, tuple) or len(action) != 2 or action not in self.legal_actions(state):
            raise PokerError("动作不在当前有限动作集合中")
        return CompactState(state.hand.apply(*action, rank_backend=self._rank_backend))

    def _resampled_root(self, action) -> CompactHand:
        if not isinstance(action, DealSample):
            raise PokerError("生成式根节点需要 DealSample")
        if (type(action.holes) is not tuple or len(action.holes) != self.num_players
                or any(type(pair) is not tuple or len(pair) != 2 for pair in action.holes)
                or type(action.board) is not tuple or len(action.board) != 5):
            raise PokerError("DealSample 结构无效")
        all_cards = [*action.board, *(card for pair in action.holes for card in pair)]
        if any(type(card) is not str or card not in DECK for card in all_cards) or len(set(all_cards)) != len(all_cards):
            raise PokerError("DealSample 牌无效或重复")
        base = self.base
        assert isinstance(base, ResampledPokerGame)
        if set(base.belief.dead_cards).intersection(all_cards):
            raise PokerError("DealSample contains an explicitly dead card")
        if action.board[:len(base._public_board)] != base._public_board:
            raise PokerError("DealSample 必须保留公开牌")
        for seat, pair in enumerate(action.holes):
            if base.belief.weights[seat][_COMBO_INDEX[frozenset(pair)]] <= 0:
                raise PokerError("DealSample 不在公共范围支持中")
        return replace(self._roots[0], holes=action.holes, full_board=action.board)

    def information_key(self, state: CompactState):
        return self._decision(state).information_key()

    def information_key_for_combo(self, state: CompactState, combo: tuple[str, str]):
        """Actor's hypothetical private combo; other sampled cards are irrelevant.

        Used for full-combo strategy likelihoods at one public decision. A
        collision with a sampled opponent card is deliberately not a blocker:
        that private deal is unknown to the actor and to the public belief.
        """
        return next(self.information_keys_for_combos(state, (combo,)))

    def information_keys_for_combos(self, state: CompactState, combos):
        """Yield hypothetical actor keys while freezing one public-node prefix."""

        hand = self._decision(state)
        key = hand.information_key()
        board = set(hand.board)

        def generate():
            for combo in combos:
                if (type(combo) is not tuple or len(combo) != 2 or combo[0] == combo[1]
                        or any(type(card) is not str or card not in DECK for card in combo)
                        or board.intersection(combo)):
                    raise PokerError("假设组合必须是两张不冲突的有效牌且不包含公共牌")
                yield (*key[:4], tuple(sorted(combo)), *key[5:])

        return generate()

    def public_observation(self, state: CompactState) -> dict[str, Any]:
        """Only public fields for a future range-conditioned leaf adapter."""
        hand = self._decision(state)
        observation = hand.view(hand.actor)
        observation["hero_cards"] = []
        for player in observation["players"]:
            player["hole_cards"] = []
        return observation

    def returns(self, state: CompactState) -> tuple[float, ...]:
        hand = state.hand
        if hand is None or hand.final_stacks is None:
            raise PokerError("只有终局可读取收益")
        net = tuple(final - start for final, start in zip(hand.final_stacks, hand.initial_stacks, strict=True))
        if sum(net):
            raise AssertionError("终局净收益必须零和")
        return tuple(value / hand.big_blind for value in net)

    @staticmethod
    def _decision(state: CompactState) -> CompactHand:
        if state.hand is None or state.hand.actor is None:
            raise PokerError("当前不是决策节点")
        return state.hand
