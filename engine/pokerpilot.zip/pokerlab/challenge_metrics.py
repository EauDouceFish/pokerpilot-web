"""Descriptive, opportunity-based statistics from public challenge frames."""
from __future__ import annotations

import math
from statistics import median
from typing import Any

from .contracts import PokerError, chips
from .evaluator import evaluate_hand


_METRIC_NAMES = (
    "vpip", "pfr", "three_bet", "fold_to_three_bet", "cbet_flop",
    "fold_to_cbet", "aggression", "fold_facing_bet", "weak_made_hand_bet",
    "overbet",
)
_POSTFLOP = frozenset(("flop", "turn", "river"))
_BUCKETS = (
    ("<=0.33", 0.33),
    ("0.33-0.75", 0.75),
    ("0.75-1.00", 1.0),
    (">1.00", math.inf),
)


def _empty_metrics() -> dict[str, list[int]]:
    return {name: [0, 0] for name in _METRIC_NAMES}


def _add(metrics: dict[str, list[int]], name: str, success: bool) -> None:
    metrics[name][1] += 1
    metrics[name][0] += int(success)


def _rate(pair: list[int]) -> dict[str, int | float | None]:
    successes, opportunities = pair
    return {
        "successes": successes,
        "opportunities": opportunities,
        "rate": successes / opportunities if opportunities else None,
    }


def _legal(observation: dict, kind: str) -> bool:
    return any(item.get("kind") == kind for item in observation.get("legal_actions", []))


def _facing_bet(observation: dict) -> bool:
    return _legal(observation, "fold") and chips(observation.get("to_call", "0")) > 0


def _active_available(observation: dict) -> bool:
    return _legal(observation, "bet") or _legal(observation, "raise")


def _validated_decisions(record: dict) -> list[tuple[dict, dict]] | None:
    frames = record.get("frames", [])
    if frames == []:
        return None
    if type(frames) is not list or len(frames) < 1:
        raise PokerError("挑战复盘 frames 格式无效")
    events = record.get("events")
    if type(events) is not list or len(frames) != len(events) + 1:
        raise PokerError("挑战复盘 frames 与 events 数量不一致")
    decisions: list[tuple[dict, dict]] = []
    for index, frame in enumerate(frames):
        if type(frame) is not dict or frame.get("index") != index:
            raise PokerError("挑战复盘 frame 序号无效")
        observation = frame.get("observation")
        if type(observation) is not dict:
            raise PokerError("挑战复盘 observation 格式无效")
        if index == 0:
            if frame.get("event") is not None:
                raise PokerError("挑战复盘初始 frame 不应包含行动")
            continue
        event = frame.get("event")
        if type(event) is not dict or event != events[index - 1]:
            raise PokerError("挑战复盘 frame 行动不一致")
        before = frames[index - 1]["observation"]
        seat = event.get("seat")
        if seat not in (0, 1) or before.get("actor") != seat:
            raise PokerError("挑战复盘行动座位不一致")
        decisions.append((before, event))
    return decisions


def _sizing_fraction(observation: dict, event: dict) -> float:
    seat = event["seat"]
    players = observation.get("players")
    if type(players) is not list or len(players) != 2:
        raise PokerError("挑战复盘玩家状态无效")
    player = players[seat]
    amount_to = chips(event.get("amount_to"))
    committed = chips(player.get("street_committed"))
    to_call = chips(observation.get("to_call", "0"))
    increment = amount_to - committed - to_call
    denominator = chips(observation.get("pot", "0")) + to_call
    if increment <= 0 or denominator <= 0:
        raise PokerError("挑战复盘下注尺度无效")
    return increment / denominator


def _high_card_opportunity(observation: dict, seat: int) -> bool:
    players = observation.get("players")
    board = observation.get("board")
    if type(players) is not list or len(players) != 2 or type(board) is not list:
        raise PokerError("挑战复盘牌面状态无效")
    holes = players[seat].get("hole_cards")
    if type(holes) is not list or len(holes) != 2 or len(board) not in (3, 4, 5):
        return False
    return evaluate_hand([*holes, *board])[0] == 0


def _style(metrics: dict[str, list[int]]) -> dict[str, int | str]:
    evidence = metrics["vpip"][1]
    if evidence < 20:
        return {"label": "样本不足", "evidence_hands": evidence}
    vpip = metrics["vpip"][0] / evidence
    aggression_pair = metrics["aggression"]
    aggression = (aggression_pair[0] / aggression_pair[1]
                  if aggression_pair[1] else 0.0)
    looseness = "宽松" if vpip >= 0.40 else "紧凑" if vpip <= 0.25 else "中等"
    initiative = "主动" if aggression >= 0.40 else "被动"
    return {"label": f"{looseness}{initiative}", "evidence_hands": evidence}


def summarize_records(records: list[dict]) -> dict:
    """Summarize only public, contemporaneous frames from completed records."""

    if type(records) is not list or any(type(record) is not dict for record in records):
        raise PokerError("挑战统计需要公开 completedRecord 列表")
    metrics = [_empty_metrics(), _empty_metrics()]
    sizings: list[list[float]] = [[], []]
    missing_frames = 0

    for record in records:
        decisions = _validated_decisions(record)
        if decisions is None:
            missing_frames += 1
            continue
        preflop_decision = [False, False]
        vpip = [False, False]
        pfr = [False, False]
        raise_count = 0
        last_raiser: int | None = None
        for observation, event in decisions:
            if event.get("street") != "preflop":
                continue
            seat, kind = event["seat"], event.get("kind")
            preflop_decision[seat] = True
            vpip[seat] |= kind in ("call", "bet", "raise")
            pfr[seat] |= kind in ("bet", "raise")
            if (raise_count == 1 and last_raiser != seat and _facing_bet(observation)
                    and _legal(observation, "raise")):
                _add(metrics[seat], "three_bet", kind == "raise")
            if (raise_count == 2 and last_raiser != seat
                    and _facing_bet(observation)):
                _add(metrics[seat], "fold_to_three_bet", kind == "fold")
            if kind in ("bet", "raise"):
                raise_count += 1
                last_raiser = seat
        for seat in range(2):
            if preflop_decision[seat]:
                _add(metrics[seat], "vpip", vpip[seat])
                _add(metrics[seat], "pfr", pfr[seat])

        preflop_last_raiser = last_raiser
        cbet_evaluated = False
        cbet_bettor: int | None = None
        fold_to_cbet_evaluated = False
        flop_bet_seen = False
        for observation, event in decisions:
            seat, kind, street = event["seat"], event.get("kind"), event.get("street")
            active_available = _active_available(observation)
            if active_available:
                _add(metrics[seat], "aggression", kind in ("bet", "raise"))
            if _facing_bet(observation):
                _add(metrics[seat], "fold_facing_bet", kind == "fold")
            if street in _POSTFLOP and active_available:
                if _high_card_opportunity(observation, seat):
                    _add(metrics[seat], "weak_made_hand_bet", kind in ("bet", "raise"))
            if street in _POSTFLOP and kind in ("bet", "raise"):
                fraction = _sizing_fraction(observation, event)
                sizings[seat].append(fraction)
                _add(metrics[seat], "overbet", fraction > 1.0)

            if street == "flop":
                if (not flop_bet_seen and not cbet_evaluated
                        and seat == preflop_last_raiser and _legal(observation, "bet")):
                    _add(metrics[seat], "cbet_flop", kind == "bet")
                    cbet_evaluated = True
                    if kind == "bet":
                        cbet_bettor = seat
                if (cbet_bettor is not None and not fold_to_cbet_evaluated
                        and seat != cbet_bettor and _facing_bet(observation)):
                    _add(metrics[seat], "fold_to_cbet", kind == "fold")
                    fold_to_cbet_evaluated = True
                if kind in ("bet", "raise"):
                    flop_bet_seen = True

    players = []
    for seat in range(2):
        values = sizings[seat]
        bucket_counts = []
        lower = -math.inf
        for label, upper in _BUCKETS:
            count = sum(lower < value <= upper for value in values)
            bucket_counts.append({"label": label, "count": count})
            lower = upper
        notes = ["弱牌下注仅指当时可见牌组成高牌牌型，可能包含听牌，不等同真实诈唬。"]
        if seat == 1:
            notes.append("AI 私牌在行动时通常不可见；这些机会不计，弱牌样本存在可见性偏差。")
        if missing_frames:
            notes.append(f"{missing_frames} 手缺少逐行动 frames，未纳入机会统计。")
        players.append({
            "seat": seat,
            "metrics": {name: _rate(metrics[seat][name]) for name in _METRIC_NAMES},
            "sizing": {
                "count": len(values),
                "mean_pot_fraction": math.fsum(values) / len(values) if values else None,
                "median_pot_fraction": median(values) if values else None,
                "buckets": bucket_counts,
            },
            "style": _style(metrics[seat]),
            "notes": notes,
        })
    limitations = [
        "统计只描述已记录的行动机会，不识别玩家本质，也不证明 GTO 平衡。",
        "尚无合格 EV 或范围基准，无法认证下注尺度合理、极化/平衡或真实诈唬频率。",
        "弱牌下注是高牌牌型代理，包含部分听牌且排除行动时不可见的私牌。",
    ]
    if missing_frames:
        limitations.append(f"{missing_frames} 手旧记录没有 frames，明确排除于行动统计。")
    return {"hands": len(records), "players": players, "limitations": limitations}
