"""Immutable, arbitrary-precision state for one no-limit betting street."""

from __future__ import annotations

from dataclasses import dataclass, replace

from pokerlab.contracts import PokerError


def _integer(value: object, *, minimum: int = 0, name: str = "amount") -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise PokerError(f"{name} must be an integer of at least {minimum}")
    return value


@dataclass(frozen=True, slots=True)
class BettingRound:
    """A single no-limit betting street without dealing or settlement."""

    stacks: tuple[int, ...]
    bets: tuple[int, ...]
    active: tuple[bool, ...]
    pending: tuple[int, ...]
    acted_at: tuple[int | None, ...]
    full_increment: int
    nominal_floor: int

    def __post_init__(self) -> None:
        fields = (self.stacks, self.bets, self.active, self.pending, self.acted_at)
        if not all(isinstance(value, tuple) for value in fields):
            raise PokerError("betting-round vector fields must be tuples")
        count = len(self.stacks)
        if not 2 <= count <= 9:
            raise PokerError("player count must be between 2 and 9")
        if len(self.bets) != count or len(self.active) != count or len(self.acted_at) != count:
            raise PokerError("betting-round vector lengths do not match")
        for value in self.stacks:
            _integer(value, name="stack")
        for value in self.bets:
            _integer(value, name="bet")
        if any(not isinstance(value, bool) for value in self.active):
            raise PokerError("active values must be booleans")
        _integer(self.full_increment, minimum=1, name="full increment")
        _integer(self.nominal_floor, name="nominal floor")

        seen: set[int] = set()
        for seat in self.pending:
            _integer(seat, name="pending seat")
            if seat >= count or seat in seen:
                raise PokerError("pending seats must be unique valid seats")
            if not self.active[seat] or not self.stacks[seat]:
                raise PokerError("pending seats must be active and have chips")
            seen.add(seat)

        ceiling = max(max(self.bets), self.nominal_floor)
        for value in self.acted_at:
            if value is not None:
                _integer(value, name="acted-at amount")
                if value > ceiling:
                    raise PokerError("acted-at amount exceeds the current wager")

    @property
    def actor(self) -> int | None:
        return self.pending[0] if self.pending else None

    def wager_level(self) -> int:
        actual = max(self.bets)
        actor = self.actor
        if actor is None or self.nominal_floor <= actual:
            return actual
        if any(
            seat != actor and self.active[seat] and self.stacks[seat]
            for seat in range(len(self.stacks))
        ):
            return self.nominal_floor
        return actual

    def to_call(self) -> int | None:
        actor = self.actor
        if actor is None:
            return None
        return min(self.stacks[actor], self.wager_level() - self.bets[actor])

    def raise_bounds(self) -> tuple[int, int] | None:
        actor = self.actor
        if actor is None:
            return None
        wager = self.wager_level()
        acted_at = self.acted_at[actor]
        if acted_at is not None and wager - acted_at < self.full_increment:
            return None
        call = self.to_call()
        assert call is not None
        if self.stacks[actor] <= call:
            return None
        if not any(
            seat != actor
            and self.active[seat]
            and self.stacks[seat] + self.bets[seat] > wager
            for seat in range(len(self.stacks))
        ):
            return None
        maximum = self.bets[actor] + self.stacks[actor]
        minimum = min(maximum, wager + self.full_increment)
        return minimum, maximum

    def legal_actions(self) -> tuple[tuple[str, int | None], ...]:
        actor = self.actor
        if actor is None:
            return ()
        call = self.to_call()
        assert call is not None
        target = self.bets[actor] + call
        if call:
            return (("fold", self.bets[actor]), ("call", target))
        return (("check", target),)

    def apply(self, kind: str, amount_to: int | None = None) -> BettingRound:
        actor = self.actor
        if actor is None:
            raise PokerError("betting round is complete")
        if kind not in ("fold", "check", "call", "bet", "raise"):
            raise PokerError("invalid betting action")
        prior_wager = self.wager_level()

        if kind in ("fold", "check", "call"):
            call = self.to_call()
            assert call is not None
            if kind == "fold":
                if not call:
                    raise PokerError("cannot fold when checking is free")
                target = self.bets[actor]
            else:
                if (kind == "check") != (call == 0):
                    raise PokerError("check or call does not match the wager")
                target = self.bets[actor] + call
            if amount_to is not None:
                _integer(amount_to, name="amount-to")
                if amount_to != target:
                    raise PokerError("amount-to does not match the action")

            stacks = list(self.stacks)
            bets = list(self.bets)
            active = list(self.active)
            acted_at = list(self.acted_at)
            if kind == "fold":
                active[actor] = False
            else:
                stacks[actor] -= call
                bets[actor] = target
            acted_at[actor] = prior_wager
            state = replace(
                self,
                stacks=tuple(stacks),
                bets=tuple(bets),
                active=tuple(active),
                pending=self.pending[1:],
                acted_at=tuple(acted_at),
            )
            return state._close_if_finished()

        expected_kind = "raise" if self.nominal_floor or max(self.bets) else "bet"
        if kind != expected_kind:
            raise PokerError("bet or raise does not match the current wager")
        if amount_to is None:
            raise PokerError("bet or raise requires amount-to")
        _integer(amount_to, name="amount-to")
        bounds = self.raise_bounds()
        if bounds is None or not bounds[0] <= amount_to <= bounds[1]:
            raise PokerError("amount-to is outside the legal raise bounds")

        stacks = list(self.stacks)
        bets = list(self.bets)
        acted_at = list(self.acted_at)
        delta = amount_to - bets[actor]
        stacks[actor] -= delta
        bets[actor] = amount_to
        acted_at[actor] = amount_to
        increment = amount_to - prior_wager
        full_increment = self.full_increment
        if increment >= full_increment:
            full_increment = increment
        pending = tuple(
            seat
            for offset in range(1, len(stacks))
            if (seat := (actor + offset) % len(stacks)) != actor
            and self.active[seat]
            and stacks[seat]
        )
        state = replace(
            self,
            stacks=tuple(stacks),
            bets=tuple(bets),
            pending=pending,
            acted_at=tuple(acted_at),
            full_increment=full_increment,
        )
        return state._close_if_finished()

    def _close_if_finished(self) -> BettingRound:
        if sum(self.active) <= 1:
            return replace(self, pending=())
        live_with_chips = sum(
            bool(self.active[seat] and self.stacks[seat])
            for seat in range(len(self.stacks))
        )
        if len(self.pending) == 1 and live_with_chips == 1:
            sole = self.pending[0]
            if self.bets[sole] >= max(self.bets):
                return replace(self, pending=())
        return self
