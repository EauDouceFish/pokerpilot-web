"""Generative public-range poker game for on-policy chance resampling.

Every traversal samples a fresh compatible joint deal from a public
``BeliefState``.  There is no fixed empirical deal table to enumerate, and this
offline research game makes no GTO or production-quality claim.
"""

from __future__ import annotations

import random
from collections.abc import Hashable, Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from typing import Any

from pokerlab.belief import COMBOS, DECK, BeliefState, build_belief
from pokerlab.contracts import PokerError
from pokerlab.game import PokerHand
from pokerlab.native_ranker import attach_native_ranker
from pokerlab.poker_game import (
    _FORBIDDEN_SPEC_KEYS,
    _SPEC_KEYS,
    _public_snapshot,
    FinitePokerGame,
    PokerState,
)

_COMBO_INDEX = {frozenset(combo): index for index, combo in enumerate(COMBOS)}


@dataclass(frozen=True, slots=True)
class DealSample:
    """One immutable, hashable joint private deal and complete board."""

    holes: tuple[tuple[str, str], ...]
    board: tuple[str, ...]


class ResampledPokerGame(FinitePokerGame):
    """Poker game whose root chance action is freshly sampled on policy."""

    chance_mode = "sampled_on_policy"

    def __init__(
        self,
        spec: dict[str, Any],
        actions: list[dict[str, Any]],
        public_board: list[str],
        *,
        ranges: Mapping[int, Mapping[str, float]] | None = None,
        raise_fractions: Sequence[float] = (0.5, 1.0),
        rank_backend: str = "pokerkit",
    ) -> None:
        if not isinstance(spec, dict):
            raise PokerError("spec 必须是对象")
        if _FORBIDDEN_SPEC_KEYS.intersection(spec):
            raise PokerError("spec 不得包含 seed、hole_cards 或 board_cards")
        if set(spec) - _SPEC_KEYS or "stacks" not in spec:
            raise PokerError("spec 包含未知字段或缺少 stacks")
        if not isinstance(actions, list):
            raise PokerError("actions 必须是列表")
        if not isinstance(public_board, list):
            raise PokerError("public_board 必须是数组")

        if type(rank_backend) is not str or rank_backend not in ("pokerkit", "native"):
            raise PokerError("rank_backend 必须是 pokerkit 或 native")
        placeholder = PokerHand(**spec, seed=0, board_cards=public_board)
        if rank_backend == "native":
            attach_native_ranker(placeholder)
        self._replay(placeholder, actions)
        if placeholder.is_terminal or placeholder.actor is None:
            raise PokerError("生成式根局面必须是非终局决策点")
        observation = placeholder.view(placeholder.actor)
        if observation["board"] != public_board:
            raise PokerError("public_board 必须正好等于动作重放后的当前公共牌")
        observation["hero_cards"] = []
        for player in observation["players"]:
            player["hole_cards"] = []
        belief = build_belief(observation, ranges)

        placeholder_deal = {
            "holes": deepcopy(placeholder.config["hole_cards"]),
            "board": list(placeholder.config["board_cards"]),
        }
        super().__init__(
            spec,
            actions,
            [placeholder_deal],
            raise_fractions=raise_fractions,
            rank_backend=rank_backend,
        )
        self._actions = deepcopy(actions)
        self._belief = belief
        self._public_board = tuple(public_board)
        self._root_public = _public_snapshot(placeholder)

    @property
    def belief(self) -> BeliefState:
        return self._belief

    @property
    def diagnostics(self) -> dict[str, Any]:
        return {
            "model": "resampled-public-range-game",
            "chance_mode": self.chance_mode,
            "fresh_joint_sampling": True,
            "fixed_deal_support": False,
            "finite_empirical_table_used": False,
            "placeholder_deal_participates_in_chance": False,
            "chance_samples": self._chance_samples,
            "quality_qualified": False,
            "gto_claimed": False,
            "rank_backend": self._rank_backend,
        }

    def sample_chance_on_policy(
        self, state: PokerState, rng: random.Random
    ) -> DealSample:
        if not isinstance(state, PokerState) or state.hand is not None:
            raise PokerError("只有生成式根节点可以采样 chance")
        if not isinstance(rng, random.Random):
            raise PokerError("rng 必须是 random.Random")
        holes = self._belief.sample_joint(rng)
        used = set((*self._belief.board, *self._belief.dead_cards))
        used.update(card for combo in holes.values() for card in combo)
        remaining = [card for card in DECK if card not in used]
        future = rng.sample(remaining, 5 - len(self._belief.board))
        return DealSample(
            tuple(holes[seat] for seat in range(self.num_players)),
            (*self._belief.board, *future),
        )

    def chance_outcomes(self, state: PokerState):
        raise PokerError("sampled_on_policy chance 不可枚举；请调用 sample_chance_on_policy")

    def next_state(self, state: PokerState, action: Hashable) -> PokerState:
        if not isinstance(state, PokerState):
            raise PokerError("state 必须是 PokerState")
        if state.hand is not None:
            return super().next_state(state, action)
        if not isinstance(action, DealSample):
            raise PokerError("生成式根节点只接受 DealSample")
        if (
            type(action.holes) is not tuple
            or len(action.holes) != self.num_players
            or any(
                type(combo) is not tuple
                or len(combo) != 2
                or any(type(card) is not str for card in combo)
                for combo in action.holes
            )
            or type(action.board) is not tuple
            or len(action.board) != 5
            or any(type(card) is not str for card in action.board)
        ):
            raise PokerError("DealSample 必须包含每人两张私牌和完整五张公共牌")
        if action.board[: len(self._public_board)] != self._public_board:
            raise PokerError("DealSample board 必须保留公开牌前缀")
        if set(self._belief.dead_cards).intersection((*action.board, *(c for pair in action.holes for c in pair))):
            raise PokerError("DealSample contains an explicitly dead card")
        hand = PokerHand(
            **self._spec,
            hole_cards=[list(combo) for combo in action.holes],
            board_cards=list(action.board),
        )
        if self._rank_backend == "native":
            attach_native_ranker(hand)
        for seat, cards in enumerate(hand.config["hole_cards"]):
            combo_index = _COMBO_INDEX[frozenset(cards)]
            if self._belief.weights[seat][combo_index] <= 0:
                raise PokerError(f"DealSample 座位 {seat} 私牌不在 belief 支持中")
        self._replay(hand, self._actions)
        if _public_snapshot(hand) != self._root_public:
            raise PokerError("采样 deal 重建后的公开根局面不一致")
        self._chance_samples += 1
        return PokerState(hand)
