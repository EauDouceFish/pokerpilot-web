"""Read-only public diagnostics, excluding private deals and RNG state."""
from copy import deepcopy

from .contracts import PokerError


def decision_diagnostics(record, model, policies, logged=None):
    holes = record["observation"]["players"][1]["hole_cards"]
    rows = []
    for before, after in zip(record["frames"], record["frames"][1:]):
        event = after["event"]
        if event["seat"] != 1:
            continue
        entry = {"step": after["index"], "actual_action": deepcopy(event),
                 "probabilities": None, "provenance": "unavailable"}
        if len(holes) != 2:
            entry["reason"] = "AI cards were not publicly revealed."
        elif logged and before['index'] in logged:
            saved = logged[before['index']]
            probabilities = saved.for_cards(holes)
            observation = before['observation']
            paid = int(observation['players'][1]['street_committed'])
            entry['probabilities'] = [
                {'kind': kind, 'amount_to': str(amount if kind in ('bet', 'raise') else
                    paid+int(observation['to_call']) if kind == 'call' else paid),
                 'probability': probability, 'ev_bb': None}
                for (kind, amount), probability in zip(saved.actions, probabilities, strict=True)]
            entry['provenance'] = 'logged_executed_policy_from_revealed_completed_hand'
            entry['source_id'] = saved.source_id
        elif model.get('backend') == 'numpy-browser-search-v1':
            entry['reason'] = 'Executed search policy was not recorded; no retrospective substitute.'
        elif model.get("adaptive"):
            entry["reason"] = "Historical adaptation state was not recorded."
        elif model != policies.identity(model.get("id")):
            entry["reason"] = "Bound model differs from the available model."
        else:
            observation = deepcopy(before["observation"])
            observation["viewer"] = 1
            observation["hero_cards"] = list(holes)
            observation["players"][0]["hole_cards"] = []
            observation["players"][1]["hole_cards"] = list(holes)
            entry["probabilities"] = policies.distribution(observation, model)
            entry["provenance"] = "recomputed_fixed_model_from_revealed_completed_hand"
        rows.append(entry)
    return rows


def export_diagnostics(challenges, policies, key, *, offset=None, limit=10):
    if type(limit) is not int or not 1 <= limit <= 50:
        raise PokerError("诊断每页必须为 1–50 手")
    if offset is not None and (type(offset) is not int or offset < 0):
        raise PokerError("诊断 offset 必须为非负整数")
    # Browser dispatch deserializes one immutable input snapshot for this GET.
    envelope = challenges.get(key)
    total = envelope["completed_hands"]
    start = max(0, total - limit) if offset is None else offset
    page = challenges.history(key, offset=start, limit=limit)
    records = [challenges.record(key, row["number"]) for row in page["items"]]
    for record in records:
        record["ai_decisions"] = decision_diagnostics(record, envelope["model"], policies,
            challenges.recorded_policies(key, record['number']))
    return {
        "schema": "pokerpilot-public-diagnostics-v1",
        "privacy": "Local browser only; public replay plus the human's own cards.",
        "units": {"observation_amounts": "integer chips encoded as strings",
                  "chips_per_bb": int(envelope["observation"]["rules"]["big_blind"]),
                  "fields_ending_in_bb": "big blinds", "probability": "0 to 1"},
        "challenge": envelope,
        "page": {"offset": start, "limit": limit, "total": total,
                 "next_offset": start + len(records) if start + len(records) < total else None},
        "records": records, "metrics": challenges.metrics(key), "curve": challenges.curve(key),
        "limitations": [
            "Current hidden AI cards, RNG seeds and the undealt deck are never exported.",
            "Recomputed probabilities are not logged decisions or proof of strategy quality.",
            "U49 has confirmed basic preflop errors and is not a teaching benchmark.",
            "No opponent adaptation is inferred from a fixed model's actions.",
        ],
    }
