"""Immutable CFR traversal samples and atomic uniform reservoir memory.

Reservoir retention uses ordinary Algorithm R.  Iteration numbers are sample
metadata only and do not change an event's probability of being retained.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, replace
from typing import Any


def _positive_integer(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"{name} must be a positive integer")
    return value


def _player(value: Any, name: str = "player") -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 8:
        raise ValueError(f"{name} must be an integer from 0 through 8")
    return value


def _immutable(value: Any, name: str) -> None:
    value_type = type(value)
    if value is None or value_type in (str, int, bool):
        return
    if value_type is float:
        if not math.isfinite(value):
            raise ValueError(f"{name} cannot contain non-finite floats")
        return
    if value_type is tuple:
        for index, item in enumerate(value):
            _immutable(item, f"{name}[{index}]")
        return
    raise ValueError(f"{name} must contain only immutable scalar values and tuples")


def _key(value: Any) -> Any:
    _immutable(value, "key")
    try:
        hash(value)
    except TypeError as exc:  # Defensive if the recursive whitelist changes.
        raise ValueError("key must be hashable") from exc
    return value


def _actions(value: Any) -> tuple[Any, ...]:
    if type(value) is not tuple or not value:
        raise ValueError("actions must be a non-empty tuple")
    _immutable(value, "actions")
    try:
        unique = len(set(value)) == len(value)
    except TypeError as exc:  # Defensive if the recursive whitelist changes.
        raise ValueError("actions must be hashable") from exc
    if not unique:
        raise ValueError("actions must be unique")
    return value


def _numbers(value: Any, size: int, name: str, *, nonnegative: bool = False) -> tuple[float, ...]:
    if type(value) is not tuple or len(value) != size:
        raise ValueError(f"{name} must be a tuple matching actions")
    output = []
    for item in value:
        if isinstance(item, bool) or not isinstance(item, (int, float)):
            raise ValueError(f"{name} must contain finite numbers")
        try:
            converted = float(item)
        except (OverflowError, ValueError) as exc:
            raise ValueError(f"{name} must contain finite numbers") from exc
        if not math.isfinite(converted) or nonnegative and converted < 0.0:
            raise ValueError(f"{name} must contain finite" + (" non-negative" if nonnegative else "") + " numbers")
        output.append(0.0 if converted == 0.0 else converted)
    return tuple(output)


def _number(value: Any, name: str, *, nonnegative: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a finite number")
    try:
        converted = float(value)
    except (OverflowError, ValueError) as exc:
        raise ValueError(f"{name} must be a finite number") from exc
    if not math.isfinite(converted) or nonnegative and converted < 0.0:
        raise ValueError(f"{name} must be finite" + (" and non-negative" if nonnegative else ""))
    return 0.0 if converted == 0.0 else converted


def _strategy(value: Any, size: int) -> tuple[float, ...]:
    probabilities = _numbers(value, size, "strategy", nonnegative=True)
    if not math.isclose(math.fsum(probabilities), 1.0, rel_tol=1e-9, abs_tol=1e-12):
        raise ValueError("strategy probabilities must sum to one")
    return probabilities


@dataclass(frozen=True, slots=True)
class AdvantageSample:
    iteration: int
    traversal_id: int
    player: int
    key: Any
    actions: tuple[Any, ...]
    strategy: tuple[float, ...]
    action_values: tuple[float, ...]
    node_value: float
    prefix_importance: float
    regrets: tuple[float, ...]
    retention_weight: float = 1.0

    def __post_init__(self) -> None:
        object.__setattr__(self, "iteration", _positive_integer(self.iteration, "iteration"))
        object.__setattr__(self, "traversal_id", _positive_integer(self.traversal_id, "traversal_id"))
        object.__setattr__(self, "player", _player(self.player))
        object.__setattr__(self, "key", _key(self.key))
        actions = _actions(self.actions)
        object.__setattr__(self, "actions", actions)
        size = len(actions)
        object.__setattr__(self, "strategy", _strategy(self.strategy, size))
        object.__setattr__(self, "action_values", _numbers(self.action_values, size, "action_values"))
        object.__setattr__(self, "node_value", _number(self.node_value, "node_value"))
        object.__setattr__(
            self, "prefix_importance", _number(self.prefix_importance, "prefix_importance", nonnegative=True)
        )
        object.__setattr__(self, "regrets", _numbers(self.regrets, size, "regrets"))
        weight = _number(self.retention_weight, "retention_weight")
        if weight <= 0:
            raise ValueError("retention_weight must be positive")
        object.__setattr__(self, "retention_weight", weight)


@dataclass(frozen=True, slots=True)
class StrategySample:
    iteration: int
    traversal_id: int
    player: int
    key: Any
    actions: tuple[Any, ...]
    strategy: tuple[float, ...]
    weight: float
    retention_weight: float = 1.0

    def __post_init__(self) -> None:
        object.__setattr__(self, "iteration", _positive_integer(self.iteration, "iteration"))
        object.__setattr__(self, "traversal_id", _positive_integer(self.traversal_id, "traversal_id"))
        object.__setattr__(self, "player", _player(self.player))
        object.__setattr__(self, "key", _key(self.key))
        actions = _actions(self.actions)
        object.__setattr__(self, "actions", actions)
        object.__setattr__(self, "strategy", _strategy(self.strategy, len(actions)))
        object.__setattr__(self, "weight", _number(self.weight, "weight", nonnegative=True))
        retention = _number(self.retention_weight, "retention_weight")
        if retention <= 0:
            raise ValueError("retention_weight must be positive")
        object.__setattr__(self, "retention_weight", retention)


@dataclass(frozen=True, slots=True)
class TraversalBatch:
    iteration: int
    traversal_id: int
    traverser: int
    advantages: tuple[AdvantageSample, ...]
    strategies: tuple[StrategySample, ...]

    def __post_init__(self) -> None:
        iteration = _positive_integer(self.iteration, "iteration")
        traversal_id = _positive_integer(self.traversal_id, "traversal_id")
        traverser = _player(self.traverser, "traverser")
        if type(self.advantages) is not tuple or not all(
            isinstance(sample, AdvantageSample) for sample in self.advantages
        ):
            raise ValueError("advantages must be a tuple of AdvantageSample")
        if type(self.strategies) is not tuple or not all(
            isinstance(sample, StrategySample) for sample in self.strategies
        ):
            raise ValueError("strategies must be a tuple of StrategySample")
        for sample in (*self.advantages, *self.strategies):
            if sample.iteration != iteration or sample.traversal_id != traversal_id:
                raise ValueError("all samples must belong to the batch iteration and traversal")
        if any(sample.player != traverser for sample in self.advantages):
            raise ValueError("advantage samples must belong to the traverser")
        if any(sample.player == traverser for sample in self.strategies):
            raise ValueError("strategy samples must belong to non-traversers")
        object.__setattr__(self, "iteration", iteration)
        object.__setattr__(self, "traversal_id", traversal_id)
        object.__setattr__(self, "traverser", traverser)


class Reservoir:
    """Fixed-capacity event-uniform Algorithm R reservoir with atomic batches."""

    __slots__ = ("_capacity", "_rng", "_items", "_seen")

    def __init__(self, capacity: int, seed: int) -> None:
        self._capacity = _positive_integer(capacity, "capacity")
        if isinstance(seed, bool) or not isinstance(seed, int):
            raise ValueError("seed must be an integer")
        self._rng = random.Random(seed)
        self._items: tuple[Any, ...] = ()
        self._seen = 0

    @property
    def capacity(self) -> int:
        return self._capacity

    @property
    def items(self) -> tuple[Any, ...]:
        return self._items

    @property
    def seen(self) -> int:
        return self._seen

    def _prepare(self, values: tuple[Any, ...]) -> tuple[tuple[Any, ...], int, object]:
        if type(values) is not tuple:
            raise ValueError("reservoir additions must be a tuple")
        items = list(self._items)
        seen = self._seen
        rng = random.Random()
        rng.setstate(self._rng.getstate())
        for value in values:
            seen += 1
            if len(items) < self._capacity:
                items.append(value)
            else:
                replacement = rng.randrange(seen)
                if replacement < self._capacity:
                    items[replacement] = value
        return tuple(items), seen, rng.getstate()

    def _commit(self, prepared: tuple[tuple[Any, ...], int, object]) -> None:
        self._items, self._seen, rng_state = prepared
        self._rng.setstate(rng_state)

    def add_many(self, values: tuple[Any, ...]) -> None:
        prepared = self._prepare(values)
        self._commit(prepared)


class SampleMemory:
    """Per-player advantage reservoirs plus one atomic strategy reservoir."""

    __slots__ = ("_num_players", "_advantages", "_strategy")

    def __init__(self, num_players: int, capacity: int, seed: int, *, stratified: bool = False) -> None:
        if isinstance(num_players, bool) or not isinstance(num_players, int) or not 2 <= num_players <= 9:
            raise ValueError("num_players must be an integer from 2 through 9")
        _positive_integer(capacity, "capacity")
        if isinstance(seed, bool) or not isinstance(seed, int):
            raise ValueError("seed must be an integer")
        if type(stratified) is not bool:
            raise ValueError("stratified must be bool")
        reservoir_type = Reservoir
        if stratified:
            from .stratified_memory import StratifiedReservoir
            reservoir_type = StratifiedReservoir
        seed_rng = random.Random(seed)
        self._num_players = num_players
        self._advantages = tuple(
            reservoir_type(capacity, seed_rng.getrandbits(128)) for _ in range(num_players)
        )
        self._strategy = reservoir_type(capacity, seed_rng.getrandbits(128))

    @property
    def num_players(self) -> int:
        return self._num_players

    @property
    def advantages(self) -> tuple[Reservoir, ...]:
        return self._advantages

    @property
    def strategy(self) -> Reservoir:
        return self._strategy

    def commit(self, batch: TraversalBatch) -> None:
        if not isinstance(batch, TraversalBatch):
            raise ValueError("batch must be TraversalBatch")
        if batch.traverser >= self._num_players or any(
            sample.player >= self._num_players for sample in batch.strategies
        ):
            raise ValueError("batch contains a player outside this memory")
        advantage_groups = [tuple(sample for sample in batch.advantages if sample.player == player)
                            for player in range(self._num_players)]
        prepared_advantages = tuple(
            reservoir._prepare(advantage_groups[player])
            for player, reservoir in enumerate(self._advantages)
        )
        prepared_strategy = self._strategy._prepare(batch.strategies)
        for reservoir, prepared in zip(self._advantages, prepared_advantages, strict=True):
            reservoir._commit(prepared)
        self._strategy._commit(prepared_strategy)


class RootScopedSink:
    """Give independent root trainers disjoint, reproducible traversal IDs."""

    def __init__(self, memory: SampleMemory, root: int, root_count: int):
        _positive_integer(root_count, "root_count")
        if type(root) is not int or not 0 <= root < root_count:
            raise ValueError("root must identify one of root_count roots")
        self.memory, self.root, self.root_count = memory, root, root_count

    def commit(self, batch: TraversalBatch) -> None:
        identity = (batch.traversal_id - 1) * self.root_count + self.root + 1
        self.memory.commit(replace(
            batch, traversal_id=identity,
            advantages=tuple(replace(s, traversal_id=identity) for s in batch.advantages),
            strategies=tuple(replace(s, traversal_id=identity) for s in batch.strategies),
        ))
