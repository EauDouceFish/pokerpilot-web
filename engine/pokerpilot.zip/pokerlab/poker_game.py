"""Finite-deal empirical no-limit hold'em game for offline MCCFR research."""

from __future__ import annotations

import math
from collections.abc import Hashable, Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any

from pokerlab.contracts import PokerError, chips
from pokerlab.game import PokerHand
from pokerlab.mccfr import CHANCE
from pokerlab.native_ranker import attach_native_ranker

PokerAction = tuple[str, int | None]

_SPEC_KEYS = {
    "stacks",
    "button",
    "small_blind",
    "big_blind",
    "ante_mode",
    "ante",
    "bba_order",
    "rules_version",
}
_FORBIDDEN_SPEC_KEYS = {"seed", "hole_cards", "board_cards"}


@dataclass(frozen=True)
class PokerState:
    """A chance root has no hand; selected states wrap an independent hand."""

    hand: PokerHand | None = None
    _view_version: int = field(default=-1, init=False, repr=False, compare=False)
    _view: dict[str, Any] | None = field(default=None, init=False, repr=False, compare=False)


def _freeze(value: Any) -> Hashable:
    if isinstance(value, Mapping):
        return tuple((key, _freeze(item)) for key, item in sorted(value.items()))
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(item) for item in value)
    return value


def _public_snapshot(hand: PokerHand) -> Hashable:
    if hand.actor is None:
        raise PokerError("有限发牌根局面必须仍有玩家待行动")
    observation = hand.view(hand.actor)
    public = deepcopy(observation)
    public.pop("hero_cards", None)
    for player in public["players"]:
        player["hole_cards"] = []
    return _freeze(public)


class FinitePokerGame:
    """A real-rules NLHE tree with chance restricted to explicit full deals.

    The chance distribution is an empirical finite abstraction. Future board
    cards stay absent from information keys, but only supplied deals can occur.
    """

    def __init__(
        self,
        spec: dict[str, Any],
        actions: list[dict[str, Any]],
        deals: list[dict[str, Any]],
        probabilities: list[float] | None = None,
        raise_fractions: Sequence[float] = (0.5, 1.0),
        rank_backend: str = "pokerkit",
    ) -> None:
        if not isinstance(spec, dict):
            raise PokerError("spec 必须是对象")
        forbidden = _FORBIDDEN_SPEC_KEYS.intersection(spec)
        if forbidden:
            raise PokerError("spec 不得包含 seed、hole_cards 或 board_cards")
        unknown = set(spec) - _SPEC_KEYS
        if unknown or "stacks" not in spec:
            raise PokerError("spec 包含未知字段或缺少 stacks")
        if not isinstance(actions, list):
            raise PokerError("actions 必须是列表")
        if not isinstance(deals, list) or not deals:
            raise PokerError("deals 必须是非空列表")
        self._spec = deepcopy(spec)
        stacks = spec["stacks"]
        if not isinstance(stacks, list) or not 2 <= len(stacks) <= 9:
            raise PokerError("玩家人数必须为 2 到 9")
        self.num_players = len(stacks)
        if type(rank_backend) is not str or rank_backend not in ("pokerkit", "native"):
            raise PokerError("rank_backend 必须是 pokerkit 或 native")
        self._rank_backend = rank_backend
        self._raise_fractions = self._validate_fractions(raise_fractions)
        self._probabilities = self._validate_probabilities(probabilities, len(deals))
        self._chance_samples = 0

        roots: list[PokerHand] = []
        root_public: Hashable | None = None
        for deal in deals:
            holes, board = self._validate_deal(deal)
            hand = PokerHand(**self._spec, hole_cards=holes, board_cards=board)
            if self._rank_backend == "native":
                attach_native_ranker(hand)
            self._replay(hand, actions)
            if hand.is_terminal:
                raise PokerError("actions 重放后必须保留一个非终局决策点")
            public = _public_snapshot(hand)
            if root_public is None:
                root_public = public
            elif public != root_public:
                raise PokerError("所有 deal 重放后的公开根局面必须一致")
            roots.append(hand)
        self._roots = tuple(roots)

    @staticmethod
    def _validate_fractions(values: Sequence[float]) -> tuple[float, ...]:
        if isinstance(values, (str, bytes)):
            raise PokerError("raise_fractions 必须是数值序列")
        try:
            fractions = tuple(values)
        except TypeError as exc:
            raise PokerError("raise_fractions 必须是数值序列") from exc
        if not fractions:
            raise PokerError("raise_fractions 不能为空")
        checked = []
        for value in fractions:
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(value)
                or value <= 0
            ):
                raise PokerError("raise_fractions 必须是有限正数")
            checked.append(float(value))
        return tuple(checked)

    @staticmethod
    def _validate_probabilities(values: list[float] | None, count: int) -> tuple[float, ...]:
        if values is None:
            return tuple(1.0 / count for _ in range(count))
        if not isinstance(values, list) or len(values) != count:
            raise PokerError("probabilities 数量必须与 deals 一致")
        checked = []
        for value in values:
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(value)
                or value <= 0
            ):
                raise PokerError("发牌概率必须是有限正数")
            checked.append(float(value))
        if not math.isclose(sum(checked), 1.0, rel_tol=1e-9, abs_tol=1e-12):
            raise PokerError("发牌概率之和必须为 1")
        return tuple(checked)

    def _validate_deal(self, deal: dict[str, Any]) -> tuple[list[list[str]], list[str]]:
        if not isinstance(deal, dict) or set(deal) != {"holes", "board"}:
            raise PokerError("每个 deal 必须且只能包含 holes 和 board")
        holes, board = deal["holes"], deal["board"]
        if not isinstance(holes, list) or len(holes) != self.num_players:
            raise PokerError("deal.holes 必须覆盖全部玩家")
        if any(not isinstance(cards, list) or len(cards) != 2 for cards in holes):
            raise PokerError("每位玩家必须恰好有两张底牌")
        if not isinstance(board, list) or len(board) != 5:
            raise PokerError("deal.board 必须恰好有五张牌")
        # PokerHand performs canonical card-format and cross-card uniqueness checks.
        return deepcopy(holes), list(board)

    @staticmethod
    def _replay(hand: PokerHand, actions: list[dict[str, Any]]) -> None:
        for event in actions:
            if not isinstance(event, dict) or not {"seat", "kind"}.issubset(event):
                raise PokerError("重放动作必须包含 seat 和 kind")
            if set(event) - {"seat", "kind", "amount_to"}:
                raise PokerError("重放动作包含未知字段")
            hand.act(event["seat"], event["kind"], event.get("amount_to"))

    @property
    def diagnostics(self) -> dict[str, Any]:
        return {
            "model": "finite-deal-empirical-game",
            "deal_count": len(self._roots),
            "empirical_sample_count": len(self._roots),
            "chance_samples": self._chance_samples,
            "future_board_hidden_from_information_key": True,
            "full_distribution_claimed": False,
            "rank_backend": self._rank_backend,
        }

    def initial_state(self) -> PokerState:
        return PokerState()

    def is_terminal(self, state: PokerState) -> bool:
        return state.hand is not None and state.hand.is_terminal

    def current_player(self, state: PokerState) -> int:
        if state.hand is None:
            return CHANCE
        if state.hand.is_terminal or state.hand.actor is None:
            raise PokerError("终局没有当前行动玩家")
        return state.hand.actor

    def chance_outcomes(self, state: PokerState) -> tuple[tuple[int, float], ...]:
        if state.hand is not None:
            raise PokerError("只有根节点是 chance 节点")
        return tuple(enumerate(self._probabilities))

    def legal_actions(self, state: PokerState) -> tuple[PokerAction, ...]:
        hand = self._decision_hand(state)
        observation = self._decision_view(state)
        actor = hand.actor
        assert actor is not None
        street_paid = chips(observation["players"][actor]["street_committed"])
        pot = chips(observation["pot"])
        to_call = chips(observation["to_call"])
        result: list[PokerAction] = []
        seen: set[PokerAction] = set()
        for legal in observation["legal_actions"]:
            kind = legal["kind"]
            if kind not in ("bet", "raise"):
                candidate = (kind, None)
                if candidate not in seen:
                    seen.add(candidate)
                    result.append(candidate)
                continue
            minimum = chips(legal["min_to"])
            maximum = chips(legal["max_to"])
            proposed = [minimum, maximum]
            proposed.extend(
                street_paid + to_call + round((pot + to_call) * fraction)
                for fraction in self._raise_fractions
            )
            for target in sorted({max(minimum, min(maximum, value)) for value in proposed}):
                candidate = (kind, target)
                if candidate not in seen:
                    seen.add(candidate)
                    result.append(candidate)
        if not result:
            raise PokerError("非终局决策点必须至少有一个合法动作")
        return tuple(result)

    def next_state(self, state: PokerState, action: Hashable) -> PokerState:
        if state.hand is None:
            if isinstance(action, bool) or not isinstance(action, int) or not 0 <= action < len(self._roots):
                raise PokerError("chance 发牌索引无效")
            self._chance_samples += 1
            return PokerState(self._roots[action].clone())
        if state.hand.is_terminal:
            raise PokerError("终局不能继续行动")
        if not isinstance(action, tuple) or len(action) != 2 or action not in self.legal_actions(state):
            raise PokerError("动作不在当前有限动作集合中")
        kind, amount_to = action
        assert state.hand.actor is not None
        return PokerState(state.hand.fork_action(state.hand.actor, kind, amount_to))

    def information_key(self, state: PokerState) -> Hashable:
        hand = self._decision_hand(state)
        actor = hand.actor
        assert actor is not None
        observation = self._decision_view(state)
        players = tuple(
            (
                player["seat"],
                player["stack"],
                player["starting_stack"],
                player["committed"],
                player["ante_paid"],
                player["street_committed"],
                player["status"],
            )
            for player in observation["players"]
        )
        history = tuple(
            (
                event["seat"],
                event["kind"],
                event.get("amount_to"),
                event.get("put_in"),
                event["street"],
                event["version"],
            )
            for event in observation["history"]
        )
        return (
            "finite-nlhe-v1",
            actor,
            observation["button"],
            observation["street"],
            tuple(sorted(observation["hero_cards"])),
            tuple(observation["board"]),
            players,
            _freeze(observation["rules"]),
            history,
        )

    def returns(self, state: PokerState) -> tuple[float, ...]:
        if state.hand is None or not state.hand.is_terminal or state.hand.result is None:
            raise PokerError("只有真实终局才能读取收益")
        net = tuple(int(value) for value in state.hand.result["net"])
        if sum(net) != 0:
            raise AssertionError("终局净收益必须为零和")
        big_blind = float(state.hand.big_blind)
        return tuple(value / big_blind for value in net)

    @staticmethod
    def _decision_view(state: PokerState) -> dict[str, Any]:
        # Traversal asks for actions, an information key and action validation
        # at the same node. Render once per hand version, confined to that
        # branch. This is not a solution/result cache across requests.
        hand = FinitePokerGame._decision_hand(state)
        if state._view is None or state._view_version != hand.version:
            object.__setattr__(state, "_view", hand.view(hand.actor))
            object.__setattr__(state, "_view_version", hand.version)
        assert state._view is not None
        return state._view

    @staticmethod
    def _decision_hand(state: PokerState) -> PokerHand:
        if state.hand is None:
            raise PokerError("chance 根节点没有玩家动作或信息集")
        if state.hand.is_terminal or state.hand.actor is None:
            raise PokerError("终局没有玩家动作或信息集")
        return state.hand
