"""Immutable public-information continuation policies for offline research."""

from __future__ import annotations

import hashlib
import json
import math
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any

from .compact_game import CompactPokerGame
from .contracts import PokerError
from .mccfr import MCCFRTrainer
from .resampled_game import ResampledPokerGame

FIXED_POLICY_RECORD_VERSION = "fixed-policy-public-teacher-v1"
FIXED_POLICY_SCOPE = "public-range-fixed-continuation-policy"
CONDITIONING_VERSION = "public-factorized-card-exclusion-own-combo-v1"

_SCHEMA = "fixed-policy-v1"
_INFORMATION_KEY_VERSION = "finite-nlhe-v1"
_FALLBACK = "uniform"
_ACTION_KINDS = ("fold", "check", "call", "bet", "raise")
_STREETS = ("preflop", "flop", "turn", "river")
_STATUSES = ("active", "folded", "all_in", "out")
_RULE_KEYS = ("ante", "ante_mode", "bba_order", "big_blind", "small_blind", "version")
_CARD_RANKS = frozenset("23456789TJQKA")
_CARD_SUITS = frozenset("cdhs")
_POLICY_ID = re.compile(r"fixed-policy-v1:[0-9a-f]{32}\Z")


def validate_policy_id(value: Any) -> str:
    if not isinstance(value, str) or _POLICY_ID.fullmatch(value) is None:
        raise PokerError("continuation_policy_id 必须是 fixed-policy-v1: 后接 32 位小写十六进制")
    return value


def _canonical_tuple(value: Any, name: str) -> Any:
    if isinstance(value, bool) or isinstance(value, float):
        raise PokerError(f"{name} 只能包含 none、str、int、tuple")
    if value is None or isinstance(value, (str, int)):
        return value
    if isinstance(value, (tuple, list)):
        return tuple(_canonical_tuple(item, name) for item in value)
    raise PokerError(f"{name} 只能包含 none、str、int、tuple")


def _card(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 2
        and value[0] in _CARD_RANKS
        and value[1] in _CARD_SUITS
    )


def _amount_text(value: Any) -> bool:
    return (
        isinstance(value, str)
        and bool(value)
        and value.isascii()
        and value.isdecimal()
        and (value == "0" or not value.startswith("0"))
    )


def _key(value: Any, *, expected_player: int | None = None) -> tuple:
    key = _canonical_tuple(value, "information key")
    if not isinstance(key, tuple) or len(key) != 9 or key[0] != _INFORMATION_KEY_VERSION:
        raise PokerError("information key 必须使用 finite-nlhe-v1 公开格式")
    player, button, street = key[1:4]
    if (
        isinstance(player, bool)
        or not isinstance(player, int)
        or not 0 <= player <= 8
        or expected_player is not None
        and player != expected_player
    ):
        raise PokerError("information key 行动座位无效或与 entry.player 不一致")
    if isinstance(button, bool) or not isinstance(button, int) or not 0 <= button <= 8:
        raise PokerError("information key button 无效")
    if street not in _STREETS:
        raise PokerError("information key street 无效")

    holes, board, players, rules, events = key[4:]
    expected_board = (0, 3, 4, 5)[_STREETS.index(street)]
    if (
        not isinstance(holes, tuple)
        or len(holes) != 2
        or not all(_card(card) for card in holes)
        or holes[0] == holes[1]
        or tuple(sorted(holes)) != holes
        or not isinstance(board, tuple)
        or len(board) != expected_board
        or not all(_card(card) for card in board)
        or len(set((*holes, *board))) != len(holes) + len(board)
    ):
        raise PokerError("information key 私牌或公共牌格式无效")

    if not isinstance(players, tuple) or not 2 <= len(players) <= 9:
        raise PokerError("information key players 数量必须为 2 到 9")
    if player >= len(players) or button >= len(players):
        raise PokerError("information key 座位超出桌面人数")
    for seat, item in enumerate(players):
        if (
            not isinstance(item, tuple)
            or len(item) != 7
            or item[0] != seat
            or not all(_amount_text(amount) for amount in item[1:6])
            or item[6] not in _STATUSES
        ):
            raise PokerError("information key players 格式无效")

    if (
        not isinstance(rules, tuple)
        or len(rules) != len(_RULE_KEYS)
        or any(not isinstance(item, tuple) or len(item) != 2 for item in rules)
        or tuple(item[0] for item in rules) != _RULE_KEYS
        or any(not isinstance(item[1], str) for item in rules)
        or dict(rules).get("version") != "chip-rules-v3"
    ):
        raise PokerError("information key rules 格式或版本无效")
    rule_values = dict(rules)
    if (
        not all(_amount_text(rule_values[name]) for name in ("ante", "big_blind", "small_blind"))
        or int(rule_values["small_blind"]) <= 0
        or int(rule_values["big_blind"]) <= 0
        or int(rule_values["small_blind"]) > int(rule_values["big_blind"])
        or rule_values["ante_mode"] not in ("none", "uniform", "big_blind")
        or (rule_values["ante_mode"] == "none") != (rule_values["ante"] == "0")
        or rule_values["bba_order"] not in ("ante_first", "blind_first")
    ):
        raise PokerError("information key rules 数值或枚举无效")

    if not isinstance(events, tuple):
        raise PokerError("information key events 必须是 tuple")
    previous_street = -1
    for index, event in enumerate(events):
        if (
            not isinstance(event, tuple)
            or len(event) != 6
            or isinstance(event[0], bool)
            or not isinstance(event[0], int)
            or not 0 <= event[0] < len(players)
            or event[1] not in _ACTION_KINDS
            or not _amount_text(event[2])
            or not _amount_text(event[3])
            or event[4] not in _STREETS
            or isinstance(event[5], bool)
            or not isinstance(event[5], int)
            or event[5] != index + 1
        ):
            raise PokerError("information key events 格式无效")
        street_index = _STREETS.index(event[4])
        if street_index < previous_street or street_index > _STREETS.index(street):
            raise PokerError("information key events 街道顺序无效")
        previous_street = street_index
    return key


def _actions(value: Any) -> tuple[tuple[str, int | None], ...]:
    normalized = _canonical_tuple(value, "actions")
    if not isinstance(normalized, tuple) or not normalized:
        raise PokerError("actions 必须是非空 tuple")
    result: list[tuple[str, int | None]] = []
    for action in normalized:
        if not isinstance(action, tuple) or len(action) != 2 or action[0] not in _ACTION_KINDS:
            raise PokerError("action 必须是合法 kind 与金额组成的二元 tuple")
        kind, amount = action
        if kind in ("fold", "check", "call"):
            if amount is not None:
                raise PokerError("fold/check/call 的 action 金额必须为 none")
        elif isinstance(amount, bool) or not isinstance(amount, int) or amount < 0:
            raise PokerError("bet/raise 的 action 金额必须是非负整数")
        result.append((kind, amount))
    actions = tuple(result)
    if len(set(actions)) != len(actions):
        raise PokerError("actions 不能重复")
    return actions


def _probabilities(value: Any, size: int) -> tuple[float, ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)) or len(value) != size:
        raise PokerError("probabilities 长度必须与 actions 一致")
    checked: list[float] = []
    for item in value:
        if (
            isinstance(item, bool)
            or not isinstance(item, (int, float))
            or not math.isfinite(item)
            or not 0.0 <= item <= 1.0
        ):
            raise PokerError("probabilities 必须是 0 到 1 的有限数")
        converted = float(item)
        checked.append(0.0 if converted == 0.0 else converted)
    if not math.isclose(math.fsum(checked), 1.0, rel_tol=1e-9, abs_tol=1e-12):
        raise PokerError("probabilities 总和必须为 1")
    return tuple(checked)


def _json_value(value: Any) -> Any:
    if isinstance(value, tuple):
        return [_json_value(item) for item in value]
    return value


@dataclass(frozen=True, slots=True)
class _Entry:
    player: int
    key: tuple
    actions: tuple[tuple[str, int | None], ...]
    probabilities: tuple[float, ...]

    def payload(self) -> dict[str, Any]:
        return {
            "player": self.player,
            "key": _json_value(self.key),
            "actions": _json_value(self.actions),
            "probabilities": list(self.probabilities),
        }


@dataclass(frozen=True, slots=True, init=False)
class FixedPolicy:
    """Content-addressed immutable policy with an explicit uniform fallback."""

    _rules_version: str
    _entries: tuple[_Entry, ...]
    _by_key: Mapping[tuple, _Entry]
    _policy_id: str

    def __init__(
        self,
        entries: Sequence[Mapping[str, Any]],
        *,
        rules_version: str = "chip-rules-v3",
    ) -> None:
        if rules_version != "chip-rules-v3":
            raise PokerError("FixedPolicy 仅支持 chip-rules-v3")
        if not isinstance(entries, Sequence) or isinstance(entries, (str, bytes)):
            raise PokerError("entries 必须是序列")
        checked: list[_Entry] = []
        seen: set[tuple] = set()
        for index, raw in enumerate(entries):
            if not isinstance(raw, Mapping) or set(raw) != {"player", "key", "actions", "probabilities"}:
                raise PokerError(f"entries[{index}] 必须精确包含 player、key、actions、probabilities")
            player = raw["player"]
            if isinstance(player, bool) or not isinstance(player, int) or not 0 <= player <= 8:
                raise PokerError(f"entries[{index}].player 必须为 0 到 8 的整数")
            key = _key(raw["key"], expected_player=player)
            actions = _actions(raw["actions"])
            probabilities = _probabilities(raw["probabilities"], len(actions))
            if key in seen:
                raise PokerError("同一 information key 不能重复")
            seen.add(key)
            checked.append(_Entry(player, key, actions, probabilities))

        checked.sort(
            key=lambda entry: json.dumps(
                entry.payload(), ensure_ascii=False, sort_keys=True, separators=(",", ":")
            )
        )
        object.__setattr__(self, "_rules_version", rules_version)
        object.__setattr__(self, "_entries", tuple(checked))
        object.__setattr__(self, "_by_key", MappingProxyType({entry.key: entry for entry in checked}))
        content = self._content_payload()
        encoded = json.dumps(
            content,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
        digest = hashlib.blake2b(encoded, digest_size=16).hexdigest()
        object.__setattr__(self, "_policy_id", f"fixed-policy-v1:{digest}")

    @property
    def policy_id(self) -> str:
        return self._policy_id

    @property
    def rules_version(self) -> str:
        return self._rules_version

    @property
    def metadata(self) -> dict[str, Any]:
        return {
            "schema": _SCHEMA,
            "rules_version": self._rules_version,
            "information_key_version": _INFORMATION_KEY_VERSION,
            "fallback": _FALLBACK,
            "policy_id": self._policy_id,
        }

    def _content_payload(self) -> dict[str, Any]:
        return {
            "schema": _SCHEMA,
            "rules_version": self._rules_version,
            "information_key_version": _INFORMATION_KEY_VERSION,
            "fallback": _FALLBACK,
            "entries": [entry.payload() for entry in self._entries],
        }

    def probabilities(self, player: int, key: Any, actions: Any) -> tuple[float, ...]:
        if isinstance(player, bool) or not isinstance(player, int) or not 0 <= player <= 8:
            raise PokerError("player 必须为 0 到 8 的整数")
        normalized_key = _key(key, expected_player=player)
        normalized_actions = _actions(actions)
        entry = self._by_key.get(normalized_key)
        if entry is None:
            return tuple(1.0 / len(normalized_actions) for _ in normalized_actions)
        if entry.player != player or entry.actions != normalized_actions:
            raise PokerError("已知 information key 的 player/actions 签名不匹配")
        return entry.probabilities

    def __call__(self, player: int, key: Any, actions: Any) -> Mapping[tuple[str, int | None], float]:
        normalized_actions = _actions(actions)
        probabilities = self.probabilities(player, key, normalized_actions)
        return dict(zip(normalized_actions, probabilities, strict=True))

    def has_entry(self, key: Any) -> bool:
        return _key(key) in self._by_key

    def to_payload(self) -> dict[str, Any]:
        return {**self._content_payload(), "policy_id": self._policy_id}

    def save(self, path: str | Path) -> None:
        try:
            Path(path).write_text(
                json.dumps(self.to_payload(), ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                encoding="utf-8",
                newline="\n",
            )
        except (OSError, TypeError, ValueError) as exc:
            raise PokerError("固定策略保存失败") from exc

    @classmethod
    def load(cls, path: str | Path) -> "FixedPolicy":
        try:
            payload = json.loads(Path(path).read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError, TypeError) as exc:
            raise PokerError("固定策略文件无法读取") from exc
        expected = {
            "schema", "rules_version", "information_key_version", "fallback", "entries", "policy_id"
        }
        if not isinstance(payload, dict) or set(payload) != expected:
            raise PokerError("固定策略 payload 字段无效")
        if (
            payload["schema"] != _SCHEMA
            or payload["information_key_version"] != _INFORMATION_KEY_VERSION
            or payload["fallback"] != _FALLBACK
        ):
            raise PokerError("固定策略 payload 版本或 fallback 无效")
        declared = validate_policy_id(payload["policy_id"])
        policy = cls(payload["entries"], rules_version=payload["rules_version"])
        if policy.policy_id != declared:
            raise PokerError("固定策略 policy_id 与内容不匹配")
        return policy

    @classmethod
    def from_trainer(cls, trainer: MCCFRTrainer) -> "FixedPolicy":
        """Snapshot a stopped trainer; its owner must serialize train/export.

        MCCFRTrainer is not a concurrent mutable service. The reentrancy guard
        detects an already running traversal, not a race with another thread.
        """
        if not isinstance(trainer, MCCFRTrainer):
            raise PokerError("trainer 必须是 MCCFRTrainer")
        if trainer._training:
            raise PokerError("训练进行中不能导出固定策略")
        game = trainer.game
        if isinstance(game, CompactPokerGame):
            if not isinstance(game.base, ResampledPokerGame):
                raise PokerError("CompactPokerGame 必须基于 ResampledPokerGame")
            rules_version = game._roots[0].rules["version"]
        elif isinstance(game, ResampledPokerGame):
            rules_version = game._spec.get("rules_version", "chip-rules-v3")
        else:
            raise PokerError("固定策略只能从 CompactPokerGame 或 ResampledPokerGame 导出")
        if rules_version != "chip-rules-v3":
            raise PokerError("固定策略只能从 chip-rules-v3 游戏导出")
        entries = []
        for key, node in trainer._nodes.items():
            if not trainer.has_average_policy(key):
                continue
            entries.append(
                {
                    "player": node.player,
                    "key": key,
                    "actions": node.actions,
                    "probabilities": tuple(trainer.average_policy(key, node.actions).values()),
                }
            )
        return cls(entries, rules_version=rules_version)


def require_continuation_policy(policy: Any) -> Any:
    """Accept only the two implemented fixed-policy providers.

    Neural dependencies stay optional for existing tabular-policy workflows.
    A neural provider defines unseen keys; this is not training coverage.
    """
    if not isinstance(policy, FixedPolicy):
        from .policy_training import FrozenNeuralPolicy
        if not isinstance(policy, FrozenNeuralPolicy):
            raise PokerError("policy 必须是 FixedPolicy 或 FrozenNeuralPolicy")
    validate_policy_id(policy.policy_id)
    if policy.rules_version != "chip-rules-v3":
        raise PokerError("continuation policy 必须使用 chip-rules-v3")
    return policy
