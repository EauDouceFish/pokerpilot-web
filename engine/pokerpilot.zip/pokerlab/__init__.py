"""Shared package for the independently tested Poker Lab modules."""

__version__ = "0.1.0"
