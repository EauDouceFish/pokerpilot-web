try:
    from numba import njit, prange
except ImportError:  # Pyodide has no numba; the same functions then run as plain Python
    prange = range

    def njit(*args, **kwargs):
        if len(args) == 1 and callable(args[0]) and not kwargs:
            return args[0]
        return lambda f: f
