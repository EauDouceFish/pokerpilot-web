"""Card encoding, 5-7 card evaluator and Monte Carlo equity (numba).

Card id = rank * 4 + suit, rank 0..12 = 2..A, suit 0..3.
Hand score: category << 20 | kickers (4 bits each), larger is better.
"""
from pathlib import Path

import numpy as np

from .jit import njit, prange

RANKS = "23456789TJQKA"
SUITS = "cdhs"


def card_str(c):
    return RANKS[c // 4] + SUITS[c % 4]


@njit(cache=True)
def _straight_high(mask):
    for h in range(12, 3, -1):
        w = 0x1F << (h - 4)
        if (mask & w) == w:
            return h
    if (mask & 0x100F) == 0x100F:
        return 3
    return -1


@njit(cache=True)
def evaluate(cards, n):
    rc = np.zeros(13, np.int64)
    sc = np.zeros(4, np.int64)
    sm = np.zeros(4, np.int64)
    rm = 0
    for i in range(n):
        c = cards[i]
        r = c >> 2
        s = c & 3
        rc[r] += 1
        sc[s] += 1
        sm[s] |= 1 << r
        rm |= 1 << r
    for s in range(4):
        if sc[s] >= 5:
            h = _straight_high(sm[s])
            if h >= 0:
                return (8 << 20) | (h << 16)
            v = 0
            k = 0
            for r in range(12, -1, -1):
                if (sm[s] >> r) & 1 and k < 5:
                    v = (v << 4) | r
                    k += 1
            return (5 << 20) | v
    quad = -1
    t1 = -1
    t2 = -1
    p1 = -1
    p2 = -1
    for r in range(12, -1, -1):
        c = rc[r]
        if c == 4:
            quad = r
        elif c == 3:
            if t1 < 0:
                t1 = r
            elif t2 < 0:
                t2 = r
        elif c == 2:
            if p1 < 0:
                p1 = r
            elif p2 < 0:
                p2 = r
    if quad >= 0:
        for r in range(12, -1, -1):
            if r != quad and rc[r] > 0:
                return (7 << 20) | (quad << 16) | (r << 12)
        return (7 << 20) | (quad << 16)
    if t1 >= 0 and (t2 >= 0 or p1 >= 0):
        p = t2 if t2 > p1 else p1
        return (6 << 20) | (t1 << 16) | (p << 12)
    h = _straight_high(rm)
    if h >= 0:
        return (4 << 20) | (h << 16)
    if t1 >= 0:
        v = t1
        k = 0
        for r in range(12, -1, -1):
            if r != t1 and rc[r] > 0 and k < 2:
                v = (v << 4) | r
                k += 1
        return (3 << 20) | (v << 8)
    if p1 >= 0 and p2 >= 0:
        for r in range(12, -1, -1):
            if r != p1 and r != p2 and rc[r] > 0:
                return (2 << 20) | (p1 << 16) | (p2 << 12) | (r << 8)
        return (2 << 20) | (p1 << 16) | (p2 << 12)
    if p1 >= 0:
        v = p1
        k = 0
        for r in range(12, -1, -1):
            if r != p1 and rc[r] > 0 and k < 3:
                v = (v << 4) | r
                k += 1
        return (1 << 20) | (v << 4)
    v = 0
    k = 0
    for r in range(12, -1, -1):
        if rc[r] > 0 and k < 5:
            v = (v << 4) | r
            k += 1
    return v


@njit(cache=True)
def equity_mc(h0, h1, board, nb, nopp, samples):
    """Hero equity (ties split) vs nopp uniformly random hands."""
    used = np.zeros(52, np.bool_)
    used[h0] = True
    used[h1] = True
    for i in range(nb):
        used[board[i]] = True
    rem = np.empty(52, np.int64)
    m = 0
    for c in range(52):
        if not used[c]:
            rem[m] = c
            m += 1
    hero = np.empty(7, np.int64)
    opp = np.empty(7, np.int64)
    hero[0] = h0
    hero[1] = h1
    for i in range(nb):
        hero[2 + i] = board[i]
        opp[2 + i] = board[i]
    need = 5 - nb + 2 * nopp
    total = 0.0
    for _ in range(samples):
        for i in range(need):
            j = i + np.random.randint(m - i)
            tmp = rem[i]
            rem[i] = rem[j]
            rem[j] = tmp
        for i in range(5 - nb):
            hero[2 + nb + i] = rem[i]
            opp[2 + nb + i] = rem[i]
        hs = evaluate(hero, 7)
        best = -1
        ties = 0
        pos = 5 - nb
        for o in range(nopp):
            opp[0] = rem[pos]
            opp[1] = rem[pos + 1]
            pos += 2
            s = evaluate(opp, 7)
            if s > best:
                best = s
                ties = 1 if s == hs else 0
            elif s == best and s == hs:
                ties += 1
        if hs > best:
            total += 1.0
        elif hs == best:
            total += 1.0 / (1 + ties)
    return total / samples


@njit(cache=True)
def preflop_class(h0, h1):
    """13x13 chart index: row/col by descending rank; suited above diagonal."""
    r0 = h0 >> 2
    r1 = h1 >> 2
    hi = r0 if r0 > r1 else r1
    lo = r1 if r0 > r1 else r0
    if hi == lo:
        return (12 - hi) * 13 + (12 - hi)
    if (h0 & 3) == (h1 & 3):
        return (12 - hi) * 13 + (12 - lo)
    return (12 - lo) * 13 + (12 - hi)


def class_cards(g):
    """Representative hole cards for chart index g."""
    row, col = divmod(g, 13)
    a, b = 12 - row, 12 - col
    if a == b:
        return a * 4, a * 4 + 1
    if row < col:
        return a * 4, b * 4
    return b * 4, a * 4 + 1


def class_label(g):
    row, col = divmod(g, 13)
    a, b = RANKS[12 - row], RANKS[12 - col]
    if row == col:
        return a + b
    return (a + b + "s") if row < col else (b + a + "o")


MAX_OPP = 8


@njit(cache=True, parallel=True)
def _preflop_table(reps, samples, max_opp):
    out = np.zeros((169, max_opp + 1))
    for task in prange(169 * max_opp):
        g = task // max_opp
        nopp = task % max_opp + 1
        board = np.zeros(5, np.int64)
        out[g, nopp] = equity_mc(reps[g, 0], reps[g, 1], board, 0, nopp, samples)
    return out


def preflop_equity_table(cache_dir, samples=6000):
    """eq[class, nopp] for nopp 1..MAX_OPP, cached on disk."""
    path = Path(cache_dir) / f"preflop_eq{MAX_OPP}_{samples}.npy"
    if path.is_file():
        return np.load(path)
    reps = np.array([class_cards(g) for g in range(169)], np.int64)
    table = _preflop_table(reps, samples, MAX_OPP)
    old = Path(cache_dir) / f"preflop_eq_{samples}.npy"
    if old.is_file():  # keep the values 2-6 seat checkpoints were trained on
        prev = np.load(old)
        table[:, :prev.shape[1]] = prev
    path.parent.mkdir(parents=True, exist_ok=True)
    np.save(path, table)
    return table
