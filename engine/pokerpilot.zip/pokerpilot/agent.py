"""Numpy-only inference for an exported PokerNet (runs in Pyodide: no torch, no numba).

`HeadsUpAgent(directory)(observation)` takes a PokerPilot-Explorer style actor view
(integer chips, cards like "Td", full public action history) and returns
[{"kind", "amount_to", "probability"}] over that engine's legal actions.
The training environment state is rebuilt by replaying the public history, so
the features are exactly the ones the network was trained on. Opponent
statistics are hidden (baseline mode).
"""
import json
import math
import zlib
from pathlib import Path

import numpy as np

from . import env as E
from .cards import RANKS, SUITS

_STREETS = ("preflop", "flop", "turn", "river")
_R_VALUE = (0.0, 0.0, 0.5, 1.0, 0.0)  # model.R_VALUE: showdown value of range-view code R + 1
_RANGE_FLOOR = 0.1     # share of a searched range spread uniformly (the range head can be overconfident)
_HERO_SAMPLES = 3      # opponent hands whose view of the hero's range is averaged
_MAX_ITERATIONS = 300  # CFR+ iterations unless the time budget runs out first
_erf = np.vectorize(math.erf, otypes=[np.float64])


def _gelu(x):
    return 0.5 * x * (1.0 + _erf(x / math.sqrt(2.0)))


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def card_id(text):
    return RANKS.index(text[0].upper()) * 4 + SUITS.index(text[1].lower())


class NumpyNet:
    """Single-example forward pass matching pokerpilot.model.PokerNet."""

    def __init__(self, weights):
        self.w = {k: np.asarray(v, np.float64) for k, v in weights.items()}
        self.blocks = len({k.split(".")[1] for k in self.w if k.startswith("blocks.")})

    def _lin(self, x, name):
        return x @ self.w[name + ".weight"].T + self.w[name + ".bias"]

    def _norm(self, x, name):
        m = x.mean(-1, keepdims=True)
        v = ((x - m) ** 2).mean(-1, keepdims=True)
        return (x - m) / np.sqrt(v + 1e-5) * self.w[name + ".weight"] + self.w[name + ".bias"]

    def _gru(self, H):
        w = self.w
        h = np.zeros(w["gru.weight_hh_l0"].shape[1])
        gi_all = H @ w["gru.weight_ih_l0"].T + w["gru.bias_ih_l0"]
        for gi in gi_all:
            gh = h @ w["gru.weight_hh_l0"].T + w["gru.bias_hh_l0"]
            ir, iz, i_n = np.split(gi, 3)
            hr, hz, hn = np.split(gh, 3)
            r = _sigmoid(ir + hr)
            z = _sigmoid(iz + hz)
            n = np.tanh(i_n + r * hn)
            h = (1.0 - z) * n + z * h
        return h

    def _block(self, x, i):
        b = f"blocks.{i}"
        return x + self._lin(_gelu(self._lin(self._norm(x, b + ".norm"), b + ".fc1")), b + ".fc2")

    def forward(self, G, C, S, H, R=None, with_range=False):
        """Policy logits and value; with_range adds the predicted combo logits of every other seat."""
        w = self.w
        dealt = C < 52
        rank = np.where(dealt, C // 4, 13)
        suit = np.where(dealt, C % 4, 4)
        cards = np.concatenate([w["rank.weight"][rank], w["suit.weight"][suit]], -1) + w["slot"]
        x_c = _gelu(self._lin(cards.reshape(-1), "card_fc"))
        S = S[..., :w["seat_fc.weight"].shape[1]]  # older exports read fewer seat features
        own = None
        if "own_fc.weight" in w:  # the actor's own statistics bypass the shared seat encoder
            own = np.concatenate([S[0, 8:13], S[0, 14:]])
            S = S.copy()
            S[0, 8:13] = 0.0
            S[0, 14:] = 0.0
        seat = _gelu(self._lin(S, "seat_fc"))
        x_s = _gelu(self._lin(seat.reshape(-1), "seats_fc"))
        x_g = _gelu(self._lin(G, "g_fc"))
        x = self._lin(np.concatenate([x_c, x_s, self._gru(H), x_g]), "inp")
        if own is not None:
            x = x + self._lin(own, "own_fc")
        for i in range(self.blocks - 1):
            x = self._block(x, i)
        range_logits = None
        if R is not None and "range_fc.weight" in w:
            R = np.asarray(R, np.int64)
            opp = seat[1:]
            hid = _gelu(self._lin(np.concatenate([np.broadcast_to(x, (len(opp), len(x))), opp], -1), "range_fc"))
            range_logits = np.where(R < 0, -1e9, self._lin(hid, "range_out"))
            belief = np.exp(range_logits - range_logits.max(-1, keepdims=True))
            belief /= belief.sum(-1, keepdims=True)
            eq = belief @ np.array(_R_VALUE)[R + 1]
            win = _sigmoid(self._lin(hid, "win_out")[:, 0])
            live = (S[1:, 0] > 0) & (S[1:, 1] == 0)
            if live.any() and not (R == E.R_UNKNOWN).any():
                feat = []
                for p in (eq, win):
                    p_live = np.where(live, p, 1.0)
                    feat += [p_live.prod(), p_live.min(), (p * live).sum() / live.sum()]
                feat.insert(3, 1.0)
                x = x + self._lin(np.array(feat), "range_feat")
        x = self._block(x, self.blocks - 1)
        x = _gelu(self._norm(x, "norm"))
        logits, value = self._lin(x, "pi"), float(self._lin(x, "v")[0])
        if with_range:
            return logits, value, range_logits
        return logits, value


class HeadsUpAgent:
    def __init__(self, directory):
        folder = Path(directory)
        self.manifest = json.loads((folder / "model.json").read_text(encoding="utf-8"))
        with np.load(folder / "weights.npz", allow_pickle=False) as archive:
            self.net = NumpyNet({k: archive[k] for k in archive.files})
        self.preflop_eq = np.load(folder / "preflop_eq.npy", allow_pickle=False)
        self.eq_samples = int(self.manifest["eq_samples"])
        self.baseline = None  # blueprint action rates for the opponent model in search
        if (folder / "baseline.json").exists():
            from .opponent import load_baseline
            self.baseline = load_baseline(folder / "baseline.json")
        self.value_net = None  # turn value network: the depth limit of flop searches
        if (folder / "value.npz").exists():
            from .value_np import ValueNet
            with np.load(folder / "value.npz", allow_pickle=False) as archive:
                self.value_net = ValueNet({k: archive[k] for k in archive.files})
        streets = self.manifest.get("search_streets", ["river"]) if self.manifest.get("search_seconds") else []
        self.search_streets = {s for s in streets if s != "flop" or self.value_net is not None}
        self._sessions = {}

    # ---------------------------------------------------------------- state
    @staticmethod
    def _deal(n, button, stacks, bb, sb_amount, known, board, counters=None):
        """Fresh single-table state. known: seat -> two card ids; other seats get spare cards.
        counters: per-seat session statistics carried into this hand (then visible to the net)."""
        fs = np.zeros((1, E.MAXP, E.NFS))
        is_ = np.zeros((1, E.MAXP, E.NIS), np.int64)
        tf = np.zeros((1, E.NTF))
        ti = np.zeros((1, E.NTI), np.int64)
        hist = np.zeros((1, E.HLEN, E.FH), np.float32)
        used = set(board) | {c for cards in known.values() for c in cards}
        spare = [c for c in range(52) if c not in used]
        ti[0, E.T_NP] = n
        ti[0, E.T_BTN] = button
        ti[0, E.T_LAGG] = -1
        for i in range(5):
            ti[0, E.T_B0 + i] = board[i] if i < len(board) else spare.pop()
        for p in range(E.MAXP):
            if p >= n:
                is_[0, p, E.I_FOLD] = 1
                is_[0, p, E.I_AGENT] = -99
                continue
            cards = known[p] if p in known else (spare.pop(), spare.pop())
            is_[0, p, E.I_H0], is_[0, p, E.I_H1] = cards
            fs[0, p, E.F_STACK] = fs[0, p, E.F_START] = stacks[p] / bb
            is_[0, p, E.I_NEED] = 1
            is_[0, p, E.I_CANR] = 1
            if counters is not None:
                fs[0, p, E.F_HANDS:E.F_BOT] = counters[p]
                ti[0, E.T_VIS] = 1
            E.roll_recent(0, p, fs)
            fs[0, p, E.F_HANDS] += 1.0
        sb, bbs = (button, (button + 1) % 2) if n == 2 else ((button + 1) % n, (button + 2) % n)
        E._post(0, sb, sb_amount, fs, is_)
        E._post(0, bbs, 1.0, fs, is_)
        tf[0, E.T_MAXBET] = 1.0
        tf[0, E.T_LASTR] = 1.0
        ti[0, E.T_ACTOR] = E._find_next(0, bbs, fs, is_, ti)
        return fs, is_, tf, ti, hist

    @staticmethod
    def _replay(state, events, bb, complete=False):
        """Apply public events; returns True if the hand ended (only allowed when complete)."""
        fs, is_, tf, ti, hist = state
        for i, event in enumerate(events):
            a = ti[0, E.T_ACTOR]
            if event["seat"] != a:
                raise ValueError("history does not match the rebuilt action order")
            kind, raise_to = event["kind"], 0.0
            if kind == "fold":
                k = 0
            elif kind in ("check", "call"):
                k = 2 if tf[0, E.T_MAXBET] - fs[0, a, E.F_SBET] > 1e-9 else 1
            else:
                raise_to = int(event["amount_to"]) / bb
                allin_to = fs[0, a, E.F_SBET] + fs[0, a, E.F_STACK]
                k = 4 if raise_to >= allin_to - 1e-9 else 3
            E._apply_kind(0, k, raise_to, fs, is_, tf, ti, hist)
            if E._advance(0, fs, is_, tf, ti):
                if not complete or i != len(events) - 1:
                    raise ValueError("history ends the hand before the current decision")
                return True
        return False

    def _rebuild(self, obs, session=None):
        players = obs["players"]
        n = len(players)
        if not 2 <= n <= E.MAXP:
            raise ValueError(f"PokerPilot model supports 2-{E.MAXP} players")
        if obs["rules"].get("ante_mode", "none") != "none":
            raise ValueError("PokerPilot model was trained without antes")
        bb = int(obs["rules"]["big_blind"])
        stacks = [int(p["starting_stack"]) for p in players]
        hole = tuple(card_id(c) for c in obs["hero_cards"])
        board = [card_id(c) for c in obs["board"]]
        state = self._deal(n, obs["button"], stacks, bb, int(obs["rules"]["small_blind"]) / bb,
                           {obs["viewer"]: hole}, board, session)
        self._replay(state, obs["history"], bb)
        fs, is_, tf, ti, hist = state
        if ti[0, E.T_ACTOR] != obs["actor"] or _STREETS[ti[0, E.T_STREET]] != obs["street"]:
            raise ValueError("rebuilt state disagrees with the observation")
        return fs, is_, tf, ti, hist, bb

    # ---------------------------------------------------------------- opponent statistics
    def session_stats(self, key, load_hands, players=2):
        """Per-seat statistics over the completed hands of one session, cached incrementally.
        load_hands(start) returns completed hands after the first `start`, each a dict with
        button, stacks (chips), big_blind, small_blind, events, board and shown
        (seat -> card strings revealed at showdown)."""
        count, counters = self._sessions.get(key, (0, None))
        if counters is None:
            counters = np.zeros((players, E.F_BOT - E.F_HANDS))
        for hand in load_hands(count):
            self._accumulate(hand, counters)
            count += 1
        self._sessions[key] = (count, counters)
        return counters.copy()

    def _accumulate(self, hand, counters):
        n = len(hand["stacks"])
        bb = int(hand["big_blind"])
        shown = {int(p): tuple(card_id(c) for c in cards)
                 for p, cards in hand.get("shown", {}).items() if len(cards) == 2}
        board = [card_id(c) for c in hand["board"]]
        state = self._deal(n, hand["button"], hand["stacks"], bb, int(hand["small_blind"]) / bb,
                           shown, board, counters)
        fs, is_, tf, ti, hist = state
        self._replay(state, hand["events"], bb, complete=True)
        for p in range(n):
            fs[0, p, E.F_VPIP] += is_[0, p, E.I_HVPIP]
            fs[0, p, E.F_PFR] += is_[0, p, E.I_HPFR]
            if p not in shown:
                is_[0, p, E.I_RAGG] = is_[0, p, E.I_RCALL] = 0
        if len(board) == 5:
            E._count_showdown(0, fs, is_, ti)
        won = np.zeros(E.MAXP)
        if "net" in hand:
            won[:n] = np.asarray(hand["net"], np.float64)
        elif all(p in shown or is_[0, p, E.I_FOLD] for p in range(n)):
            E._settle(0, fs, is_, ti, np.zeros((1, 52), np.int64), won)
        E.count_results(0, fs, is_, ti, won)
        counters[:] = fs[0, :n, E.F_HANDS:E.F_BOT]

    # ---------------------------------------------------------------- policy
    def _forward(self, state, seed_key):
        """Network outputs at the current decision of a rebuilt state: logits, value, legal mask,
        predicted combo logits of the other seats."""
        fs, is_, tf, ti, hist = state
        G = np.zeros((1, E.NG), np.float32)
        C = np.zeros((1, 7), np.int64)
        S = np.zeros((1, E.MAXP, E.NS), np.float32)
        M = np.zeros((1, E.NA), np.bool_)
        R = np.zeros((1, E.NCOMBO), np.int8)
        np.random.seed(zlib.crc32(json.dumps(seed_key).encode()))  # deterministic MC equity
        E.build_obs(fs, is_, tf, ti, hist, np.zeros((1, 52), np.int64), self.preflop_eq,
                    self.eq_samples, G, C, S, M, np.zeros(1), np.zeros(1, np.int64), np.zeros(1, np.int64),
                    R, np.zeros((1, E.MAXP), np.int16))
        logits, value, ranges = self.net.forward(G[0].astype(np.float64), C[0], S[0].astype(np.float64),
                                                 hist[0].astype(np.float64), R[0], with_range=True)
        return logits, value, M[0], ranges

    def evaluate(self, obs, session=None):
        """Returns (distribution over the engine's legal actions, value in units of E).
        session: per-seat statistics from session_stats; None keeps opponents unknown. Exports
        with a search budget re-solve heads-up decisions on the manifest's search_streets."""
        hidden = self.manifest.get("hide_stats", False)  # blueprint trained without opponent stats
        fs, is_, tf, ti, hist, bb = self._rebuild(obs, None if hidden else session)
        key = [obs["hero_cards"], obs["board"], len(obs["history"])]
        logits, value, mask, _ = self._forward((fs, is_, tf, ti, hist), key)
        if len(obs["players"]) == 2 and obs["street"] in self.search_streets:
            return self.search(obs, session), value
        targets = self._targets(obs, fs, tf, ti, mask, bb)
        if not targets:
            raise ValueError("no legal action maps onto the model menu")
        idx = np.array(sorted(targets))
        z = logits[idx] - logits[idx].max()
        p = np.exp(z) / np.exp(z).sum()
        merged = {}
        for i, prob in zip(idx, p):
            merged[targets[i]] = merged.get(targets[i], 0.0) + float(prob)
        return self._distribution(merged), value

    @staticmethod
    def _distribution(merged):
        total = math.fsum(merged.values())
        out = [{"kind": k, "amount_to": str(amt), "probability": v / total}
               for (k, amt), v in merged.items()]
        top = max(range(len(out)), key=lambda j: out[j]["probability"])
        out[top]["probability"] += 1.0 - math.fsum(o["probability"] for o in out)
        return out

    def __call__(self, obs):
        return self.evaluate(obs)[0]

    # ---------------------------------------------------------------- search
    def _canonical(self, obs, viewer, hole, upto):
        """Heads-up state with the button as seat 0 after the first `upto` events, `hole` dealt to
        `viewer` (table seat)."""
        btn = obs["button"]
        seat = lambda s: (s - btn) % 2
        bb = int(obs["rules"]["big_blind"])
        stacks = [int(obs["players"][(p + btn) % 2]["starting_stack"]) for p in (0, 1)]
        board = [card_id(c) for c in obs["board"]]
        state = self._deal(2, 0, stacks, bb, int(obs["rules"]["small_blind"]) / bb, {seat(viewer): hole}, board)
        state[3][0, E.T_VIS] = 0
        self._replay(state, [{**e, "seat": seat(e["seat"])} for e in obs["history"][:upto]], bb)
        return state

    def _belief(self, logits, board):
        from .subgame import COMBOS
        p = np.exp(logits - logits.max())
        ok = np.array([lo not in board and hi not in board for lo, hi in COMBOS], np.float64)
        p = p * ok / max((p * ok).sum(), 1e-300)
        return (1 - _RANGE_FLOOR) * p + _RANGE_FLOOR * ok / ok.sum()

    def search(self, obs, session=None):
        """CFR+ re-solve of a heads-up flop, turn or river decision (subgame.NumpySubgame, light
        settings: sampled next cards, pruned combos; a flop tree stops at the turn with the value
        network) within the export's time budget. Ranges come from the network's range head: the
        opponent's from the hero's view now, the hero's from the opponent's view at its last
        decision (averaged over a few likely opponent hands). session statistics tilt the
        opponent's play in the solve."""
        import time
        from .opponent import tilt_table
        from .subgame import COMBOS, NumpySubgame, combo_index, light_args, spot_args
        deadline = time.monotonic() + float(self.manifest["search_seconds"])
        hero_seat, opp_seat = obs["viewer"], 1 - obs["viewer"]
        btn = obs["button"]
        hero, opp = (hero_seat - btn) % 2, (opp_seat - btn) % 2
        hole = tuple(card_id(c) for c in obs["hero_cards"])
        board = [card_id(c) for c in obs["board"]]
        bb = int(obs["rules"]["big_blind"])
        state = self._canonical(obs, hero_seat, hole, len(obs["history"]))
        key = [obs["hero_cards"], obs["board"], len(obs["history"])]
        ranges = np.zeros((2, len(COMBOS)))
        ranges[opp] = self._belief(self._forward(state, key)[3][0], board + list(hole))
        last = max(i for i, e in enumerate(obs["history"]) if e["seat"] == opp_seat)
        rng = np.random.default_rng(zlib.crc32(json.dumps(key).encode()))
        for k in rng.choice(len(COMBOS), _HERO_SAMPLES, p=ranges[opp]):
            past = self._canonical(obs, opp_seat, tuple(int(c) for c in COMBOS[k]), last)
            ranges[hero] += self._belief(self._forward(past, key + [int(k)])[3][0], board) / _HERO_SAMPLES
        tilt = None
        if session is not None and self.baseline is not None:
            tilt = tilt_table(np.asarray(session)[opp_seat], self.baseline)
        game = NumpySubgame(board, ranges, tilt=tilt, opp=opp, value_net=self.value_net if len(board) == 3 else None,
                            **light_args(board, hole), **spot_args(state))
        strategy = game.solve(_MAX_ITERATIONS, deadline).root_strategy(combo_index(hole))
        legal = {a["kind"]: a for a in obs["legal_actions"]}
        rk = "raise" if "raise" in legal else "bet" if "bet" in legal else None
        merged = {}
        for label, size, prob in strategy:
            if label in ("fold", "check", "call") and label in legal:
                choice = (label, int(legal[label]["amount_to"]))
            elif label in ("raise", "allin") and rk is not None:
                lo, hi = int(legal[rk]["min_to"]), int(legal[rk]["max_to"])
                choice = (rk, hi if label == "allin" else min(max(int(round(size * bb)), lo), hi))
            else:
                continue
            merged[choice] = merged.get(choice, 0.0) + prob
        if not merged or math.fsum(merged.values()) <= 0:
            raise ValueError("search strategy maps onto no legal action")
        return self._distribution(merged)

    @staticmethod
    def _targets(obs, fs, tf, ti, mask, bb):
        """Menu index -> (engine kind, amount_to chips) for actions legal in both rule sets."""
        legal = {a["kind"]: a for a in obs["legal_actions"]}
        a = ti[0, E.T_ACTOR]
        maxbet = tf[0, E.T_MAXBET]
        to_call = maxbet - fs[0, a, E.F_SBET]
        pot = sum(fs[0, p, E.F_COMMIT] for p in range(E.MAXP))
        out = {}
        if mask[E.A_FOLD] and "fold" in legal:
            out[E.A_FOLD] = ("fold", int(legal["fold"]["amount_to"]))
        for kind in ("check", "call"):
            if kind in legal:
                out[E.A_CALL] = (kind, int(legal[kind]["amount_to"]))
        rk = "raise" if "raise" in legal else "bet" if "bet" in legal else None
        if rk is not None:
            lo, hi = int(legal[rk]["min_to"]), int(legal[rk]["max_to"])
            for i in range(E.NFRAC):
                if mask[E.A_RAISE0 + i]:
                    chips = int(round((maxbet + E.FRACS[i] * (pot + to_call)) * bb))
                    if lo <= chips < hi:
                        out[E.A_RAISE0 + i] = (rk, chips)
            if mask[E.A_ALLIN]:
                out[E.A_ALLIN] = (rk, hi)
        return out
