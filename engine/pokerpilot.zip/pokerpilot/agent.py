"""Numpy-only inference for an exported PokerNet (runs in Pyodide: no torch, no numba).

`HeadsUpAgent(directory)(observation)` takes a PokerPilot-Explorer style actor view
(integer chips, cards like "Td", full public action history) and returns
[{"kind", "amount_to", "probability"}] over that engine's legal actions.
The training environment state is rebuilt by replaying the public history, so
the features are exactly the ones the network was trained on. Opponent
statistics are hidden (baseline mode).
"""
import json
import math
import zlib
from pathlib import Path

import numpy as np

from . import env as E
from .cards import RANKS, SUITS

_STREETS = ("preflop", "flop", "turn", "river")
_erf = np.vectorize(math.erf, otypes=[np.float64])


def _gelu(x):
    return 0.5 * x * (1.0 + _erf(x / math.sqrt(2.0)))


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def card_id(text):
    return RANKS.index(text[0].upper()) * 4 + SUITS.index(text[1].lower())


class NumpyNet:
    """Single-example forward pass matching pokerpilot.model.PokerNet."""

    def __init__(self, weights):
        self.w = {k: np.asarray(v, np.float64) for k, v in weights.items()}
        self.blocks = len({k.split(".")[1] for k in self.w if k.startswith("blocks.")})

    def _lin(self, x, name):
        return x @ self.w[name + ".weight"].T + self.w[name + ".bias"]

    def _norm(self, x, name):
        m = x.mean(-1, keepdims=True)
        v = ((x - m) ** 2).mean(-1, keepdims=True)
        return (x - m) / np.sqrt(v + 1e-5) * self.w[name + ".weight"] + self.w[name + ".bias"]

    def _gru(self, H):
        w = self.w
        h = np.zeros(w["gru.weight_hh_l0"].shape[1])
        gi_all = H @ w["gru.weight_ih_l0"].T + w["gru.bias_ih_l0"]
        for gi in gi_all:
            gh = h @ w["gru.weight_hh_l0"].T + w["gru.bias_hh_l0"]
            ir, iz, i_n = np.split(gi, 3)
            hr, hz, hn = np.split(gh, 3)
            r = _sigmoid(ir + hr)
            z = _sigmoid(iz + hz)
            n = np.tanh(i_n + r * hn)
            h = (1.0 - z) * n + z * h
        return h

    def forward(self, G, C, S, H):
        w = self.w
        dealt = C < 52
        rank = np.where(dealt, C // 4, 13)
        suit = np.where(dealt, C % 4, 4)
        cards = np.concatenate([w["rank.weight"][rank], w["suit.weight"][suit]], -1) + w["slot"]
        x_c = _gelu(self._lin(cards.reshape(-1), "card_fc"))
        S = S[..., :w["seat_fc.weight"].shape[1]]  # older exports read fewer seat features
        x_s = _gelu(self._lin(_gelu(self._lin(S, "seat_fc")).reshape(-1), "seats_fc"))
        x_g = _gelu(self._lin(G, "g_fc"))
        x = self._lin(np.concatenate([x_c, x_s, self._gru(H), x_g]), "inp")
        for i in range(self.blocks):
            b = f"blocks.{i}"
            x = x + self._lin(_gelu(self._lin(self._norm(x, b + ".norm"), b + ".fc1")), b + ".fc2")
        x = _gelu(self._norm(x, "norm"))
        return self._lin(x, "pi"), float(self._lin(x, "v")[0])


class HeadsUpAgent:
    def __init__(self, directory):
        folder = Path(directory)
        self.manifest = json.loads((folder / "model.json").read_text(encoding="utf-8"))
        with np.load(folder / "weights.npz", allow_pickle=False) as archive:
            self.net = NumpyNet({k: archive[k] for k in archive.files})
        self.preflop_eq = np.load(folder / "preflop_eq.npy", allow_pickle=False)
        self.eq_samples = int(self.manifest["eq_samples"])
        self._sessions = {}

    # ---------------------------------------------------------------- state
    @staticmethod
    def _deal(n, button, stacks, bb, sb_amount, known, board, counters=None):
        """Fresh single-table state. known: seat -> two card ids; other seats get spare cards.
        counters: per-seat session statistics carried into this hand (then visible to the net)."""
        fs = np.zeros((1, E.MAXP, E.NFS))
        is_ = np.zeros((1, E.MAXP, E.NIS), np.int64)
        tf = np.zeros((1, E.NTF))
        ti = np.zeros((1, E.NTI), np.int64)
        hist = np.zeros((1, E.HLEN, E.FH), np.float32)
        used = set(board) | {c for cards in known.values() for c in cards}
        spare = [c for c in range(52) if c not in used]
        ti[0, E.T_NP] = n
        ti[0, E.T_BTN] = button
        ti[0, E.T_LAGG] = -1
        for i in range(5):
            ti[0, E.T_B0 + i] = board[i] if i < len(board) else spare.pop()
        for p in range(E.MAXP):
            if p >= n:
                is_[0, p, E.I_FOLD] = 1
                is_[0, p, E.I_AGENT] = -99
                continue
            cards = known[p] if p in known else (spare.pop(), spare.pop())
            is_[0, p, E.I_H0], is_[0, p, E.I_H1] = cards
            fs[0, p, E.F_STACK] = fs[0, p, E.F_START] = stacks[p] / bb
            is_[0, p, E.I_NEED] = 1
            is_[0, p, E.I_CANR] = 1
            if counters is not None:
                fs[0, p, E.F_HANDS:E.F_BOT] = counters[p]
                ti[0, E.T_VIS] = 1
            fs[0, p, E.F_HANDS] += 1.0
        sb, bbs = (button, (button + 1) % 2) if n == 2 else ((button + 1) % n, (button + 2) % n)
        E._post(0, sb, sb_amount, fs, is_)
        E._post(0, bbs, 1.0, fs, is_)
        tf[0, E.T_MAXBET] = 1.0
        tf[0, E.T_LASTR] = 1.0
        ti[0, E.T_ACTOR] = E._find_next(0, bbs, fs, is_, ti)
        return fs, is_, tf, ti, hist

    @staticmethod
    def _replay(state, events, bb, complete=False):
        """Apply public events; returns True if the hand ended (only allowed when complete)."""
        fs, is_, tf, ti, hist = state
        for i, event in enumerate(events):
            a = ti[0, E.T_ACTOR]
            if event["seat"] != a:
                raise ValueError("history does not match the rebuilt action order")
            kind, raise_to = event["kind"], 0.0
            if kind == "fold":
                k = 0
            elif kind in ("check", "call"):
                k = 2 if tf[0, E.T_MAXBET] - fs[0, a, E.F_SBET] > 1e-9 else 1
            else:
                raise_to = int(event["amount_to"]) / bb
                allin_to = fs[0, a, E.F_SBET] + fs[0, a, E.F_STACK]
                k = 4 if raise_to >= allin_to - 1e-9 else 3
            E._apply_kind(0, k, raise_to, fs, is_, tf, ti, hist)
            if E._advance(0, fs, is_, tf, ti):
                if not complete or i != len(events) - 1:
                    raise ValueError("history ends the hand before the current decision")
                return True
        return False

    def _rebuild(self, obs, session=None):
        players = obs["players"]
        n = len(players)
        if not 2 <= n <= E.MAXP:
            raise ValueError("PokerPilot model supports 2-6 players")
        if obs["rules"].get("ante_mode", "none") != "none":
            raise ValueError("PokerPilot model was trained without antes")
        bb = int(obs["rules"]["big_blind"])
        stacks = [int(p["starting_stack"]) for p in players]
        hole = tuple(card_id(c) for c in obs["hero_cards"])
        board = [card_id(c) for c in obs["board"]]
        state = self._deal(n, obs["button"], stacks, bb, int(obs["rules"]["small_blind"]) / bb,
                           {obs["viewer"]: hole}, board, session)
        self._replay(state, obs["history"], bb)
        fs, is_, tf, ti, hist = state
        if ti[0, E.T_ACTOR] != obs["actor"] or _STREETS[ti[0, E.T_STREET]] != obs["street"]:
            raise ValueError("rebuilt state disagrees with the observation")
        return fs, is_, tf, ti, hist, bb

    # ---------------------------------------------------------------- opponent statistics
    def session_stats(self, key, load_hands, players=2):
        """Per-seat statistics over the completed hands of one session, cached incrementally.
        load_hands(start) returns completed hands after the first `start`, each a dict with
        button, stacks (chips), big_blind, small_blind, events, board and shown
        (seat -> card strings revealed at showdown)."""
        count, counters = self._sessions.get(key, (0, None))
        if counters is None:
            counters = np.zeros((players, E.F_BOT - E.F_HANDS))
        for hand in load_hands(count):
            self._accumulate(hand, counters)
            count += 1
        self._sessions[key] = (count, counters)
        return counters.copy()

    def _accumulate(self, hand, counters):
        n = len(hand["stacks"])
        bb = int(hand["big_blind"])
        shown = {int(p): tuple(card_id(c) for c in cards)
                 for p, cards in hand.get("shown", {}).items() if len(cards) == 2}
        board = [card_id(c) for c in hand["board"]]
        state = self._deal(n, hand["button"], hand["stacks"], bb, int(hand["small_blind"]) / bb,
                           shown, board, counters)
        fs, is_, tf, ti, hist = state
        self._replay(state, hand["events"], bb, complete=True)
        for p in range(n):
            fs[0, p, E.F_VPIP] += is_[0, p, E.I_HVPIP]
            fs[0, p, E.F_PFR] += is_[0, p, E.I_HPFR]
            if p not in shown:
                is_[0, p, E.I_RAGG] = is_[0, p, E.I_RCALL] = 0
        if len(board) == 5:
            E._count_showdown(0, fs, is_, ti)
        counters[:] = fs[0, :n, E.F_HANDS:E.F_BOT]

    # ---------------------------------------------------------------- policy
    def evaluate(self, obs, session=None):
        """Returns (distribution over the engine's legal actions, value in units of E).
        session: per-seat statistics from session_stats; None keeps opponents unknown."""
        fs, is_, tf, ti, hist, bb = self._rebuild(obs, session)
        G = np.zeros((1, E.NG), np.float32)
        C = np.zeros((1, 7), np.int64)
        S = np.zeros((1, E.MAXP, E.NS), np.float32)
        M = np.zeros((1, E.NA), np.bool_)
        EQ = np.zeros(1)
        key = json.dumps([obs["hero_cards"], obs["board"], len(obs["history"])]).encode()
        np.random.seed(zlib.crc32(key))  # deterministic MC equity for the same decision
        E.build_obs(fs, is_, tf, ti, hist, np.zeros((1, 52), np.int64), self.preflop_eq,
                    self.eq_samples, G, C, S, M, EQ, np.zeros(1, np.int64), np.zeros(1, np.int64))
        logits, value = self.net.forward(G[0].astype(np.float64), C[0], S[0].astype(np.float64),
                                         hist[0].astype(np.float64))
        targets = self._targets(obs, fs, tf, ti, M[0], bb)
        if not targets:
            raise ValueError("no legal action maps onto the model menu")
        idx = np.array(sorted(targets))
        z = logits[idx] - logits[idx].max()
        p = np.exp(z) / np.exp(z).sum()
        merged = {}
        for i, prob in zip(idx, p):
            merged[targets[i]] = merged.get(targets[i], 0.0) + float(prob)
        total = math.fsum(merged.values())
        out = [{"kind": k, "amount_to": str(amt), "probability": v / total}
               for (k, amt), v in merged.items()]
        top = max(range(len(out)), key=lambda j: out[j]["probability"])
        out[top]["probability"] += 1.0 - math.fsum(o["probability"] for o in out)
        return out, value

    def __call__(self, obs):
        return self.evaluate(obs)[0]

    @staticmethod
    def _targets(obs, fs, tf, ti, mask, bb):
        """Menu index -> (engine kind, amount_to chips) for actions legal in both rule sets."""
        legal = {a["kind"]: a for a in obs["legal_actions"]}
        a = ti[0, E.T_ACTOR]
        maxbet = tf[0, E.T_MAXBET]
        to_call = maxbet - fs[0, a, E.F_SBET]
        pot = sum(fs[0, p, E.F_COMMIT] for p in range(E.MAXP))
        out = {}
        if mask[E.A_FOLD] and "fold" in legal:
            out[E.A_FOLD] = ("fold", int(legal["fold"]["amount_to"]))
        for kind in ("check", "call"):
            if kind in legal:
                out[E.A_CALL] = (kind, int(legal[kind]["amount_to"]))
        rk = "raise" if "raise" in legal else "bet" if "bet" in legal else None
        if rk is not None:
            lo, hi = int(legal[rk]["min_to"]), int(legal[rk]["max_to"])
            for i in range(E.NFRAC):
                if mask[E.A_RAISE0 + i]:
                    chips = int(round((maxbet + E.FRACS[i] * (pot + to_call)) * bb))
                    if lo <= chips < hi:
                        out[E.A_RAISE0 + i] = (rk, chips)
            if mask[E.A_ALLIN]:
                out[E.A_ALLIN] = (rk, hi)
        return out
