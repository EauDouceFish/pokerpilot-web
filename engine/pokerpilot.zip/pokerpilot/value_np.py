"""Plain-numpy turn value network (pokerpilot.value without torch, for Pyodide): the depth-limit
leaf values of subgame.NumpySubgame flop trees. Weights: tools/export_browser.py (value.npz)."""
import numpy as np

NBIN = 10
NFEAT = 4 + 2 * NBIN + 4
_K = 1326


def ehs_features(s):
    """(mean, mean square) over the river cards of each combo's equity against a random hand, from
    hand scores s (rivers, K), -1 where a combo collides with the board or that river."""
    ok = s >= 0
    ref = np.where(ok, s, np.iinfo(np.int64).max)
    srt = np.sort(ref, 1)
    lt = np.stack([np.searchsorted(srt[r], ref[r], "left") for r in range(len(s))]).astype(np.float64)
    le = np.stack([np.searchsorted(srt[r], ref[r], "right") for r in range(len(s))]).astype(np.float64)
    n = ok.sum(1, keepdims=True)
    p = np.where(ok, (lt + 0.5 * (le - lt - 1)) / np.maximum(n - 1, 1), 0.0)
    cnt = np.maximum(ok.sum(0), 1)
    return p.sum(0) / cnt, (p * p).sum(0) / cnt


def _gelu(x):
    # tanh approximation (|error| ~ 1e-3, well below the network's own error)
    return 0.5 * x * (1.0 + np.tanh(np.float32(0.7978846) * (x + np.float32(0.044715) * x * x * x)))


class ValueNet:
    """weights: mlp.{0,2,4,6}.{weight,bias} of value.ValueNet."""

    def __init__(self, weights):
        self.w = [(np.asarray(weights[f"mlp.{i}.weight"], np.float32).T,
                   np.asarray(weights[f"mlp.{i}.bias"], np.float32)) for i in (0, 2, 4, 6)]

    def leaf_values(self, eqv, ehs, ehs2, own, opp, spr, seat, rows):
        """Values per unit pot and opponent mass at the True entries of rows, in order. eqv, own,
        opp, rows: (spots, K); ehs, ehs2: (K,); spr: (spots,). The first layer is split into its
        per-combo and per-spot parts (value.features)."""
        own = own / np.maximum(own.sum(-1, keepdims=True), 1e-30)
        opp = opp / np.maximum(opp.sum(-1, keepdims=True), 1e-30)
        bins = np.minimum((ehs * NBIN).astype(np.int64), NBIN - 1)
        onehot = (bins[:, None] == np.arange(NBIN)).astype(np.float32)   # (K, NBIN)
        r_eq = (own * eqv).sum(-1, keepdims=True)
        lspr = np.log(np.maximum(spr, 1e-3))[:, None]
        ctx = np.concatenate([own @ onehot, opp @ onehot, r_eq, lspr, np.full_like(lspr, float(seat)),
                              np.ones_like(lspr)], -1).astype(np.float32)
        (w0, b0), (w1, b1), (w2, b2), (w3, b3) = self.w
        spot, combo = np.nonzero(rows)
        per = np.stack([eqv[spot, combo], ehs[combo], ehs2[combo], np.log1p(_K * own[spot, combo])],
                       -1).astype(np.float32)
        x = _gelu(per @ w0[:4] + (ctx @ w0[4:] + b0)[spot])
        x = _gelu(x @ w1 + b1)
        x = _gelu(x @ w2 + b2)
        return (x @ w3 + b3)[..., 0]
