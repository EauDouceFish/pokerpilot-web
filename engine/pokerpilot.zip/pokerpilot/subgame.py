"""Heads-up flop / turn / river subgame: the bet tree and a plain-numpy CFR+ solver (runs in
Pyodide; turn and river only).

A river or turn tree goes from the current decision to the end of the hand, a turn tree dealing
every river card. A flop tree deals every turn card and stops when the turn betting closes: its
leaves are worth the showdown averaged over the river (both players check it down), the value
estimate that limits the depth. Amounts in big blinds: `commit` = total each player has put in,
`sbets` = this street's bets, `stacks` = what remains behind. Seat 0 is the button, seat 1 (big
blind) acts first after the flop. search.Subgame solves the same trees with torch on a GPU.

The numpy solver evaluates showdowns by sorting hands by strength: a hand's value is the opponent
reach below it minus the reach above it, each read off a prefix sum, less the opponent combos that
share one of its cards (prefix sums over the 51 combos holding each card), so a showdown costs
O(1326) instead of a 1326 x 1326 matrix product.
"""
from collections import namedtuple

import numpy as np

from . import env as E
from .cards import evaluate
from .jit import njit
from .opponent import AGGR, FOLD, PASS, context

K = E.NCOMBO
COMBOS = np.array([(lo, hi) for hi in range(1, 52) for lo in range(hi)], np.int64)
Spec = namedtuple("Spec", "bets raises max_raises")  # pot fractions; all-in is always offered
RIVER_SPEC = Spec((0.33, 0.75, 1.5), (1.0,), 3)  # river subgame
TURN_SPEC = Spec((0.5, 1.0), (), 2)               # turn street of a turn subgame
LATER_RIVER_SPEC = Spec((0.5, 1.0), (), 2)        # river streets inside a turn subgame
FLOP_SPEC = Spec((0.33, 0.75), (0.75,), 2)        # flop street of a flop subgame
LATER_TURN_SPEC = Spec((0.5, 1.0), (), 2)         # turn streets inside a flop subgame
STREET_SPECS = {1: (FLOP_SPEC, LATER_TURN_SPEC), 2: (TURN_SPEC, LATER_RIVER_SPEC), 3: (RIVER_SPEC, None)}
# browser search (NumpySubgame): sampled next cards, one river bet size inside turn trees, combos
# below a quarter of a uniform range's weight in both ranges left out
LIGHT_RIVER_SPEC = Spec((0.75,), (), 2)
LIGHT_CARDS = 8
LIGHT_PRUNE = 0.25
CLASSES = {"fold": FOLD, "check": PASS, "call": PASS, "raise": AGGR, "allin": AGGR}
CARD_COMBOS = np.array([np.nonzero((COMBOS == c).any(1))[0] for c in range(52)])  # (52, 51)


def combo_index(hole):
    lo, hi = sorted(int(c) for c in hole)
    return hi * (hi - 1) // 2 + lo


@njit(cache=True)
def strengths(board, rivers, combos):
    """Hand score per (river card, combo); -1 where the combo collides with the cards."""
    out = np.full((rivers.shape[0], combos.shape[0]), -1, np.int64)
    cards = np.zeros(7, np.int64)
    nb = board.shape[0]
    for i in range(nb):
        cards[2 + i] = board[i]
    for r in range(rivers.shape[0]):
        if rivers[r] >= 0:
            cards[2 + nb] = rivers[r]
        for k in range(combos.shape[0]):
            lo, hi = combos[k, 0], combos[k, 1]
            clash = lo == rivers[r] or hi == rivers[r]
            for i in range(nb):
                if lo == board[i] or hi == board[i]:
                    clash = True
            if not clash:
                cards[0], cards[1] = lo, hi
                out[r, k] = evaluate(cards, 7)
    return out


_RANK_TABLES = []


def _rank_tables():
    """Per 13-bit rank mask: highest rank, top-n ranks packed 4 bits each (highest first, as
    cards.evaluate), straight high card (-1 if none)."""
    if not _RANK_TABLES:
        m = np.arange(8192)
        ranks = np.arange(12, -1, -1)
        bits = (m[:, None] >> ranks) & 1
        high = np.where(bits.any(1), ranks[bits.argmax(1)], -1)
        csum = np.cumsum(bits, 1)
        top = np.zeros((6, 8192), np.int64)
        for n in range(1, 6):
            for j in range(13):
                take = (bits[:, j] == 1) & (csum[:, j] <= n)
                top[n] = np.where(take, (top[n] << 4) | ranks[j], top[n])
        straight = np.full(8192, -1)
        for h in range(3, 13):
            w = 0x1F << (h - 4) if h >= 4 else 0x100F
            straight = np.where((m & w) == w, h, straight)
        _RANK_TABLES.extend((high, top, straight))
    return _RANK_TABLES


def evaluate_np(cards):
    """cards.evaluate over the rows of cards (N, 7), vectorized for Pyodide (no numba there)."""
    high, top, straight = _rank_tables()
    n = cards.shape[0]
    r, s = cards >> 2, cards & 3
    bit = np.left_shift(1, r)
    rows = np.arange(n)
    cnt = np.zeros((n, 13), np.int64)
    smask = np.zeros((n, 4), np.int64)
    scnt = np.zeros((n, 4), np.int64)
    for i in range(cards.shape[1]):
        cnt[rows, r[:, i]] += 1
        smask[rows, s[:, i]] |= bit[:, i]
        scnt[rows, s[:, i]] += 1
    pw = np.left_shift(1, np.arange(13))
    anym, m4, m3, m2 = (((cnt > 0) if k == 0 else (cnt == k)).astype(np.int64) @ pw for k in (0, 4, 3, 2))
    b = lambda x: np.where(x >= 0, np.left_shift(1, np.maximum(x, 0)), 0)
    sh = lambda x, k: np.where(x >= 0, np.left_shift(np.maximum(x, 0), k), 0)
    fsuit = scnt.argmax(1)
    flush = scnt[rows, fsuit] >= 5
    fm = smask[rows, fsuit]
    sf = straight[fm]
    quad = high[m4]
    t1 = high[m3]
    t2 = high[m3 & ~b(t1)]
    p1 = high[m2]
    p2 = high[m2 & ~b(p1)]
    st = straight[anym]
    score = top[5][anym]
    score = np.where(p1 >= 0, (1 << 20) | sh(p1, 16) | (top[3][anym & ~b(p1)] << 4), score)
    score = np.where((p1 >= 0) & (p2 >= 0), (2 << 20) | sh(p1, 16) | sh(p2, 12)
                     | sh(high[anym & ~b(p1) & ~b(p2)], 8), score)
    score = np.where(t1 >= 0, (3 << 20) | sh(t1, 16) | (top[2][anym & ~b(t1)] << 8), score)
    score = np.where(st >= 0, (4 << 20) | sh(st, 16), score)
    score = np.where((t1 >= 0) & ((t2 >= 0) | (p1 >= 0)), (6 << 20) | sh(t1, 16) | sh(np.maximum(t2, p1), 12), score)
    score = np.where(quad >= 0, (7 << 20) | sh(quad, 16) | sh(high[anym & ~b(quad)], 12), score)
    score = np.where(flush, (5 << 20) | top[5][fm], score)
    score = np.where(flush & (sf >= 0), (8 << 20) | sh(sf, 16), score)
    return score


def strengths_np(board, rivers):
    """strengths(board, rivers, COMBOS) with evaluate_np."""
    board, rivers = np.asarray(board, np.int64), np.asarray(rivers, np.int64)
    nr = len(rivers)
    extra = rivers[:, None] if rivers[0] >= 0 else np.zeros((nr, 0), np.int64)
    public = np.concatenate([np.broadcast_to(board, (nr, len(board))), extra], 1)  # (rivers, 5)
    cards = np.concatenate([np.broadcast_to(COMBOS, (nr, K, 2)),
                            np.broadcast_to(public[:, None, :], (nr, K, public.shape[1]))], 2)
    score = evaluate_np(cards.reshape(nr * K, -1)).reshape(nr, K)
    clash = (COMBOS[None, :, :, None] == public[:, None, None, :]).any((2, 3))
    return np.where(clash, -1, score)


def sample_cards(board, n=None, exclude=()):
    """[(card, weight)]: about n of the cards that can come next, stratified by suit with the ranks
    spread evenly, each weighted by the cards it stands for (all of them, weight 1, if n is None)."""
    left = [c for c in range(52) if c not in board and c not in exclude]
    if n is None or n >= len(left):
        return [(c, 1.0) for c in left]
    groups = [[c for c in left if c % 4 == s] for s in range(4)]
    groups = [g for g in groups if g]
    share = np.array([len(g) for g in groups]) * n / len(left)
    quota = np.maximum(np.floor(share).astype(int), 1)
    for j in np.argsort(-(share - np.floor(share))):
        if quota.sum() >= n:
            break
        quota[j] += 1
    out = []
    for g, k in zip(groups, quota):
        k = min(int(k), len(g))
        out += [(g[i], len(g) / k) for i in ((np.arange(k) + 0.5) * len(g) / k).astype(int)]
    return out


def light_args(board, hole):
    """NumpySubgame keywords of the browser search for a decision holding `hole` on `board`."""
    kw = dict(keep=combo_index(hole))
    if len(board) < 5:
        kw.update(deal_cards=sample_cards(board, LIGHT_CARDS, exclude=hole), prune=LIGHT_PRUNE)
    if len(board) == 4:
        kw["specs"] = (TURN_SPEC, LIGHT_RIVER_SPEC)
    return kw


def spot_args(state):
    """Tree arguments for the current decision of a rebuilt heads-up state (button = seat 0)."""
    fs, is_, tf, ti, hist = state
    actor = int(ti[0, E.T_ACTOR])
    sbets = [float(fs[0, p, E.F_SBET]) for p in (0, 1)]
    return dict(commit=[float(fs[0, p, E.F_COMMIT]) for p in (0, 1)], sbets=sbets,
                stacks=[float(fs[0, p, E.F_STACK]) for p in (0, 1)], actor=actor,
                checked=max(sbets) == 0 and actor == 0, last_raise=float(tf[0, E.T_LASTR]),
                raises=(max(sbets) > 0) + (min(sbets) > 0),
                cx=(int(ti[0, E.T_STREET]), (int(is_[0, 0, E.I_ST]), int(is_[0, 1, E.I_ST])),
                    int(ti[0, E.T_NRAISE]), (int(is_[0, 0, E.I_PAGG]), int(is_[0, 1, E.I_PAGG])),
                    int(ti[0, E.T_LAGG])))


class Tree:
    """Bet tree plus its edges in breadth-first order (so the edges of one node, and of one depth,
    are contiguous). cx: (street, st per seat, raises this street, previous-street aggressor
    flags, last aggressor) as in the env, for the statistics cell of each node; tilt: opponent-
    model multipliers (opponent.tilt_table) on the strategy of seat `opp`."""

    def __init__(self, board, commit, sbets, stacks, actor, checked, last_raise, raises, cx=None,
                 tilt=None, opp=None, depth_limit=False, deal_cards=None, specs=None):
        self.board = [int(c) for c in board]
        self.street = len(self.board) - 2
        self.turn = self.street == 2
        # flop tree only: stop once the turn card is dealt; those leaves are valued by a network
        self.depth_limit = depth_limit and self.street == 1
        # the card dealt inside the tree (turn in a flop tree, river in a turn tree): every card, or
        # deal_cards = [(card, weight)] (sample_cards) standing for the rest
        if self.street == 3:
            deal_cards = [(-1, 1.0)]
        deal_cards = deal_cards or sample_cards(self.board)
        self.rivers = [int(c) for c, _ in deal_cards]
        self.deal_w = np.array([w for _, w in deal_cards])
        self.tilt, self.opp = tilt, opp
        self.nodes = []
        spec, self.later = specs or STREET_SPECS[self.street]
        cx = cx or (self.street, (0, 0), raises, (0, 0), -1)
        self.root = self._build(actor, list(commit), list(sbets), list(stacks), checked, last_raise, raises,
                                spec, None if self.street < 3 else 0, cx)
        self._edges()

    def _node(self, **kw):
        self.nodes.append(kw)
        return len(self.nodes) - 1

    def _close(self, commit, stacks, card, cx):
        """Betting closed: a leaf once the tree's card is out (showdown, or the depth limit of a
        flop tree), otherwise deal every card."""
        if card is not None:
            return self._node(kind="show", commit=commit, card=card)
        lagg = cx[4]
        nxt = (cx[0] + 1, (0, 0), 0, (int(lagg == 0), int(lagg == 1)), lagg)
        kids = []
        for c in range(len(self.rivers)):
            if min(stacks) <= 1e-9:
                child = self._node(kind="show", commit=list(commit), card=c)
            elif self.depth_limit:
                child = self._node(kind="leaf", commit=list(commit), stacks=list(stacks), card=c)
            else:
                child = self._build(1, list(commit), [0.0, 0.0], list(stacks), False, 0.0, 0, self.later, c, nxt)
            kids.append(("deal", c, child))
        return self._node(kind="chance", kids=kids)

    def _build(self, a, commit, sbets, stacks, checked, last_raise, raises, spec, card, cx):
        b = 1 - a
        to_call = sbets[b] - sbets[a]
        pot = commit[0] + commit[1]
        street, st, nraise, pagg, lagg = cx
        cell = street * E.NCTX + context(street, a, to_call, st, nraise, pagg)
        passed = list(st)
        passed[a] = max(st[a], 1)
        cx_pass = (street, tuple(passed), nraise, pagg, lagg)
        aggr = list(st)
        aggr[a] = 2
        cx_aggr = (street, tuple(aggr), nraise + 1, pagg, a)
        kids = []
        if to_call > 1e-9:
            kids.append(("fold", 0.0, self._node(kind="fold", folder=a, commit=list(commit))))
            pay = min(to_call, stacks[a])
            c2, s2, st2 = list(commit), list(sbets), list(stacks)
            c2[a] += pay
            s2[a] += pay
            st2[a] -= pay
            kids.append(("call", s2[a], self._close(c2, st2, card, cx_pass)))
            allowed, fracs = raises < spec.max_raises and stacks[a] > to_call and stacks[b] > 0, spec.raises
        else:
            if checked:
                kids.append(("check", sbets[a], self._close(list(commit), list(stacks), card, cx_pass)))
            else:
                kids.append(("check", sbets[a], self._build(b, list(commit), list(sbets), list(stacks), True,
                                                            last_raise, raises, spec, card, cx_pass)))
            allowed, fracs = stacks[a] > 0 and stacks[b] > 0, spec.bets
        if allowed:
            allin_to = sbets[a] + stacks[a]
            min_to = sbets[b] + max(last_raise, 1.0)
            sizes = sorted({min(max(sbets[b] + f * (pot + to_call), min_to), allin_to) for f in fracs} | {allin_to})
            for size in sizes:
                add = size - sbets[a]
                c2, s2, st2 = list(commit), list(sbets), list(stacks)
                c2[a] += add
                s2[a] = size
                st2[a] -= add
                child = self._build(b, c2, s2, st2, False, size - sbets[b], raises + 1, spec, card, cx_aggr)
                kids.append(("allin" if size >= allin_to - 1e-9 else "raise", size, child))
        return self._node(kind="act", actor=a, kids=kids, cell=cell)

    def _edges(self):
        nodes = self.nodes
        depth, order, edges = {self.root: 0}, [self.root], []
        for n in order:
            if nodes[n]["kind"] in ("act", "chance"):
                actor = nodes[n].get("actor", 2)
                for label, x, c in nodes[n]["kids"]:
                    depth[c] = depth[n] + 1
                    m = 1.0
                    if self.tilt is not None and actor == self.opp:
                        m = float(self.tilt[nodes[n]["cell"], CLASSES[label]])
                    edges.append((n, c, actor, depth[n], len(nodes[n]["kids"]), x if actor == 2 else -1, m))
                    order.append(c)
        self.P, self.C, self.A, self.D, self.NK, self.CARD, self.TILT = (np.array(x) for x in zip(*edges))
        self.root_edges = np.nonzero(self.P == self.root)[0]
        folds = [n for n in range(len(nodes)) if nodes[n]["kind"] == "fold"]
        coef = np.zeros((2, len(folds), 1))
        for j, n in enumerate(folds):
            c = nodes[n]["commit"]
            for i in (0, 1):
                coef[i, j] = -c[i] if nodes[n]["folder"] == i else c[1 - i]
        self.folds, self.fold_coef = np.array(folds, np.int64), coef
        shows = [[] for _ in self.rivers]
        for n in range(len(nodes)):
            if nodes[n]["kind"] == "show":
                shows[nodes[n]["card"]].append(n)
        assert len({len(s) for s in shows}) == 1, "river subtrees differ"
        self.shows = np.array(shows, np.int64)  # (cards, showdowns per card)
        self.stake = np.array([[min(nodes[n]["commit"]) for n in s] for s in shows]).reshape(len(shows), -1, 1)
        leaves = [[n for n in range(len(nodes)) if nodes[n]["kind"] == "leaf" and nodes[n]["card"] == c]
                  for c in range(len(self.rivers))]
        self.leaves = np.array(leaves, np.int64) if leaves[0] else None  # (cards, leaves per card)
        if self.leaves is not None:
            first = [nodes[n] for n in self.leaves[0]]
            self.leaf_pot = np.array([sum(x["commit"]) for x in first])
            self.leaf_spr = np.array([min(x["stacks"]) / sum(x["commit"]) for x in first])
        self.n = len(nodes)

    def strength(self):
        return strengths(np.array(self.board, np.int64), np.array(self.rivers, np.int64), COMBOS)

    def root_actions(self, avg_row):
        """[(label, street total in big blinds, probability)] from the root edges' average weights."""
        kids = self.nodes[self.root]["kids"]
        total = avg_row.sum()
        p = avg_row / total if total > 0 else np.full(len(kids), 1.0 / len(kids))
        return [(label, size, float(q)) for (label, size, _), q in zip(kids, p)]


def showdown_tables(strength):
    """Lookups for sorted showdowns per river card (rows of strength): global order, each combo's
    first / past-last position among equal scores, and per held card the 51 combos sorted with
    each combo's positions there (flat indices card * 52 + position, low and high card)."""
    nc = strength.shape[0]
    order = np.argsort(strength, 1, kind="stable")
    ss = np.take_along_axis(strength, order, 1)
    lo, hi = (_row_search(ss, strength, how) for how in ("left", "right"))
    sc = strength[:, CARD_COMBOS]                        # (cards, 52, 51)
    corder = np.argsort(sc, 2, kind="stable")
    card_sorted = np.take_along_axis(np.broadcast_to(CARD_COMBOS, sc.shape), corder, 2).reshape(nc, -1)
    css = np.take_along_axis(sc, corder, 2).reshape(-1, 51)
    p = [_row_search(css, sc.reshape(-1, 51), how).reshape(nc, 52, 51) for how in ("left", "right")]
    pos = np.zeros((2, 2, nc, K), np.int64)              # (low / high card, left / right, card, combo)
    first = COMBOS[CARD_COMBOS, 0] == np.arange(52)[:, None]
    for j, sel in enumerate((first, ~first)):
        xs, ii = np.nonzero(sel)
        for side in (0, 1):
            pos[j, side][:, CARD_COMBOS[xs, ii]] = p[side][:, xs, ii]
    card_pos = [(COMBOS[:, j] * 52 + pos[j, 0], COMBOS[:, j] * 52 + pos[j, 1], COMBOS[:, j]) for j in (0, 1)]
    return order, lo, hi, card_sorted, card_pos


def _row_search(sorted_rows, query, side):
    """np.searchsorted of each query row in the matching sorted row, as one call (row offsets)."""
    nr, n = sorted_rows.shape
    span = int(max(sorted_rows.max(), query.max())) + 2
    off = (np.arange(nr, dtype=np.int64) * span)[:, None]
    idx = np.searchsorted((sorted_rows + 1 + off).ravel(), (query + 1 + off).ravel(), side)
    return idx.reshape(query.shape) - (np.arange(nr) * n)[:, None]


def show_diff(q, tables, valid):
    """q: (cards, T, K) opponent reach at showdowns, one row of showdown_tables per card; returns
    each combo's opponent reach below minus above it (card removal included)."""
    order, lo, hi, card_sorted, card_pos = tables
    nc, T, _ = q.shape
    out = np.empty(q.shape, q.dtype)
    z = np.zeros((T, 1), q.dtype)
    for c in range(nc):
        qc = q[c]
        cum = np.concatenate([z, np.cumsum(qc[:, order[c]], 1)], 1)
        d = cum[:, lo[c]] + cum[:, hi[c]] - cum[:, -1:]          # below minus above
        ccum = np.concatenate([np.zeros((T, 52, 1), q.dtype), np.cumsum(qc[:, card_sorted[c]].reshape(T, 52, 51), 2)], 2)
        ctot = ccum[:, :, -1]
        ccum = ccum.reshape(T, 52 * 52)
        for clo, chi, x in card_pos:
            d -= ccum[:, clo[c]] + ccum[:, chi[c]] - ctot[:, x]
        out[c] = d * valid[c]
    return out


REFRESH = {1, 3, 8, 20, 50, 120, 300}  # iterations that re-evaluate a flop tree's leaves


class NumpySubgame(Tree):
    """Tree solved with plain numpy (float32). A flop tree takes value_net (value_np.ValueNet): it
    stops at the turn card and the net values those leaves. Leaves and all-in showdowns of a flop
    tree are re-evaluated at the REFRESH iterations; in between they keep their values per unit of
    compatible opponent reach (the opponent's range there changes in mass faster than in shape).
    keep: the hero's combo, always solved (and valued by the net). prune: combos whose weight in
    both ranges is below this share of a uniform range are left out of the solve."""

    def __init__(self, board, ranges, *args, value_net=None, keep=None, prune=0.0, **kw):
        super().__init__(board, *args, depth_limit=value_net is not None, **kw)
        assert self.street >= 2 or value_net is not None, "a flop tree needs a value net"
        board_ok = np.array([lo not in self.board and hi not in self.board for lo, hi in COMBOS])
        r = np.asarray(ranges, np.float64) * board_ok
        density = r / np.maximum(r.sum(1, keepdims=True), 1e-300) * board_ok.sum()
        sel = board_ok & (density.max(0) >= prune)
        if keep is not None:
            sel[keep] = True
        self.cidx = np.nonzero(sel)[0]                   # the combos solved
        self.kc = len(self.cidx)
        self.keep = None if keep is None else int(np.searchsorted(self.cidx, keep))
        self.n_valid = float(board_ok.sum())
        self.lo_c, self.hi_c = COMBOS[self.cidx, 0], COMBOS[self.cidx, 1]
        self.held = np.zeros((self.kc, 52), np.float32)
        self.held[np.arange(self.kc), self.lo_c] = 1
        self.held[np.arange(self.kc), self.hi_c] = 1
        self.value_net = value_net
        if self.street >= 2:
            strength = strengths_np(self.board, self.rivers)          # (cards, K)
            self.valid = (strength >= 0).astype(np.float32)
            self.tables = showdown_tables(strength)
            self.deal = (self.valid * (self.deal_w[:, None] / (44.0 if self.turn else 1.0)))[:, self.cidx]
        else:
            from .value_np import ehs_features
            self.turn_tables, self.turn_valid, self.ehs = [], [], []
            ok = np.zeros((len(self.rivers), K), np.float32)
            for c, turn in enumerate(self.rivers):
                b = self.board + [turn]
                s = strengths_np(b, [r for r in range(52) if r not in b])
                self.turn_tables.append(showdown_tables(s))
                self.turn_valid.append((s >= 0).astype(np.float32))
                self.ehs.append(tuple(x[self.cidx] for x in ehs_features(s)))
                ok[c] = (COMBOS != turn).all(1) & board_ok
            # chance: each (hand, hand) pair leaves 45 turn cards
            self.deal = (ok * (self.deal_w[:, None] / 45.0))[:, self.cidx]
            self.cache = [None, None]
        self.deal = self.deal.astype(np.float32)
        self.ranges = r[:, self.cidx].astype(np.float32)
        self._prepare()

    def _full(self, q):
        """(..., solved combos) -> (..., K), zero elsewhere."""
        out = np.zeros(q.shape[:-1] + (K,), np.float32)
        out[..., self.cidx] = q
        return out

    def _show_diff(self, q, tables, valid):
        return show_diff(self._full(q), tables, valid)[..., self.cidx]

    def _prepare(self):
        """Renumbers the nodes breadth-first (the child of edge k is node k + 1, the root node 0), so
        each depth's children and parents are contiguous blocks and a CFR pass works on slices."""
        E_ = len(self.P)
        new = np.zeros(self.n, np.int64)
        new[self.C] = np.arange(1, E_ + 1)
        self.P, self.C = new[self.P], np.arange(1, E_ + 1)
        self.folds, self.shows = new[self.folds], new[self.shows]
        if self.leaves is not None:
            self.leaves = new[self.leaves]
        self.n = E_ + 1
        self.starts = np.r_[0, np.nonzero(np.diff(self.P))[0] + 1]  # first edge of each parent
        self.counts = np.diff(np.r_[self.starts, E_])
        self.uniform = (1.0 / self.NK)[:, None].astype(np.float32)
        self.fold_coef = self.fold_coef.astype(np.float32)
        self.stake = self.stake.astype(np.float32)
        self.levels = []
        ps, pe = 0, 1                                    # the parents' block (nodes at this depth)
        for d in range(self.D.max() + 1):
            sel = np.nonzero(self.D == d)[0]
            s, e = sel[0], sel[-1] + 1
            P, A = self.P[s:e], self.A[s:e]
            deal = None
            if (self.CARD[s:e] >= 0).any():
                deal = np.ones((e - s, self.kc), np.float32)
                ch = np.nonzero(self.CARD[s:e] >= 0)[0]
                deal[ch] = self.deal[self.CARD[s:e][ch]]
            gs = np.r_[0, np.nonzero(np.diff(P))[0] + 1]
            counts = np.bincount(P - ps, minlength=pe - ps)
            acts = [np.nonzero(A == p)[0] for p in (0, 1)]
            self.levels.append((s, e, ps, pe, counts, acts, deal, None if deal is None else deal > 0, gs, P[gs]))
            ps, pe = s + 1, e + 1
        self.tilt_e = self.TILT[:, None].astype(np.float32) if self.tilt is not None else None
        self.mine = [np.nonzero(self.A == i)[0] for i in (0, 1)]
        self.regret = np.zeros((E_, self.kc), np.float32)
        self.avg = np.zeros((E_, self.kc), np.float32)
        self.it = 0

    def _group_sum(self, x):
        return np.repeat(np.add.reduceat(x, self.starts, 0), self.counts, 0)

    def _fold_values(self, q):
        """sum of q over combos sharing no card with each combo (the board is already excluded)."""
        card = q @ self.held                             # (..., 52)
        return q.sum(-1, keepdims=True) - card[..., self.lo_c] - card[..., self.hi_c] + q

    def _flop_terminals(self, reach, i, val):
        """Values of a flop tree's leaves (turn value net) and all-in showdowns (over the river)."""
        q = reach[1 - i]
        L = 0 if self.leaves is None else self.leaves.shape[1]
        idx = np.concatenate([self.leaves if L else np.zeros((len(self.rivers), 0), np.int64), self.shows], 1)
        mass = self._fold_values(q[idx])                 # (cards, L + T, K)
        if self.cache[i] is None or self.it in REFRESH:
            per = np.zeros_like(mass)
            for c in range(len(self.rivers)):
                tables, valid = self.turn_tables[c], self.turn_valid[c]
                qc = np.ascontiguousarray(np.broadcast_to(q[idx[c]], (len(valid),) + q[idx[c]].shape))
                d = self._show_diff(qc, tables, valid).sum(0) / 44.0 / np.maximum(mass[c], 1e-30)
                per[c, L:] = d[L:]
                if L:
                    eqv = np.clip(0.5 + 0.5 * d[:L], 0.0, 1.0)
                    per[c, :L] = self._net_values(eqv, self.ehs[c], reach[i][self.leaves[c]], q[self.leaves[c]], i)
            self.cache[i] = per
        per = self.cache[i]
        if L:
            val[self.leaves] = per[:, :L] * mass[:, :L] * self.leaf_pot[:, None].astype(np.float32)
        if self.shows.shape[1]:
            val[self.shows] = self.stake * per[:, L:] * mass[:, L:]

    def _net_values(self, eqv, ehs, own, opp, seat):
        """Value net at the leaves of one turn card for combos holding a real share of the leaf's own
        reach (and `keep`); the checkdown value elsewhere."""
        share = own / np.maximum(own.sum(-1, keepdims=True), 1e-30)
        rows = share * self.n_valid > 0.2
        if self.keep is not None:
            rows[:, self.keep] = True
        out = (eqv - 0.5).astype(np.float32)
        if rows.any():
            out[rows] = self.value_net.leaf_values(eqv, ehs[0], ehs[1], own, opp, self.leaf_spr, seat, rows)
        return out

    def _pass(self, i, it):
        pos = np.maximum(self.regret, 0.0)
        total = self._group_sum(pos)
        sigma = np.where(total > 0, pos / np.maximum(total, 1e-30), self.uniform)
        if self.tilt_e is not None:
            sigma = sigma * self.tilt_e
            sigma /= np.maximum(self._group_sum(sigma), 1e-30)
        reach = np.zeros((2, self.n, self.kc), np.float32)
        reach[:, 0] = self.ranges
        for s, e, ps, pe, counts, acts, deal, dealt, gs, parents in self.levels:
            r = np.repeat(reach[:, ps:pe], counts, 1)
            for p in (0, 1):
                if len(acts[p]):
                    r[p, acts[p]] *= sigma[s + acts[p]]
            if deal is not None:
                r *= deal
            reach[:, s + 1:e + 1] = r
        q = reach[1 - i]
        val = np.zeros((self.n, self.kc), np.float32)
        if len(self.folds):
            val[self.folds] = self.fold_coef[i] * self._fold_values(q[self.folds])
        if self.street == 1:
            self._flop_terminals(reach, i, val)
        elif self.shows.shape[1]:
            val[self.shows] = self.stake * self._show_diff(q[self.shows], self.tables, self.valid)
        for s, e, ps, pe, counts, acts, deal, dealt, gs, parents in reversed(self.levels):
            vc = val[s + 1:e + 1]
            if dealt is not None:
                vc = vc * dealt  # a hand holding the dealt card never sees that branch
            if len(acts[i]):
                vc = vc.copy() if dealt is None else vc
                vc[acts[i]] *= sigma[s + acts[i]]
            val[parents] += np.add.reduceat(vc, gs, 0)
        m = self.mine[i]
        self.regret[m] = np.maximum(self.regret[m] + val[self.C[m]] - val[self.P[m]], 0.0)
        self.avg[m] += it * reach[i, self.P[m]] * sigma[m]

    def solve(self, iterations=200, deadline=None):
        """CFR+ with linear averaging; stops early at `deadline` (a time.monotonic() value)."""
        import time
        for _ in range(iterations):
            self.it += 1
            for i in (0, 1):
                self._pass(i, self.it)
            if deadline is not None and time.monotonic() > deadline:
                break
        return self

    def root_strategy(self, combo):
        pos = int(np.searchsorted(self.cidx, combo))
        assert self.cidx[pos] == combo, "combo left out of the solve (pass it as keep)"
        return self.root_actions(self.avg[self.root_edges, pos])

    def root_policy(self):
        """(root actions, K) average strategy; uniform for combos left out."""
        a = self.avg[self.root_edges]
        out = np.full((len(self.root_edges), K), 1.0 / len(self.root_edges))
        tot = a.sum(0)
        out[:, self.cidx] = np.where(tot > 0, a / np.maximum(tot, 1e-30), out[:, self.cidx])
        return out
