"""Heads-up turn / river subgame: the bet tree and a plain-numpy CFR+ solver (runs in Pyodide).

The tree goes from the current decision to the end of the hand; a turn subgame deals every river
card. Amounts in big blinds: `commit` = total each player has put in, `sbets` = this street's
bets, `stacks` = what remains behind. Seat 0 is the button, seat 1 (big blind) acts first after
the flop. search.Subgame solves the same tree with torch on a GPU.

The numpy solver evaluates showdowns by sorting hands by strength: a hand's value is the opponent
reach below it minus the reach above it, each read off a prefix sum, less the opponent combos that
share one of its cards (prefix sums over the 51 combos holding each card), so a showdown costs
O(1326) instead of a 1326 x 1326 matrix product.
"""
from collections import namedtuple

import numpy as np

from . import env as E
from .cards import evaluate
from .jit import njit
from .opponent import AGGR, FOLD, PASS, context

K = E.NCOMBO
COMBOS = np.array([(lo, hi) for hi in range(1, 52) for lo in range(hi)], np.int64)
Spec = namedtuple("Spec", "bets raises max_raises")  # pot fractions; all-in is always offered
RIVER_SPEC = Spec((0.33, 0.75, 1.5), (1.0,), 3)  # river subgame
TURN_SPEC = Spec((0.5, 1.0), (), 2)               # turn street of a turn subgame
LATER_RIVER_SPEC = Spec((0.5, 1.0), (), 2)        # river streets inside a turn subgame
CLASSES = {"fold": FOLD, "check": PASS, "call": PASS, "raise": AGGR, "allin": AGGR}
CARD_COMBOS = np.array([np.nonzero((COMBOS == c).any(1))[0] for c in range(52)])  # (52, 51)


def combo_index(hole):
    lo, hi = sorted(int(c) for c in hole)
    return hi * (hi - 1) // 2 + lo


@njit(cache=True)
def strengths(board, rivers, combos):
    """Hand score per (river card, combo); -1 where the combo collides with the cards."""
    out = np.full((rivers.shape[0], combos.shape[0]), -1, np.int64)
    cards = np.zeros(7, np.int64)
    nb = board.shape[0]
    for i in range(nb):
        cards[2 + i] = board[i]
    for r in range(rivers.shape[0]):
        if rivers[r] >= 0:
            cards[2 + nb] = rivers[r]
        for k in range(combos.shape[0]):
            lo, hi = combos[k, 0], combos[k, 1]
            clash = lo == rivers[r] or hi == rivers[r]
            for i in range(nb):
                if lo == board[i] or hi == board[i]:
                    clash = True
            if not clash:
                cards[0], cards[1] = lo, hi
                out[r, k] = evaluate(cards, 7)
    return out


def spot_args(state):
    """Tree arguments for the current decision of a rebuilt heads-up state (button = seat 0)."""
    fs, is_, tf, ti, hist = state
    actor = int(ti[0, E.T_ACTOR])
    sbets = [float(fs[0, p, E.F_SBET]) for p in (0, 1)]
    return dict(commit=[float(fs[0, p, E.F_COMMIT]) for p in (0, 1)], sbets=sbets,
                stacks=[float(fs[0, p, E.F_STACK]) for p in (0, 1)], actor=actor,
                checked=max(sbets) == 0 and actor == 0, last_raise=float(tf[0, E.T_LASTR]),
                raises=(max(sbets) > 0) + (min(sbets) > 0),
                cx=(int(ti[0, E.T_STREET]), (int(is_[0, 0, E.I_ST]), int(is_[0, 1, E.I_ST])),
                    int(ti[0, E.T_NRAISE]), (int(is_[0, 0, E.I_PAGG]), int(is_[0, 1, E.I_PAGG])),
                    int(ti[0, E.T_LAGG])))


class Tree:
    """Bet tree plus its edges in breadth-first order (so the edges of one node, and of one depth,
    are contiguous). cx: (street, st per seat, raises this street, previous-street aggressor
    flags, last aggressor) as in the env, for the statistics cell of each node; tilt: opponent-
    model multipliers (opponent.tilt_table) on the strategy of seat `opp`."""

    def __init__(self, board, commit, sbets, stacks, actor, checked, last_raise, raises, cx=None,
                 tilt=None, opp=None):
        self.board = [int(c) for c in board]
        self.turn = len(self.board) == 4
        self.rivers = [c for c in range(52) if c not in self.board] if self.turn else [-1]
        self.tilt, self.opp = tilt, opp
        self.nodes = []
        spec = TURN_SPEC if self.turn else RIVER_SPEC
        cx = cx or (2 if self.turn else 3, (0, 0), raises, (0, 0), -1)
        self.root = self._build(actor, list(commit), list(sbets), list(stacks), checked, last_raise, raises,
                                spec, None if self.turn else 0, cx)
        self._edges()

    def _node(self, **kw):
        self.nodes.append(kw)
        return len(self.nodes) - 1

    def _close(self, commit, stacks, card, cx):
        """Betting closed: showdown on the river, otherwise deal every river card."""
        if card is not None:
            return self._node(kind="show", commit=commit, card=card)
        lagg = cx[4]
        river = (3, (0, 0), 0, (int(lagg == 0), int(lagg == 1)), lagg)
        kids = []
        for c in range(len(self.rivers)):
            if min(stacks) <= 1e-9:
                child = self._node(kind="show", commit=list(commit), card=c)
            else:
                child = self._build(1, list(commit), [0.0, 0.0], list(stacks), False, 0.0, 0, LATER_RIVER_SPEC, c,
                                    river)
            kids.append(("deal", c, child))
        return self._node(kind="chance", kids=kids)

    def _build(self, a, commit, sbets, stacks, checked, last_raise, raises, spec, card, cx):
        b = 1 - a
        to_call = sbets[b] - sbets[a]
        pot = commit[0] + commit[1]
        street, st, nraise, pagg, lagg = cx
        cell = street * E.NCTX + context(street, a, to_call, st, nraise, pagg)
        passed = list(st)
        passed[a] = max(st[a], 1)
        cx_pass = (street, tuple(passed), nraise, pagg, lagg)
        aggr = list(st)
        aggr[a] = 2
        cx_aggr = (street, tuple(aggr), nraise + 1, pagg, a)
        kids = []
        if to_call > 1e-9:
            kids.append(("fold", 0.0, self._node(kind="fold", folder=a, commit=list(commit))))
            pay = min(to_call, stacks[a])
            c2, s2, st2 = list(commit), list(sbets), list(stacks)
            c2[a] += pay
            s2[a] += pay
            st2[a] -= pay
            kids.append(("call", s2[a], self._close(c2, st2, card, cx_pass)))
            allowed, fracs = raises < spec.max_raises and stacks[a] > to_call and stacks[b] > 0, spec.raises
        else:
            if checked:
                kids.append(("check", sbets[a], self._close(list(commit), list(stacks), card, cx_pass)))
            else:
                kids.append(("check", sbets[a], self._build(b, list(commit), list(sbets), list(stacks), True,
                                                            last_raise, raises, spec, card, cx_pass)))
            allowed, fracs = stacks[a] > 0 and stacks[b] > 0, spec.bets
        if allowed:
            allin_to = sbets[a] + stacks[a]
            min_to = sbets[b] + max(last_raise, 1.0)
            sizes = sorted({min(max(sbets[b] + f * (pot + to_call), min_to), allin_to) for f in fracs} | {allin_to})
            for size in sizes:
                add = size - sbets[a]
                c2, s2, st2 = list(commit), list(sbets), list(stacks)
                c2[a] += add
                s2[a] = size
                st2[a] -= add
                child = self._build(b, c2, s2, st2, False, size - sbets[b], raises + 1, spec, card, cx_aggr)
                kids.append(("allin" if size >= allin_to - 1e-9 else "raise", size, child))
        return self._node(kind="act", actor=a, kids=kids, cell=cell)

    def _edges(self):
        nodes = self.nodes
        depth, order, edges = {self.root: 0}, [self.root], []
        for n in order:
            if nodes[n]["kind"] in ("act", "chance"):
                actor = nodes[n].get("actor", 2)
                for label, x, c in nodes[n]["kids"]:
                    depth[c] = depth[n] + 1
                    m = 1.0
                    if self.tilt is not None and actor == self.opp:
                        m = float(self.tilt[nodes[n]["cell"], CLASSES[label]])
                    edges.append((n, c, actor, depth[n], len(nodes[n]["kids"]), x if actor == 2 else -1, m))
                    order.append(c)
        self.P, self.C, self.A, self.D, self.NK, self.CARD, self.TILT = (np.array(x) for x in zip(*edges))
        self.root_edges = np.nonzero(self.P == self.root)[0]
        folds = [n for n in range(len(nodes)) if nodes[n]["kind"] == "fold"]
        coef = np.zeros((2, len(folds), 1))
        for j, n in enumerate(folds):
            c = nodes[n]["commit"]
            for i in (0, 1):
                coef[i, j] = -c[i] if nodes[n]["folder"] == i else c[1 - i]
        self.folds, self.fold_coef = np.array(folds, np.int64), coef
        shows = [[] for _ in self.rivers]
        for n in range(len(nodes)):
            if nodes[n]["kind"] == "show":
                shows[nodes[n]["card"]].append(n)
        assert len({len(s) for s in shows}) == 1, "river subtrees differ"
        self.shows = np.array(shows, np.int64)  # (cards, showdowns per card)
        self.stake = np.array([[min(nodes[n]["commit"]) for n in s] for s in shows])[:, :, None]
        self.n = len(nodes)

    def strength(self):
        return strengths(np.array(self.board, np.int64), np.array(self.rivers, np.int64), COMBOS)

    def root_actions(self, avg_row):
        """[(label, street total in big blinds, probability)] from the root edges' average weights."""
        kids = self.nodes[self.root]["kids"]
        total = avg_row.sum()
        p = avg_row / total if total > 0 else np.full(len(kids), 1.0 / len(kids))
        return [(label, size, float(q)) for (label, size, _), q in zip(kids, p)]


class NumpySubgame(Tree):
    def __init__(self, board, ranges, *args, **kw):
        super().__init__(board, *args, **kw)
        strength = self.strength()                       # (cards, K)
        self.valid = strength >= 0
        self.ranges = np.asarray(ranges, np.float64)
        # showdown lookups per river card: global order, and per held card the 51 combos sorted
        nc = len(self.rivers)
        self.order = np.argsort(strength, 1, kind="stable")
        ss = np.take_along_axis(strength, self.order, 1)
        self.lo = np.stack([np.searchsorted(ss[c], strength[c], "left") for c in range(nc)])
        self.hi = np.stack([np.searchsorted(ss[c], strength[c], "right") for c in range(nc)])
        sc = strength[:, CARD_COMBOS]                    # (cards, 52, 51)
        corder = np.argsort(sc, 2, kind="stable")
        self.card_sorted = np.take_along_axis(np.broadcast_to(CARD_COMBOS, sc.shape), corder, 2).reshape(nc, -1)
        css = np.take_along_axis(sc, corder, 2)
        pos = np.zeros((2, 2, nc, K), np.int64)          # (low / high card, left / right, card, combo)
        first = COMBOS[CARD_COMBOS, 0] == np.arange(52)[:, None]
        for c in range(nc):
            for x in range(52):
                ks, f = CARD_COMBOS[x], first[x]
                for side, how in enumerate(("left", "right")):
                    p = np.searchsorted(css[c, x], sc[c, x], how)
                    pos[0, side, c, ks[f]] = p[f]
                    pos[1, side, c, ks[~f]] = p[~f]
        self.card_pos = [(COMBOS[:, j] * 52 + pos[j, 0], COMBOS[:, j] * 52 + pos[j, 1], COMBOS[:, j])
                         for j in (0, 1)]
        self.deal = self.valid / (44.0 if self.turn else 1.0)
        self.held = np.zeros((K, 52))
        self.held[np.arange(K), COMBOS[:, 0]] = 1
        self.held[np.arange(K), COMBOS[:, 1]] = 1
        board_ok = np.array([lo not in self.board and hi not in self.board for lo, hi in COMBOS])
        self.board_ok = board_ok.astype(np.float64)
        self.ranges = self.ranges * self.board_ok
        self._prepare()

    def _prepare(self):
        E_ = len(self.P)
        self.starts = np.r_[0, np.nonzero(np.diff(self.P))[0] + 1]  # first edge of each parent
        self.counts = np.diff(np.r_[self.starts, E_])
        self.uniform = (1.0 / self.NK)[:, None]
        self.levels = []
        for d in range(self.D.max() + 1):
            sel = np.nonzero(self.D == d)[0]
            s, e = sel[0], sel[-1] + 1
            P, C, A = self.P[s:e], self.C[s:e], self.A[s:e][:, None]
            deal = None
            if (self.CARD[s:e] >= 0).any():
                deal = np.ones((e - s, K))
                ch = np.nonzero(self.CARD[s:e] >= 0)[0]
                deal[ch] = self.deal[self.CARD[s:e][ch]]
            gs = np.r_[0, np.nonzero(np.diff(P))[0] + 1]
            self.levels.append((s, e, P, C, A, deal, gs, P[gs]))
        self.tilt_e = self.TILT[:, None] if self.tilt is not None else None
        self.regret = np.zeros((E_, K))
        self.avg = np.zeros((E_, K))
        self.it = 0

    def _group_sum(self, x):
        return np.repeat(np.add.reduceat(x, self.starts, 0), self.counts, 0)

    def _fold_values(self, q):
        """sum of q over combos sharing no card with each combo (the board is already excluded)."""
        card = q @ self.held                             # (F, 52)
        return (q.sum(1, keepdims=True) - card[:, COMBOS[:, 0]] - card[:, COMBOS[:, 1]] + q) * self.board_ok

    def _show_values(self, q):
        """q: (cards, T, K) opponent reach at the showdowns; returns reach below minus above."""
        nc, T, _ = q.shape
        srt = np.take_along_axis(q, self.order[:, None, :], 2)
        cum = np.concatenate([np.zeros((nc, T, 1)), np.cumsum(srt, 2)], 2)
        total = cum[:, :, -1:]
        win = np.take_along_axis(cum, self.lo[:, None, :], 2)
        lose = total - np.take_along_axis(cum, self.hi[:, None, :], 2)
        held = np.take_along_axis(q, self.card_sorted[:, None, :], 2).reshape(nc, T, 52, 51)
        ccum = np.concatenate([np.zeros((nc, T, 52, 1)), np.cumsum(held, 3)], 3)
        ctot = ccum[:, :, :, -1]
        ccum = ccum.reshape(nc, T, 52 * 52)
        for lo, hi, x in self.card_pos:
            win -= np.take_along_axis(ccum, lo[:, None, :], 2)
            lose -= ctot[:, :, x] - np.take_along_axis(ccum, hi[:, None, :], 2)
        return (win - lose) * self.valid[:, None, :]

    def _pass(self, i, it):
        pos = np.maximum(self.regret, 0.0)
        total = self._group_sum(pos)
        sigma = np.where(total > 0, pos / np.maximum(total, 1e-300), self.uniform)
        if self.tilt_e is not None:
            sigma = sigma * self.tilt_e
            sigma /= np.maximum(self._group_sum(sigma), 1e-300)
        reach = np.zeros((2, self.n, K))
        reach[0, self.root], reach[1, self.root] = self.ranges[0], self.ranges[1]
        for s, e, P, C, A, deal, gs, parents in self.levels:
            sg = sigma[s:e]
            m0, m1 = np.where(A == 0, sg, 1.0), np.where(A == 1, sg, 1.0)
            if deal is not None:
                m0, m1 = m0 * deal, m1 * deal
            reach[0, C] = reach[0, P] * m0
            reach[1, C] = reach[1, P] * m1
        q = reach[1 - i]
        val = np.zeros((self.n, K))
        if len(self.folds):
            val[self.folds] = self.fold_coef[i] * self._fold_values(q[self.folds])
        val[self.shows] = self.stake * self._show_values(q[self.shows])
        for s, e, P, C, A, deal, gs, parents in reversed(self.levels):
            vc = val[C]
            if deal is not None:
                vc = vc * (deal > 0)  # a hand holding the dealt river card never sees that river
            val[parents] += np.add.reduceat(np.where(A == i, sigma[s:e] * vc, vc), gs, 0)
        mine = (self.A == i)[:, None]
        self.regret = np.where(mine, np.maximum(self.regret + val[self.C] - val[self.P], 0.0), self.regret)
        self.avg += np.where(mine, it * reach[i, self.P] * sigma, 0.0)

    def solve(self, iterations=200, deadline=None):
        """CFR+ with linear averaging; stops early at `deadline` (a time.monotonic() value)."""
        import time
        for _ in range(iterations):
            self.it += 1
            for i in (0, 1):
                self._pass(i, self.it)
            if deadline is not None and time.monotonic() > deadline:
                break
        return self

    def root_strategy(self, combo):
        return self.root_actions(self.avg[self.root_edges, combo])
