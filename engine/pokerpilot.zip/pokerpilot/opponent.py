"""Opponent model for search: how far an opponent's action frequencies sit from the blueprint's.

The session statistics already count, per (street, context) cell (see env.NCTX), how often a
player had a decision, bet / raised, and folded. The blueprint's own rates in the same cells come
from self-play (tools/baseline_rates.py). Shrinking the observed rates toward the blueprint rates
by PRIOR opportunities gives an estimate that starts at the blueprint (no deviation, plain GTO
search) and moves only as evidence accumulates; the ratio estimate / blueprint, capped, is a
per-cell multiplier on the opponent's fold, check-call and bet-raise probabilities.
"""
import json

import numpy as np

from . import env as E

PRIOR = 20.0           # opportunities at which observed and blueprint rates weigh equally
CAP = (1 / 3, 3.0)     # largest deviation from the blueprint per action class
FOLD, PASS, AGGR = 0, 1, 2


def load_baseline(path):
    with open(path, encoding="utf-8") as f:
        b = json.load(f)
    n = np.maximum(np.array(b["gn"], float), 1.0)
    return np.array(b["gf"], float) / n, np.array(b["ga"], float) / n


def tilt_table(counters, baseline):
    """counters: one player's session statistics (env fields F_HANDS..F_BOT); returns (NCELL, 3)
    multipliers for fold, check / call and bet / raise. Lifetime rates are shrunk toward the
    blueprint, then the recent-window rates toward the lifetime ones."""
    ef, ea = baseline
    cell = lambda field, off=0: counters[field - E.F_HANDS + off:field - E.F_HANDS + off + E.NCELL]
    f = (cell(E.F_GF) + PRIOR * ef) / (cell(E.F_GN) + PRIOR)
    a = (cell(E.F_GA) + PRIOR * ea) / (cell(E.F_GN) + PRIOR)
    if len(counters) >= E.F_BOT - E.F_HANDS:
        o, w = E.F_REC - E.F_HANDS, E.RECENT_PRIOR
        f = (cell(E.F_GF, o) + w * f) / (cell(E.F_GN, o) + w)
        a = (cell(E.F_GA, o) + w * a) / (cell(E.F_GN, o) + w)
    out = np.ones((E.NCELL, 3))
    ratio = lambda x, e: np.where(e > 1e-3, np.clip(x / np.maximum(e, 1e-3), *CAP), 1.0)
    out[:, FOLD] = ratio(f, ef)
    out[:, AGGR] = ratio(a, ea)
    out[:, PASS] = ratio(1 - f - a, 1 - ef - ea)
    return out


def context(street, a, to_call, st, nraise, pagg):
    """Same as env._context for a heads-up decision after the flop."""
    if street == 0 and nraise == 0:
        return 0 if to_call > 1e-9 else 1
    if to_call <= 1e-9:
        return 0 if pagg[a] else 1
    if st[a] == 2:
        return 4
    if st[a] == 1:
        return 3
    return 2 if nraise <= 1 else 5


def action_class(menu_index):
    if menu_index == E.A_FOLD:
        return FOLD
    return PASS if menu_index == E.A_CALL else AGGR
