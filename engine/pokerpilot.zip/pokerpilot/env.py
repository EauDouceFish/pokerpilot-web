"""Vectorized 2-6 player no-limit hold'em tables (numba).

Money is in big blinds (SB 0.5, BB 1). Every table always has exactly one
player to act; finished hands are settled and redealt inside `step`.

Agent ids per seat: 0 = learner network, 1..K = frozen snapshot slot,
negative = scripted style bot (-1 - style index).
"""
import math

import numpy as np

from .cards import evaluate, equity_mc, preflop_class
from .jit import njit, prange

MAXP = 9
FRACS = np.array([0.25, 0.33, 0.5, 0.66, 0.75, 0.85, 1.0, 1.25, 1.5, 2.0, 3.0])
NFRAC = len(FRACS)
A_FOLD, A_CALL, A_RAISE0 = 0, 1, 2
A_ALLIN = A_RAISE0 + NFRAC
NA = A_ALLIN + 1
# History token: relative position 0..5 one-hot in 0..5 and 6..8 in 18..20 (appended for 7-9 seats).
# Global features 45..50 likewise hold player counts 7..9 and positions 6..8, so older
# (2-6 seat) checkpoints keep their meaning when their input layers are zero-padded.
HLEN, FH = 24, 21
NG, NS = 51, 61
MAXD = 64
MIN_STACK, MAX_STACK = 20.0, 200.0
STATS_MIN_HANDS = 10.0   # opponents are unknown until this many shared hands
STATS_PRIOR_HANDS = 20.0  # shrinkage weight toward the prior
PRO_SHARE = 0.4          # snapshot seats without style tilt

# per-seat float fields
F_STACK, F_START, F_COMMIT, F_SBET = 0, 1, 2, 3
F_HANDS, F_VPIP, F_PFR, F_AGG, F_PASS, F_FACED, F_FOLDF = 4, 5, 6, 7, 8, 9, 10
# Session stat grid, one cell per (street, context), index street * NCTX + context.
# Contexts at a decision (see _context):
#   0 unbet pot, actor was the previous street's last aggressor (c-bet / barrel);
#     preflop: unopened pot facing the blinds (open)
#   1 unbet pot otherwise (donk / probe / stab); preflop: big blind option after limps
#   2 first decision facing a bet or one raise (raise / fold vs bet; preflop 3-bet)
#   3 facing a bet after checking or calling this street (check-raise; preflop limp-raise)
#   4 facing a raise after betting or raising this street (re-raise / fold to raise; 4-bet)
#   5 first decision facing two or more raises (cold re-raise)
NCTX = 6
NCELL = 4 * NCTX
F_GN = 11                # opportunities per cell
F_GA = F_GN + NCELL      # bets / raises per cell
F_GF = F_GA + NCELL      # folds per cell
F_SZ = F_GF + NCELL      # sum of bet / raise sizes (pot fractions) per street
F_SAWF, F_WTSD = F_SZ + 4, F_SZ + 5
# showdowns after a river bet / raise and how many showed high card;
# showdowns after a river call and how many showed one pair or worse
F_RSD, F_RSDW, F_CSD, F_CSDW = F_SZ + 6, F_SZ + 7, F_SZ + 8, F_SZ + 9
# 16 parameters for style bots (see BOT_PARAMS) or, for snapshot seats,
# logit tilt (fold, call, raise, size slope) in the first four
F_BOT = F_SZ + 10
BOT_PARAMS = ["tight", "aggr", "size", "slack", "bluff_pre", "bluff_flop", "bluff_turn", "bluff_river",
              "threebet", "fold_3bet", "cbet", "barrel", "donk", "check_raise", "slowplay", "fold_raise"]
NBOT = len(BOT_PARAMS)
NFS = F_BOT + NBOT
# per-seat int fields; I_ST this street: 0 not acted, 1 checked / called, 2 bet / raised;
# I_PAGG last aggressor of the previous street; I_RAGG / I_RCALL bet or called on the river
I_H0, I_H1, I_FOLD, I_ALLIN, I_NEED, I_CANR, I_AGENT, I_HVPIP, I_HPFR = range(9)
I_ST, I_PAGG, I_SAWF, I_RAGG, I_RCALL = range(9, 14)
NIS = 14
# stat priors (population guesses) for bet / raise and fold frequency per cell
PRIOR_GA = np.array([
    [0.25, 0.15, 0.08, 0.05, 0.10, 0.04],
    [0.55, 0.25, 0.10, 0.12, 0.12, 0.05],
    [0.50, 0.30, 0.08, 0.10, 0.10, 0.04],
    [0.45, 0.30, 0.06, 0.08, 0.08, 0.03],
])
PRIOR_GF = np.array([
    [0.0, 0.0, 0.55, 0.40, 0.50, 0.75],
    [0.0, 0.0, 0.45, 0.45, 0.45, 0.70],
    [0.0, 0.0, 0.45, 0.45, 0.40, 0.65],
    [0.0, 0.0, 0.50, 0.50, 0.40, 0.60],
])
CELL_PRIOR = 10.0  # shrinkage weight (opportunities) for grid cells and showdown stats
# table float fields
T_MAXBET, T_LASTR = 0, 1
NTF = 2
# table int fields
T_NP, T_BTN, T_STREET, T_ACTOR, T_BN, T_B0 = 0, 1, 2, 3, 4, 5  # board 5..9
T_SESSION, T_VIS, T_KIND, T_NRAISE, T_DEC, T_LAGG = 10, 11, 12, 13, 14, 15
NTI = 16

# table kinds
K_SELF, K_MIXED, K_BOTS, K_SNAPS, K_EXPLOIT = 0, 1, 2, 3, 4
NKIND = 5
# league config: snapshot count, exploiter count, exploit-table mode, forced bot style (-1 random).
# Agent slots: 1..n_exploit are exploiters, then snapshots. Exploit tables seat one special
# seat against the rest: mode 0 = learner vs slot 1 (training an exploiter),
# mode 1 = one exploiter vs learner seats (training the main policy against exploiters).
# L_NMIN..L_NMAX: players per table drawn uniformly in this range at each reseat.
# L_PRO: percent of snapshot seats playing without style tilt.
L_SNAP, L_EXP, L_MODE, L_STYLE, L_NMIN, L_NMAX, L_PRO = 0, 1, 2, 3, 4, 5, 6
# results per table: [kind*2] learner bb won, [kind*2+1] learner seat-hands, [10] hands
NRES = 2 * NKIND + 1

# style bots, columns as BOT_PARAMS (bluffs per street, size 0..1, negative slack also folds
# marginal hands postflop); tight < -1 => uniformly random legal actions
STYLE_NAMES = ["nit", "tag", "lag", "station", "maniac", "random", "barrel",
               "threebettor", "trapper", "folder", "riverbluffer"]
STYLES = np.array([
    [0.8, 0.3, 0.5, -0.1, 0.01, 0.02, 0.02, 0.01, 0.02, 0.6, 0.3, 0.2, 0.02, 0.02, 0.2, 0.6],
    [0.4, 0.7, 0.5, 0.0, 0.03, 0.06, 0.05, 0.04, 0.06, 0.4, 0.5, 0.35, 0.05, 0.05, 0.05, 0.4],
    [0.0, 0.85, 0.6, 0.1, 0.1, 0.15, 0.12, 0.1, 0.12, 0.25, 0.6, 0.45, 0.1, 0.08, 0.0, 0.25],
    [0.1, 0.1, 0.4, 0.45, 0.01, 0.02, 0.02, 0.01, 0.01, 0.1, 0.1, 0.05, 0.05, 0.02, 0.4, 0.05],
    [-0.3, 1.0, 0.9, 0.3, 0.4, 0.45, 0.4, 0.35, 0.25, 0.05, 0.7, 0.6, 0.3, 0.1, 0.0, 0.05],
    [-9.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0.3, 0.9, 0.6, 0.1, 0.05, 0.4, 0.35, 0.1, 0.08, 0.3, 0.7, 0.6, 0.15, 0.25, 0.0, 0.15],
    [0.3, 0.6, 0.6, 0.0, 0.05, 0.06, 0.05, 0.04, 0.3, 0.3, 0.5, 0.35, 0.05, 0.05, 0.05, 0.4],
    [0.3, 0.6, 0.5, 0.1, 0.03, 0.05, 0.05, 0.04, 0.05, 0.4, 0.3, 0.2, 0.03, 0.35, 0.5, 0.3],
    [0.3, 0.6, 0.5, -0.6, 0.04, 0.06, 0.05, 0.04, 0.05, 0.8, 0.6, 0.4, 0.05, 0.02, 0.1, 0.8],
    [0.3, 0.6, 0.7, 0.0, 0.03, 0.05, 0.06, 0.35, 0.06, 0.4, 0.5, 0.4, 0.05, 0.05, 0.05, 0.4],
])
# independent per-parameter ranges for randomized bots (half of non-forced bot seats)
BOT_LO = np.array([-0.3, 0.0, 0.2, -0.6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
BOT_HI = np.array([0.9, 1.0, 0.9, 0.45, 0.4, 0.4, 0.4, 0.4, 0.3, 0.8, 0.9, 0.8, 0.4, 0.35, 0.6, 0.8])


class Env:
    def __init__(self, n_tables, preflop_eq, seed=0):
        B = n_tables
        self.B = B
        self.fs = np.zeros((B, MAXP, NFS))
        self.is_ = np.zeros((B, MAXP, NIS), np.int64)
        self.tf = np.zeros((B, NTF))
        self.ti = np.zeros((B, NTI), np.int64)
        self.hist = np.zeros((B, HLEN, FH), np.float32)
        self.deck = np.tile(np.arange(52, dtype=np.int64), (B, 1))
        self.pend_idx = np.zeros((B, MAXP, MAXD), np.int64)
        self.pend_n = np.zeros((B, MAXP), np.int64)
        self.res = np.zeros((B, NRES))
        self.preflop_eq = preflop_eq
        self.G = np.zeros((B, NG), np.float32)
        self.C = np.zeros((B, 7), np.int64)
        self.S = np.zeros((B, MAXP, NS), np.float32)
        self.M = np.zeros((B, NA), np.bool_)
        self.EQ = np.zeros(B)
        self.actor_agent = np.zeros(B, np.int64)
        self.actor_seat = np.zeros(B, np.int64)
        self.kind_probs = np.array([1.0, 0, 0, 0, 0])
        self.league = np.array([0, 0, 0, -1, 2, 6, int(PRO_SHARE * 100)], np.int64)
        _seed(seed)
        self.ti[:, T_SESSION] = 0
        reset_all(*self.state(), self.kind_probs, self.league)

    def state(self):
        return self.fs, self.is_, self.tf, self.ti, self.hist, self.deck

    def set_league(self, kind_probs, n_snap, reseat=False, n_exploit=0, exploit_mode=0, style=-1,
                   players=None):
        self.kind_probs = np.asarray(kind_probs, float) / np.sum(kind_probs)
        if players is not None:
            self.league[L_NMIN:L_NMAX + 1] = players
        self.league[:L_NMIN] = (n_snap, n_exploit, exploit_mode, style)
        if reseat:
            self.pend_n[:] = 0
            self.ti[:, T_SESSION] = 0
            reset_all(*self.state(), self.kind_probs, self.league)

    def observe(self, eq_samples=48):
        build_obs(*self.state(), self.preflop_eq, eq_samples, self.G, self.C, self.S,
                  self.M, self.EQ, self.actor_agent, self.actor_seat)

    def bot_actions(self, actions):
        bot_policy(self.fs, self.is_, self.tf, self.ti, self.M, self.EQ, actions)

    def register(self, tables, buf_idx):
        register_pending(self.ti, self.pend_idx, self.pend_n, tables, buf_idx)

    def step(self, actions, buf_ret, buf_state):
        step_all(*self.state(), actions, self.pend_idx, self.pend_n, buf_ret, buf_state,
                 self.res, self.kind_probs, self.league)

    def take_results(self):
        r = self.res.sum(axis=0)
        self.res[:] = 0
        return r


@njit(cache=True)
def _seed(s):
    np.random.seed(s)


# ---------------------------------------------------------------- dealing

@njit(cache=True)
def _reseat(t, fs, is_, ti, kind_probs, league):
    n_snap = league[L_SNAP]
    n_exp = league[L_EXP]
    n = np.random.randint(league[L_NMIN], league[L_NMAX] + 1)
    r = np.random.random()
    kind = 0
    acc = 0.0
    for k in range(NKIND):
        acc += kind_probs[k]
        if r < acc:
            kind = k
            break
    if (kind == K_SNAPS and n_snap == 0) or (kind == K_EXPLOIT and n_exp == 0):
        kind = K_SELF
    ti[t, T_NP] = n
    ti[t, T_KIND] = kind
    ti[t, T_BTN] = np.random.randint(n)
    ti[t, T_SESSION] = np.random.randint(30, 300)
    ti[t, T_VIS] = 1 if np.random.random() < 0.7 else 0
    learner = np.random.randint(n)
    for p in range(MAXP):
        for f in range(F_HANDS, NFS):
            fs[t, p, f] = 0.0
        if p >= n:
            is_[t, p, I_AGENT] = -99
            continue
        if kind == K_EXPLOIT:
            if league[L_MODE] == 0:
                agent = 0 if p == learner else 1
            else:
                agent = 1 + np.random.randint(n_exp) if p == learner else 0
        elif kind == K_SELF or p == learner:
            agent = 0
        elif kind == K_SNAPS or (kind == K_MIXED and n_snap > 0 and np.random.random() < 0.5):
            agent = 1 + n_exp + np.random.randint(max(n_snap, 1))
            if np.random.random() * 100 >= league[L_PRO]:
                for j in range(4):
                    fs[t, p, F_BOT + j] = 0.7 * np.random.randn()
        else:
            agent = 99
        if agent == 99:
            style = league[L_STYLE] if league[L_STYLE] >= 0 else np.random.randint(STYLES.shape[0])
            agent = -1 - style
            if league[L_STYLE] < 0 and STYLES[style, 0] >= -1 and np.random.random() < 0.5:
                for j in range(NBOT):
                    fs[t, p, F_BOT + j] = BOT_LO[j] + (BOT_HI[j] - BOT_LO[j]) * np.random.random()
            else:
                for j in range(NBOT):
                    v = STYLES[style, j]
                    fs[t, p, F_BOT + j] = v if v < -1 else v * (1.0 + 0.15 * np.random.randn())
        is_[t, p, I_AGENT] = agent


@njit(cache=True)
def _post(t, p, amount, fs, is_):
    a = min(amount, fs[t, p, F_STACK])
    fs[t, p, F_STACK] -= a
    fs[t, p, F_SBET] += a
    fs[t, p, F_COMMIT] += a
    if fs[t, p, F_STACK] <= 1e-9:
        fs[t, p, F_STACK] = 0.0
        is_[t, p, I_ALLIN] = 1


@njit(cache=True)
def _find_next(t, start, fs, is_, ti):
    n = ti[t, T_NP]
    for k in range(1, n + 1):
        p = (start + k) % n
        if is_[t, p, I_FOLD] == 0 and is_[t, p, I_ALLIN] == 0 and is_[t, p, I_NEED] == 1:
            return p
    return -1


@njit(cache=True)
def _start_hand(t, fs, is_, tf, ti, hist, deck, stacks, forced_seat, f0, f1):
    """Deal a hand with current seating. stacks[p] > 0 overrides random depth;
    forced_seat >= 0 receives hole cards f0, f1."""
    n = ti[t, T_NP]
    ti[t, T_BTN] = (ti[t, T_BTN] + 1) % n
    d = deck[t]
    need = 2 * n + 5
    if forced_seat >= 0:
        # move forced cards to the front, then shuffle the rest
        for i in range(52):
            if d[i] == f0:
                d[i] = d[0]
                d[0] = f0
                break
        for i in range(52):
            if d[i] == f1:
                d[i] = d[1]
                d[1] = f1
                break
        for i in range(2, need):
            j = i + np.random.randint(52 - i)
            tmp = d[i]
            d[i] = d[j]
            d[j] = tmp
    else:
        for i in range(need):
            j = i + np.random.randint(52 - i)
            tmp = d[i]
            d[i] = d[j]
            d[j] = tmp
    pos = 0
    if forced_seat >= 0:
        is_[t, forced_seat, I_H0] = d[0]
        is_[t, forced_seat, I_H1] = d[1]
        pos = 2
    for p in range(n):
        if p == forced_seat:
            continue
        is_[t, p, I_H0] = d[pos]
        is_[t, p, I_H1] = d[pos + 1]
        pos += 2
    for i in range(5):
        ti[t, T_B0 + i] = d[2 * n + i]
    ti[t, T_BN] = 0
    lo = math.log(MIN_STACK)
    hi = math.log(MAX_STACK)
    for p in range(MAXP):
        for f in range(4):
            fs[t, p, f] = 0.0
        for f in range(I_FOLD, NIS):
            if f != I_AGENT:
                is_[t, p, f] = 0
        if p >= n:
            is_[t, p, I_FOLD] = 1
            continue
        s = stacks[p] if stacks[p] > 0 else math.exp(lo + (hi - lo) * np.random.random())
        s = round(s * 2.0) / 2.0
        fs[t, p, F_STACK] = s
        fs[t, p, F_START] = s
        is_[t, p, I_NEED] = 1
        is_[t, p, I_CANR] = 1
        fs[t, p, F_HANDS] += 1.0
    btn = ti[t, T_BTN]
    if n == 2:
        sb = btn
        bb = (btn + 1) % 2
    else:
        sb = (btn + 1) % n
        bb = (btn + 2) % n
    _post(t, sb, 0.5, fs, is_)
    _post(t, bb, 1.0, fs, is_)
    tf[t, T_MAXBET] = 1.0
    tf[t, T_LASTR] = 1.0
    ti[t, T_STREET] = 0
    ti[t, T_NRAISE] = 0
    ti[t, T_DEC] = 0
    ti[t, T_LAGG] = -1
    for i in range(HLEN):
        for j in range(FH):
            hist[t, i, j] = 0.0
    ti[t, T_ACTOR] = _find_next(t, bb, fs, is_, ti)


@njit(cache=True)
def _new_hand(t, fs, is_, tf, ti, hist, deck, kind_probs, league):
    if ti[t, T_SESSION] <= 0:
        _reseat(t, fs, is_, ti, kind_probs, league)
    ti[t, T_SESSION] -= 1
    _start_hand(t, fs, is_, tf, ti, hist, deck, np.zeros(MAXP), -1, 0, 0)


@njit(cache=True, parallel=True)
def reset_all(fs, is_, tf, ti, hist, deck, kind_probs, league):
    for t in prange(fs.shape[0]):
        _new_hand(t, fs, is_, tf, ti, hist, deck, kind_probs, league)


@njit(cache=True)
def force_hand(fs, is_, tf, ti, hist, deck, t, n, btn, stack, seat, c0, c1):
    """Deterministic seating for probes: n players, all `stack` deep, all
    learner seats, `seat` holds (c0, c1). Button lands on `btn`."""
    ti[t, T_NP] = n
    ti[t, T_KIND] = K_SELF
    ti[t, T_VIS] = 0
    ti[t, T_SESSION] = 1 << 30
    ti[t, T_BTN] = (btn - 1) % n
    for p in range(MAXP):
        is_[t, p, I_AGENT] = 0 if p < n else -99
        for f in range(F_HANDS, NFS):
            fs[t, p, f] = 0.0
    stacks = np.zeros(MAXP)
    for p in range(n):
        stacks[p] = stack
    _start_hand(t, fs, is_, tf, ti, hist, deck, stacks, seat, c0, c1)


# ---------------------------------------------------------------- rules

@njit(cache=True)
def _pot(t, fs):
    s = 0.0
    for p in range(MAXP):
        s += fs[t, p, F_COMMIT]
    return s


@njit(cache=True)
def _legal(t, fs, is_, tf, ti, mask):
    for i in range(NA):
        mask[i] = False
    a = ti[t, T_ACTOR]
    n = ti[t, T_NP]
    to_call = tf[t, T_MAXBET] - fs[t, a, F_SBET]
    stack = fs[t, a, F_STACK]
    mask[A_FOLD] = to_call > 1e-9
    mask[A_CALL] = True
    others = 0
    for p in range(n):
        if p != a and is_[t, p, I_FOLD] == 0 and is_[t, p, I_ALLIN] == 0:
            others += 1
    if is_[t, a, I_CANR] == 1 and stack > to_call + 1e-9 and others > 0:
        pot = _pot(t, fs)
        maxbet = tf[t, T_MAXBET]
        minr = maxbet + tf[t, T_LASTR]
        allin_to = fs[t, a, F_SBET] + stack
        for i in range(NFRAC):
            r = maxbet + FRACS[i] * (pot + to_call)
            if r >= minr - 1e-9 and r < allin_to - 1e-9:
                mask[A_RAISE0 + i] = True
        mask[A_ALLIN] = True


@njit(cache=True)
def _effective(t, p, fs, ti):
    n = ti[t, T_NP]
    m = 0.0
    for q in range(n):
        if q != p and fs[t, q, F_START] > m:
            m = fs[t, q, F_START]
    return min(fs[t, p, F_START], m)


@njit(cache=True)
def _apply(t, act, fs, is_, tf, ti, hist):
    a = ti[t, T_ACTOR]
    maxbet = tf[t, T_MAXBET]
    to_call = maxbet - fs[t, a, F_SBET]
    raise_to = 0.0
    kind = 0  # 0 fold 1 check 2 call 3 raise 4 allin
    if act == A_FOLD:
        kind = 0
    elif act == A_CALL:
        kind = 2 if to_call > 1e-9 else 1
    elif act == A_ALLIN:
        raise_to = fs[t, a, F_SBET] + fs[t, a, F_STACK]
        kind = 4
    else:
        raise_to = maxbet + FRACS[act - A_RAISE0] * (_pot(t, fs) + to_call)
        kind = 3
    _apply_kind(t, kind, raise_to, fs, is_, tf, ti, hist)


@njit(cache=True)
def _context(t, a, is_, tf, ti, fs):
    """Decision context of the actor (see NCTX)."""
    to_call = tf[t, T_MAXBET] - fs[t, a, F_SBET]
    if ti[t, T_STREET] == 0 and ti[t, T_NRAISE] == 0:
        return 0 if to_call > 1e-9 else 1
    if to_call <= 1e-9:
        return 0 if is_[t, a, I_PAGG] == 1 else 1
    st = is_[t, a, I_ST]
    if st == 2:
        return 4
    if st == 1:
        return 3
    return 2 if ti[t, T_NRAISE] <= 1 else 5


@njit(cache=True)
def _apply_kind(t, kind, raise_to, fs, is_, tf, ti, hist):
    """Apply an action of `kind` (raise_to used for kinds 3, 4) for the current actor."""
    a = ti[t, T_ACTOR]
    n = ti[t, T_NP]
    street = ti[t, T_STREET]
    maxbet = tf[t, T_MAXBET]
    to_call = maxbet - fs[t, a, F_SBET]
    pot = _pot(t, fs)
    stack = fs[t, a, F_STACK]
    # statistics
    cell = street * NCTX + _context(t, a, is_, tf, ti, fs)
    fs[t, a, F_GN + cell] += 1.0
    if kind >= 3:
        fs[t, a, F_GA + cell] += 1.0
        fs[t, a, F_SZ + street] += min((raise_to - maxbet) / max(pot, 1e-9), 3.0)
        is_[t, a, I_ST] = 2
        ti[t, T_LAGG] = a
    elif kind == 0:
        fs[t, a, F_GF + cell] += 1.0
    elif is_[t, a, I_ST] == 0:
        is_[t, a, I_ST] = 1
    if street == 3:
        if kind >= 3:
            is_[t, a, I_RAGG] = 1
        elif kind == 2:
            is_[t, a, I_RCALL] = 1
    if street == 0:
        if kind == 2 or kind >= 3:
            is_[t, a, I_HVPIP] = 1
        if kind >= 3:
            is_[t, a, I_HPFR] = 1
    else:
        if to_call > 1e-9:
            fs[t, a, F_FACED] += 1.0
            if kind == 0:
                fs[t, a, F_FOLDF] += 1.0
        if kind >= 3:
            fs[t, a, F_AGG] += 1.0
        elif kind == 2:
            fs[t, a, F_PASS] += 1.0
    # history token
    for i in range(HLEN - 1):
        for j in range(FH):
            hist[t, i, j] = hist[t, i + 1, j]
    for j in range(FH):
        hist[t, HLEN - 1, j] = 0.0
    rel = (a - ti[t, T_BTN]) % n
    hist[t, HLEN - 1, rel if rel < 6 else 12 + rel] = 1.0
    hist[t, HLEN - 1, 6 + kind] = 1.0
    if kind >= 3:
        hist[t, HLEN - 1, 11] = (raise_to - maxbet) / max(pot, 1e-9)
        hist[t, HLEN - 1, 12] = raise_to / max(pot, 1e-9)
        hist[t, HLEN - 1, 13] = math.log1p(raise_to) / 6.0
    elif kind == 2:
        hist[t, HLEN - 1, 12] = min(to_call, stack) / max(pot, 1e-9)
    hist[t, HLEN - 1, 14 + street] = 1.0
    # transition
    if kind == 0:
        is_[t, a, I_FOLD] = 1
        is_[t, a, I_NEED] = 0
    elif kind <= 2:
        amt = min(to_call, stack)
        fs[t, a, F_STACK] -= amt
        fs[t, a, F_SBET] += amt
        fs[t, a, F_COMMIT] += amt
        if fs[t, a, F_STACK] <= 1e-9:
            fs[t, a, F_STACK] = 0.0
            is_[t, a, I_ALLIN] = 1
        is_[t, a, I_NEED] = 0
        is_[t, a, I_CANR] = 0
    else:
        amt = raise_to - fs[t, a, F_SBET]
        fs[t, a, F_STACK] -= amt
        fs[t, a, F_SBET] = raise_to
        fs[t, a, F_COMMIT] += amt
        if fs[t, a, F_STACK] <= 1e-9:
            fs[t, a, F_STACK] = 0.0
            is_[t, a, I_ALLIN] = 1
        inc = raise_to - maxbet
        full = inc >= tf[t, T_LASTR] - 1e-9
        if full:
            tf[t, T_LASTR] = inc
        if raise_to > maxbet + 1e-9:
            for p in range(n):
                if p != a and is_[t, p, I_FOLD] == 0 and is_[t, p, I_ALLIN] == 0:
                    is_[t, p, I_NEED] = 1
                    if full:
                        is_[t, p, I_CANR] = 1
            tf[t, T_MAXBET] = raise_to
        ti[t, T_NRAISE] += 1
        is_[t, a, I_NEED] = 0
        is_[t, a, I_CANR] = 0
    ti[t, T_DEC] += 1


@njit(cache=True)
def _payouts(t, fs, is_, ti, scores, out):
    """Side-pot distribution of all commitments given showdown scores."""
    n = ti[t, T_NP]
    contrib = np.zeros(MAXP)
    for p in range(n):
        contrib[p] = fs[t, p, F_COMMIT]
        out[p] = 0.0
    while True:
        m = 1e18
        for p in range(n):
            if is_[t, p, I_FOLD] == 0 and contrib[p] > 1e-12 and contrib[p] < m:
                m = contrib[p]
        if m >= 1e17:
            # leftover from folded players only: give to best live hand
            left = 0.0
            for p in range(n):
                left += contrib[p]
                contrib[p] = 0.0
            if left > 1e-12:
                best = -1
                for p in range(n):
                    if is_[t, p, I_FOLD] == 0 and scores[p] > best:
                        best = scores[p]
                cnt = 0
                for p in range(n):
                    if is_[t, p, I_FOLD] == 0 and scores[p] == best:
                        cnt += 1
                for p in range(n):
                    if is_[t, p, I_FOLD] == 0 and scores[p] == best:
                        out[p] += left / cnt
            break
        layer = 0.0
        best = -1
        for p in range(n):
            if is_[t, p, I_FOLD] == 0 and contrib[p] >= m - 1e-12 and scores[p] > best:
                best = scores[p]
        cnt = 0
        for p in range(n):
            if is_[t, p, I_FOLD] == 0 and contrib[p] >= m - 1e-12 and scores[p] == best:
                cnt += 1
        winners = np.zeros(MAXP, np.bool_)
        for p in range(n):
            if is_[t, p, I_FOLD] == 0 and contrib[p] >= m - 1e-12 and scores[p] == best:
                winners[p] = True
        for p in range(n):
            take = min(contrib[p], m)
            layer += take
            contrib[p] -= take
        for p in range(n):
            if winners[p]:
                out[p] += layer / cnt


@njit(cache=True)
def _settle(t, fs, is_, ti, deck, won):
    """won[p] = net chips (BB). Board incomplete => expectation over runouts."""
    n = ti[t, T_NP]
    live = 0
    for p in range(n):
        if is_[t, p, I_FOLD] == 0:
            live += 1
    pay = np.zeros(MAXP)
    scores = np.zeros(MAXP, np.int64)
    if live == 1:
        for p in range(n):
            scores[p] = 1 if is_[t, p, I_FOLD] == 0 else 0
        _payouts(t, fs, is_, ti, scores, pay)
    else:
        bn = ti[t, T_BN]
        cards = np.empty(7, np.int64)
        if bn == 5:
            for p in range(n):
                if is_[t, p, I_FOLD] == 0:
                    cards[0] = is_[t, p, I_H0]
                    cards[1] = is_[t, p, I_H1]
                    for i in range(5):
                        cards[2 + i] = ti[t, T_B0 + i]
                    scores[p] = evaluate(cards, 7)
            _payouts(t, fs, is_, ti, scores, pay)
        else:
            used = np.zeros(52, np.bool_)
            for p in range(n):
                used[is_[t, p, I_H0]] = True
                used[is_[t, p, I_H1]] = True
            for i in range(bn):
                used[ti[t, T_B0 + i]] = True
            rem = np.empty(52, np.int64)
            m = 0
            for c in range(52):
                if not used[c]:
                    rem[m] = c
                    m += 1
            k = 5 - bn
            samples = 64
            tmp_pay = np.zeros(MAXP)
            board = np.empty(5, np.int64)
            for i in range(bn):
                board[i] = ti[t, T_B0 + i]
            for _ in range(samples):
                for i in range(k):
                    j = i + np.random.randint(m - i)
                    x = rem[i]
                    rem[i] = rem[j]
                    rem[j] = x
                    board[bn + i] = rem[i]
                for p in range(n):
                    if is_[t, p, I_FOLD] == 0:
                        cards[0] = is_[t, p, I_H0]
                        cards[1] = is_[t, p, I_H1]
                        for i in range(5):
                            cards[2 + i] = board[i]
                        scores[p] = evaluate(cards, 7)
                _payouts(t, fs, is_, ti, scores, tmp_pay)
                for p in range(n):
                    pay[p] += tmp_pay[p] / samples
    for p in range(n):
        won[p] = fs[t, p, F_STACK] + pay[p] - fs[t, p, F_START]


@njit(cache=True)
def _advance(t, fs, is_, tf, ti):
    """After an action: returns True when the hand is over."""
    n = ti[t, T_NP]
    live = 0
    can_act = 0
    for p in range(n):
        if is_[t, p, I_FOLD] == 0:
            live += 1
            if is_[t, p, I_ALLIN] == 0:
                can_act += 1
    if live == 1:
        return True
    nxt = _find_next(t, ti[t, T_ACTOR], fs, is_, ti)
    if nxt >= 0:
        ti[t, T_ACTOR] = nxt
        return False
    if ti[t, T_STREET] == 3 or can_act <= 1:
        return True
    ti[t, T_STREET] += 1
    s = ti[t, T_STREET]
    ti[t, T_BN] = 3 if s == 1 else s + 2
    lagg = ti[t, T_LAGG]
    ti[t, T_LAGG] = -1
    for p in range(n):
        fs[t, p, F_SBET] = 0.0
        is_[t, p, I_ST] = 0
        is_[t, p, I_PAGG] = 1 if p == lagg else 0
        if s == 1 and is_[t, p, I_FOLD] == 0:
            is_[t, p, I_SAWF] = 1
            fs[t, p, F_SAWF] += 1.0
        if is_[t, p, I_FOLD] == 0 and is_[t, p, I_ALLIN] == 0:
            is_[t, p, I_NEED] = 1
            is_[t, p, I_CANR] = 1
    tf[t, T_MAXBET] = 0.0
    tf[t, T_LASTR] = 1.0
    ti[t, T_NRAISE] = 0
    ti[t, T_ACTOR] = _find_next(t, ti[t, T_BTN], fs, is_, ti)
    return False


@njit(cache=True)
def _count_showdown(t, fs, is_, ti):
    n = ti[t, T_NP]
    live = 0
    for p in range(n):
        if is_[t, p, I_FOLD] == 0:
            live += 1
    if live <= 1:
        return
    cards = np.empty(7, np.int64)
    for i in range(5):
        cards[2 + i] = ti[t, T_B0 + i]
    for p in range(n):
        if is_[t, p, I_FOLD] != 0:
            continue
        if is_[t, p, I_SAWF] == 1:
            fs[t, p, F_WTSD] += 1.0
        if is_[t, p, I_RAGG] == 1 or is_[t, p, I_RCALL] == 1:
            cards[0] = is_[t, p, I_H0]
            cards[1] = is_[t, p, I_H1]
            category = evaluate(cards, 7) >> 20
            if is_[t, p, I_RAGG] == 1:
                fs[t, p, F_RSD] += 1.0
                if category == 0:
                    fs[t, p, F_RSDW] += 1.0
            else:
                fs[t, p, F_CSD] += 1.0
                if category <= 1:
                    fs[t, p, F_CSDW] += 1.0


@njit(cache=True, parallel=True)
def step_all(fs, is_, tf, ti, hist, deck, actions, pend_idx, pend_n, buf_ret, buf_state,
             res, kind_probs, league):
    for t in prange(fs.shape[0]):
        _apply(t, actions[t], fs, is_, tf, ti, hist)
        if not (_advance(t, fs, is_, tf, ti) or ti[t, T_DEC] > 400):
            continue
        n = ti[t, T_NP]
        won = np.zeros(MAXP)
        _settle(t, fs, is_, ti, deck, won)
        _count_showdown(t, fs, is_, ti)
        kind = ti[t, T_KIND]
        for p in range(n):
            reward = won[p] / _effective(t, p, fs, ti)
            for k in range(pend_n[t, p]):
                i = pend_idx[t, p, k]
                buf_ret[i] = reward
                buf_state[i] = 2
            pend_n[t, p] = 0
            if is_[t, p, I_AGENT] == 0:
                res[t, 2 * kind] += won[p]
                res[t, 2 * kind + 1] += 1.0
            fs[t, p, F_VPIP] += is_[t, p, I_HVPIP]
            fs[t, p, F_PFR] += is_[t, p, I_HPFR]
        res[t, 2 * NKIND] += 1.0
        _new_hand(t, fs, is_, tf, ti, hist, deck, kind_probs, league)


@njit(cache=True)
def register_pending(ti, pend_idx, pend_n, tables, buf_idx):
    for k in range(tables.shape[0]):
        t = tables[k]
        p = ti[t, T_ACTOR]
        c = pend_n[t, p]
        if c < MAXD:
            pend_idx[t, p, c] = buf_idx[k]
            pend_n[t, p] = c + 1


@njit(cache=True)
def apply_scripted(fs, is_, tf, ti, hist, t, act):
    """Probe helper: apply one action without settling (caller ensures the hand continues)."""
    _apply(t, act, fs, is_, tf, ti, hist)
    return _advance(t, fs, is_, tf, ti)


# ---------------------------------------------------------------- observation

@njit(cache=True)
def _shrunk(count, n, prior):
    return (count + prior * STATS_PRIOR_HANDS) / (n + STATS_PRIOR_HANDS)


@njit(cache=True)
def _cell(count, n, prior):
    return (count + prior * CELL_PRIOR) / (n + CELL_PRIOR)


@njit(cache=True)
def _grid_stats(fs, t, p, s):
    """Seat features 14..60: per street 10 frequencies (bet/raise in contexts 0..5,
    fold in contexts 2..5), mean bet size per street, WTSD and two showdown reveals."""
    for st in range(4):
        base = 14 + 10 * st
        k = 0
        for c in range(NCTX):
            cell = st * NCTX + c
            n = fs[t, p, F_GN + cell]
            s[base + k] = _cell(fs[t, p, F_GA + cell], n, PRIOR_GA[st, c])
            k += 1
            if c >= 2:
                s[base + k] = _cell(fs[t, p, F_GF + cell], n, PRIOR_GF[st, c])
                k += 1
        bets = 0.0
        for c in range(NCTX):
            bets += fs[t, p, F_GA + st * NCTX + c]
        s[54 + st] = _cell(fs[t, p, F_SZ + st], bets, 0.6) / 2.0
    s[58] = _cell(fs[t, p, F_WTSD], fs[t, p, F_SAWF], 0.3)
    s[59] = _cell(fs[t, p, F_RSDW], fs[t, p, F_RSD], 0.3)
    s[60] = _cell(fs[t, p, F_CSDW], fs[t, p, F_CSD], 0.4)


@njit(cache=True, parallel=True)
def build_obs(fs, is_, tf, ti, hist, deck, preflop_eq, eq_samples, G, C, S, M, EQ,
              actor_agent, actor_seat):
    for t in prange(fs.shape[0]):
        a = ti[t, T_ACTOR]
        n = ti[t, T_NP]
        btn = ti[t, T_BTN]
        street = ti[t, T_STREET]
        bn = ti[t, T_BN]
        actor_agent[t] = is_[t, a, I_AGENT]
        actor_seat[t] = a
        _legal(t, fs, is_, tf, ti, M[t])
        E = _effective(t, a, fs, ti)
        pot = _pot(t, fs)
        to_call = tf[t, T_MAXBET] - fs[t, a, F_SBET]
        stack = fs[t, a, F_STACK]
        live = 0
        can_act = 0
        max_other = 0.0
        for p in range(n):
            if is_[t, p, I_FOLD] == 0:
                live += 1
                if is_[t, p, I_ALLIN] == 0:
                    can_act += 1
                if p != a and fs[t, p, F_STACK] > max_other:
                    max_other = fs[t, p, F_STACK]
        g = G[t]
        for i in range(NG):
            g[i] = 0.0
        g[street] = 1.0
        g[4 + n - 2 if n <= 6 else 45 + n - 7] = 1.0
        g[9] = live / 6.0
        g[10] = can_act / 6.0
        g[11] = pot / E
        g[12] = to_call / E
        g[13] = to_call / (pot + to_call)
        g[14] = stack / E
        g[15] = min(min(stack, max_other) / pot, 20.0) / 5.0
        g[16] = math.log(E) / math.log(200.0)
        g[17] = math.log1p(pot) / 6.0
        g[18] = ti[t, T_NRAISE] / 4.0
        pos = (a - btn) % n
        g[19 + pos if pos < 6 else 48 + pos - 6] = 1.0
        behind = 0
        last = True
        for k in range(1, n):
            p = (a + k) % n
            if is_[t, p, I_FOLD] == 0 and is_[t, p, I_ALLIN] == 0:
                if is_[t, p, I_NEED] == 1:
                    behind += 1
                if (p - btn) % n > pos and (p - btn) % n != 0:
                    last = False
                if (p - btn) % n == 0 and pos != 0:
                    last = False
        g[25] = behind / 5.0
        g[26] = 1.0 if (street > 0 and last) else 0.0
        h0 = is_[t, a, I_H0]
        h1 = is_[t, a, I_H1]
        nopp = max(live - 1, 1)
        pe = preflop_eq[preflop_class(h0, h1), nopp]
        g[27] = pe
        board = np.empty(5, np.int64)
        for i in range(bn):
            board[i] = ti[t, T_B0 + i]
        if street == 0:
            eq = pe
            if (h0 >> 2) == (h1 >> 2):
                g[30] = 1.0
            else:
                g[29] = 1.0
        else:
            eq = equity_mc(h0, h1, board, bn, nopp, eq_samples)
            cards = np.empty(7, np.int64)
            cards[0] = h0
            cards[1] = h1
            for i in range(bn):
                cards[2 + i] = board[i]
            g[29 + (evaluate(cards, 2 + bn) >> 20)] = 1.0
        g[28] = eq
        EQ[t] = eq
        r0 = h0 >> 2
        r1 = h1 >> 2
        g[38] = 1.0 if (h0 & 3) == (h1 & 3) else 0.0
        g[39] = max(r0, r1) / 12.0
        g[40] = min(r0, r1) / 12.0
        g[41] = 1.0 if r0 == r1 else 0.0
        g[42] = ti[t, T_VIS]
        g[43] = E / 200.0
        g[44] = math.log1p(to_call) / 5.0
        C[t, 0] = h0
        C[t, 1] = h1
        for i in range(5):
            C[t, 2 + i] = ti[t, T_B0 + i] if i < bn else 52
        for i in range(MAXP):
            s = S[t, i]
            for j in range(NS):
                s[j] = 0.0
            if i >= n:
                continue
            p = (a + i) % n
            s[0] = 1.0
            s[1] = is_[t, p, I_FOLD]
            s[2] = is_[t, p, I_ALLIN]
            s[3] = fs[t, p, F_STACK] / E
            s[4] = fs[t, p, F_COMMIT] / E
            s[5] = fs[t, p, F_SBET] / E
            s[6] = ((p - btn) % n) / 5.0
            s[13] = fs[t, p, F_START] / E
            hands = fs[t, p, F_HANDS]
            if ti[t, T_VIS] == 1 and i > 0 and hands > STATS_MIN_HANDS:
                s[8] = _shrunk(fs[t, p, F_VPIP], hands, 0.3)
                s[9] = _shrunk(fs[t, p, F_PFR], hands, 0.2)
                s[10] = _shrunk(fs[t, p, F_AGG], fs[t, p, F_AGG] + fs[t, p, F_PASS], 0.4)
                s[11] = _shrunk(fs[t, p, F_FOLDF], fs[t, p, F_FACED], 0.4)
                s[12] = math.log1p(hands) / math.log(300.0)
                _grid_stats(fs, t, p, s)
            else:
                s[7] = 1.0


# ---------------------------------------------------------------- bots

@njit(cache=True, parallel=True)
def bot_policy(fs, is_, tf, ti, M, EQ, actions):
    for t in prange(fs.shape[0]):
        a = ti[t, T_ACTOR]
        agent = is_[t, a, I_AGENT]
        if agent >= 0:
            continue
        m = M[t]
        tight = fs[t, a, F_BOT]
        if tight < -1:
            cnt = 0
            for i in range(NA):
                if m[i]:
                    cnt += 1
            k = np.random.randint(cnt)
            for i in range(NA):
                if m[i]:
                    if k == 0:
                        actions[t] = i
                        break
                    k -= 1
            continue
        P = fs[t, a, F_BOT:F_BOT + NBOT]
        aggr = P[1]
        size = P[2]
        slack = P[3]
        street = ti[t, T_STREET]
        bluff = P[4 + street]
        ctx = _context(t, a, is_, tf, ti, fs)
        n = ti[t, T_NP]
        live = 0
        for p in range(n):
            if is_[t, p, I_FOLD] == 0:
                live += 1
        strength = EQ[t] * live
        pot = _pot(t, fs)
        to_call = tf[t, T_MAXBET] - fs[t, a, F_SBET]
        odds = to_call / (pot + to_call)
        raise_thr = 1.15 + 0.5 * tight - 0.4 * aggr
        r = np.random.random()
        want_raise = (strength > raise_thr and r < 0.5 + 0.5 * aggr) or np.random.random() < bluff
        weak = strength < raise_thr + 0.3
        u = np.random.random()
        if street == 0:
            if ctx == 2 and u < P[8]:
                want_raise = True
            elif ctx == 4 and weak and u < P[9]:
                actions[t] = A_FOLD
                continue
        else:
            if ctx == 0 and u < (P[10] if street == 1 else P[11]):
                want_raise = True
            elif ctx == 1 and u < P[12]:
                want_raise = True
            elif ctx == 3 and u < P[13]:
                want_raise = True
            elif ctx == 4 and weak and u < P[15]:
                actions[t] = A_FOLD
                continue
            if (to_call <= 1e-9 and want_raise and strength > raise_thr
                    and np.random.random() < P[14]):
                want_raise = False
        act = A_CALL
        if want_raise:
            target = A_RAISE0 + int(size * (NFRAC - 1) + np.random.randint(3) - 1)
            best = -1
            bestd = 99
            for i in range(A_RAISE0, A_ALLIN):
                if m[i] and abs(i - target) < bestd:
                    bestd = abs(i - target)
                    best = i
            if best >= 0:
                act = best
            elif m[A_ALLIN] and strength > raise_thr + 0.5:
                act = A_ALLIN
        elif to_call > 1e-9:
            if EQ[t] < odds * (1.0 + 0.5 * tight - slack):
                act = A_FOLD
            elif street > 0 and strength < raise_thr and np.random.random() < -slack:
                act = A_FOLD
        actions[t] = act
